import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { vendorApi } from '@/lib/api'
import type { Vendor, CreateVendorData } from '@/types'

interface EditVendorFormProps {
  vendor: Vendor | null
  open: boolean
  onClose: () => void
}

export default function EditVendorForm({ vendor, open, onClose }: EditVendorFormProps) {
  const queryClient = useQueryClient()
  
  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<CreateVendorData>({
    defaultValues: {
      name: vendor?.name || '',
      contact: vendor?.contact || '',
      email: vendor?.email || '',
      phone: vendor?.phone || '',
      address: vendor?.address || '',
      tax_number: vendor?.tax_number || '',
    }
  })

  // تحديث القيم عند تغيير المورد
  useEffect(() => {
    if (vendor) {
      setValue('name', vendor.name)
      setValue('contact', vendor.contact || '')
      setValue('email', vendor.email || '')
      setValue('phone', vendor.phone || '')
      setValue('address', vendor.address || '')
      setValue('tax_number', vendor.tax_number || '')
    }
  }, [vendor, setValue])

  // mutation لتحديث المورد
  const updateMutation = useMutation({
    mutationFn: (data: CreateVendorData) => 
      vendorApi.updateVendor(vendor!.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vendors'] })
      reset()
      onClose()
    },
    onError: (error) => {
      console.error('خطأ في تحديث المورد:', error)
    }
  })

  const onSubmit = (data: CreateVendorData) => {
    if (!vendor) return
    updateMutation.mutate(data)
  }

  if (!vendor) return null

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>تحرير المورد</DialogTitle>
          <DialogDescription>
            تحديث تفاصيل مورد "{vendor.name}"
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">اسم المورد *</Label>
            <Input
              {...register('name', { required: 'اسم المورد مطلوب' })}
              placeholder="مثال: شركة التقنيات المتقدمة"
            />
            {errors.name && (
              <span className="text-sm text-destructive">{errors.name.message}</span>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="contact">جهة الاتصال (اختياري)</Label>
            <Input
              {...register('contact')}
              placeholder="مثال: أحمد محمد"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">البريد الإلكتروني (اختياري)</Label>
            <Input
              {...register('email')}
              type="email"
              placeholder="مثال: contact@company.com"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">رقم الهاتف (اختياري)</Label>
            <Input
              {...register('phone')}
              placeholder="مثال: +966501234567"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">العنوان (اختياري)</Label>
            <Textarea
              {...register('address')}
              placeholder="العنوان الكامل للمورد..."
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tax_number">الرقم الضريبي (اختياري)</Label>
            <Input
              {...register('tax_number')}
              placeholder="مثال: 123456789000003"
            />
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                reset()
                onClose()
              }}
            >
              إلغاء
            </Button>
            <Button
              type="submit"
              disabled={updateMutation.isPending}
            >
              {updateMutation.isPending ? 'جاري الحفظ...' : 'حفظ التغييرات'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
