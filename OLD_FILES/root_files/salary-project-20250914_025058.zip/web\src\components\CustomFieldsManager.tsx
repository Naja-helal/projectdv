import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"


import { Trash2, Plus, Settings } from 'lucide-react'
import { customFieldApi } from '@/lib/api'
import { CustomField } from '@/types'

interface CustomFieldsManagerProps {
  onBack?: () => void
}

export default function CustomFieldsManager({ onBack }: CustomFieldsManagerProps = {}) {
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    entity: 'expense' as 'expense' | 'category' | 'vendor',
    name: '',
    key: '',
    type: 'text' as 'text' | 'number' | 'date' | 'select' | 'bool',
    required: false,
    options: '',
    sort_order: 0
  })

  const queryClient = useQueryClient()

  const { data: customFields = [], isLoading } = useQuery({
    queryKey: ['customFields'],
    queryFn: () => customFieldApi.getCustomFields()
  })

  const createMutation = useMutation({
    mutationFn: customFieldApi.createCustomField,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customFields'] })
      setShowForm(false)
      setFormData({
        entity: 'expense',
        name: '',
        key: '',
        type: 'text',
        required: false,
        options: '',
        sort_order: 0
      })
      alert('تم إضافة الحقل بنجاح')
    },
    onError: (error: any) => {
      alert(error.message || 'حدث خطأ في إضافة الحقل')
    }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.name.trim() || !formData.key.trim()) {
      alert('يرجى ملء جميع الحقول المطلوبة')
      return
    }

    const data = {
      ...formData,
      options: formData.type === 'select' && formData.options 
        ? formData.options.split(',').map(opt => opt.trim())
        : undefined
    }

    createMutation.mutate(data)
  }

  const generateKey = (name: string) => {
    return name
      .toLowerCase()
      .replace(/[^\w\s]/g, '')
      .replace(/\s+/g, '_')
      .replace(/[أ-ي]/g, match => {
        const arabicToEnglish: { [key: string]: string } = {
          'أ': 'a', 'ب': 'b', 'ت': 't', 'ث': 'th', 'ج': 'j', 'ح': 'h', 'خ': 'kh',
          'د': 'd', 'ذ': 'dh', 'ر': 'r', 'ز': 'z', 'س': 's', 'ش': 'sh', 'ص': 's',
          'ض': 'd', 'ط': 't', 'ظ': 'dh', 'ع': 'a', 'غ': 'gh', 'ف': 'f', 'ق': 'q',
          'ك': 'k', 'ل': 'l', 'م': 'm', 'ن': 'n', 'ه': 'h', 'و': 'w', 'ي': 'y'
        }
        return arabicToEnglish[match] || match
      })
  }

  const handleNameChange = (name: string) => {
    setFormData(prev => ({
      ...prev,
      name,
      key: generateKey(name)
    }))
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          {onBack && (
            <Button variant="outline" onClick={onBack}>
              ← العودة
            </Button>
          )}
          <div>
            <h1 className="text-3xl font-bold">إدارة الحقول المخصصة</h1>
            <p className="text-muted-foreground mt-2">
              إضافة وإدارة الحقول المخصصة للكيانات المختلفة
            </p>
          </div>
        </div>
        <Button onClick={() => setShowForm(!showForm)}>
          <Plus className="w-4 h-4 ml-2" />
          إضافة حقل جديد
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>إضافة حقل مخصص</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="entity">نوع الكيان</Label>
                  <select 
                    value={formData.entity}
                    onChange={(e) => setFormData(prev => ({ ...prev, entity: e.target.value as any }))}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="expense">المصروفات</option>
                    <option value="vendor">المورّدين</option>
                    <option value="category">الفئات</option>
                  </select>
                </div>

                <div>
                  <Label htmlFor="type">نوع الحقل</Label>
                  <select 
                    value={formData.type}
                    onChange={(e) => setFormData(prev => ({ ...prev, type: e.target.value as any }))}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="text">نص</option>
                    <option value="number">رقم</option>
                    <option value="date">تاريخ</option>
                    <option value="select">قائمة اختيار</option>
                  </select>
                </div>
              </div>

              <div>
                <Label htmlFor="name">اسم الحقل</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  placeholder="مثال: اسم الموقع"
                  required
                />
              </div>

              <div>
                <Label htmlFor="key">المفتاح (تلقائي)</Label>
                <Input
                  id="key"
                  value={formData.key}
                  onChange={(e) => setFormData(prev => ({ ...prev, key: e.target.value }))}
                  placeholder="site_name"
                  required
                />
              </div>

              {formData.type === 'select' && (
                <div>
                  <Label htmlFor="options">الخيارات (مفصولة بفواصل)</Label>
                  <Input
                    id="options"
                    value={formData.options}
                    onChange={(e) => setFormData(prev => ({ ...prev, options: e.target.value }))}
                    placeholder="خيار 1, خيار 2, خيار 3"
                  />
                </div>
              )}

              <div className="flex items-center space-x-2">
                <input
                  id="required"
                  type="checkbox"
                  checked={formData.required}
                  onChange={(e) => 
                    setFormData(prev => ({ ...prev, required: e.target.checked }))
                  }
                  className="h-4 w-4 rounded border"
                />
                <Label htmlFor="required">حقل إجباري</Label>
              </div>

              <div className="flex gap-2">
                <Button type="submit" disabled={createMutation.isPending}>
                  {createMutation.isPending ? 'جاري الإضافة...' : 'إضافة الحقل'}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>الحقول المخصصة الموجودة</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-muted-foreground mt-2">جاري التحميل...</p>
            </div>
          ) : customFields.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Settings className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
              <p>لا توجد حقول مخصصة حالياً</p>
              <p className="text-sm mt-1">أضف حقلك الأول باستخدام الزر أعلاه</p>
            </div>
          ) : (
            <div className="space-y-3">
              {customFields.map((field: CustomField) => (
                <div
                  key={field.id}
                  className="flex items-center justify-between p-4 border rounded-lg"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <h4 className="font-medium">{field.name}</h4>
                      <span className="text-xs px-2 py-1 bg-primary/10 text-primary rounded">
                        {field.entity === 'expense' ? 'مصروف' : 
                         field.entity === 'vendor' ? 'مورّد' : 'فئة'}
                      </span>
                      <span className="text-xs px-2 py-1 bg-muted text-muted-foreground rounded">
                        {field.type === 'text' ? 'نص' :
                         field.type === 'number' ? 'رقم' :
                         field.type === 'date' ? 'تاريخ' : 'قائمة'}
                      </span>
                      {field.required && (
                        <span className="text-xs px-2 py-1 bg-red-100 text-red-700 rounded">
                          إجباري
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      المفتاح: {field.key}
                    </p>
                    {field.options && (
                      <p className="text-sm text-muted-foreground mt-1">
                        الخيارات: {Array.isArray(field.options) ? field.options.join(', ') : field.options}
                      </p>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    onClick={() => {
                      // TODO: إضافة وظيفة الحذف
                      alert('وظيفة الحذف ستكون متاحة قريباً')
                    }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
