import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { bramawiApi, settingsApi } from '@/lib/api'
import type { BramawiField, CreateBramawiFieldData } from '@/types'
import { Plus, Settings as SettingsIcon, Trash2, Edit, Calculator, DollarSign, Calendar } from 'lucide-react'
import CustomFieldsManager from "@/components/CustomFieldsManager"

// مكون إعدادات الرواتب
function SalarySettingsTab() {
  const queryClient = useQueryClient()
  
  // جلب الإعدادات
  const { data: settings, isLoading } = useQuery({
    queryKey: ['salary-settings'],
    queryFn: settingsApi.getAll
  })

  // تحديث إعداد
  const updateMutation = useMutation({
    mutationFn: ({ key, value, type }: { key: string; value: any; type?: string }) =>
      settingsApi.update(key, { value, type }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['salary-settings'] })
    }
  })

  const handleSettingUpdate = async (key: string, value: any, type?: string) => {
    try {
      await updateMutation.mutateAsync({ key, value, type })
    } catch (error) {
      console.error('خطأ في تحديث الإعداد:', error)
    }
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">جاري تحميل الإعدادات...</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            إعدادات الرواتب
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            إعدادات نظام الرواتب الجديد والتوليد التلقائي
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* يوم توليد الرواتب */}
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5 text-blue-600" />
              <div>
                <h4 className="font-medium">يوم توليد الرواتب</h4>
                <p className="text-sm text-muted-foreground">
                  اليوم من الشهر الذي يتم فيه توليد الرواتب تلقائياً
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Input
                type="number"
                min="1"
                max="28"
                value={settings?.salary_generation_day?.value || 1}
                onChange={(e) => handleSettingUpdate('salary_generation_day', parseInt(e.target.value), 'number')}
                className="w-20 text-center"
                disabled={updateMutation.isPending}
              />
              <span className="text-sm text-muted-foreground">من كل شهر</span>
            </div>
          </div>

          {/* التوليد التلقائي */}
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-3">
              <SettingsIcon className="h-5 w-5 text-green-600" />
              <div>
                <h4 className="font-medium">التوليد التلقائي للرواتب</h4>
                <p className="text-sm text-muted-foreground">
                  تفعيل توليد الرواتب تلقائياً في تاريخ محدد من كل شهر
                </p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings?.auto_generate_salaries?.value || false}
                onChange={(e) => handleSettingUpdate('auto_generate_salaries', e.target.checked, 'boolean')}
                className="sr-only peer"
                disabled={updateMutation.isPending}
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          {/* الراتب الافتراضي */}
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-3">
              <DollarSign className="h-5 w-5 text-green-600" />
              <div>
                <h4 className="font-medium">الراتب الافتراضي</h4>
                <p className="text-sm text-muted-foreground">
                  المبلغ الافتراضي عند إضافة موظف جديد
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Input
                type="number"
                min="0"
                step="0.01"
                value={settings?.default_salary_amount?.value || 5000}
                onChange={(e) => handleSettingUpdate('default_salary_amount', parseFloat(e.target.value), 'number')}
                className="w-32 text-right"
                disabled={updateMutation.isPending}
                dir="ltr"
              />
              <span className="text-sm text-muted-foreground">ريال</span>
            </div>
          </div>

          {/* معلومات إضافية */}
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h4 className="font-medium text-blue-900 mb-2">ملاحظات مهمة:</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• يتم توليد الرواتب تلقائياً للموظفين النشطين فقط</li>
              <li>• عند إضافة موظف جديد، يتم إنشاء راتب الشهر الحالي تلقائياً</li>
              <li>• يمكن توليد رواتب أشهر سابقة أو مستقبلية يدوياً من صفحة الرواتب</li>
              <li>• التوليد التلقائي يحدث مرة واحدة فقط لكل شهر لكل موظف</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default function Settings() {
  const [activeTab, setActiveTab] = useState('general')
  const [showCustomFields, setShowCustomFields] = useState(false)
  const [showFieldForm, setShowFieldForm] = useState(false)
  const [editingField, setEditingField] = useState<BramawiField | null>(null)
  const [formData, setFormData] = useState<CreateBramawiFieldData>({
    name: '',
    type: 'text',
    label: '',
    is_required: false,
    display_order: 0
  })

  const queryClient = useQueryClient()

  // جلب الحقول
  const { data: fields = [], isLoading } = useQuery({
    queryKey: ['bramawi-fields'],
    queryFn: bramawiApi.getFields
  })

  // إضافة حقل جديد
  const createMutation = useMutation({
    mutationFn: bramawiApi.createField,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bramawi-fields'] })
      resetForm()
      setShowFieldForm(false)
    }
  })

  // تحديث حقل
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number, data: Partial<CreateBramawiFieldData> }) =>
      bramawiApi.updateField(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bramawi-fields'] })
      resetForm()
      setShowFieldForm(false)
      setEditingField(null)
    }
  })

  // حذف حقل
  const deleteMutation = useMutation({
    mutationFn: bramawiApi.deleteField,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bramawi-fields'] })
    }
  })

  const resetForm = () => {
    setFormData({
      name: '',
      type: 'text',
      label: '',
      is_required: false,
      display_order: 0
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (editingField) {
      updateMutation.mutate({ id: editingField.id, data: formData })
    } else {
      createMutation.mutate(formData)
    }
  }

  const handleEdit = (field: BramawiField) => {
    setEditingField(field)
    setFormData({
      name: field.name,
      type: field.type,
      label: field.label,
      options: field.options,
      calculation_formula: field.calculation_formula,
      dependent_fields: field.dependent_fields,
      is_required: field.is_required,
      display_order: field.display_order
    })
    setShowFieldForm(true)
  }

  const handleDelete = (field: BramawiField) => {
    if (confirm(`هل أنت متأكد من حذف الحقل "${field.label}"؟`)) {
      deleteMutation.mutate(field.id)
    }
  }

  const getTypeLabel = (type: string) => {
    const types = {
      text: 'نص',
      number: 'رقم',
      date: 'تاريخ',
      select: 'اختيار',
      calculated: 'محسوب',
      fixed: 'ثابت'
    }
    return types[type as keyof typeof types] || type
  }

  const addOption = () => {
    const newOptions = [...(formData.options || []), '']
    setFormData(prev => ({ ...prev, options: newOptions }))
  }

  const updateOption = (index: number, value: string) => {
    const newOptions = [...(formData.options || [])]
    newOptions[index] = value
    setFormData(prev => ({ ...prev, options: newOptions }))
  }

  const removeOption = (index: number) => {
    const newOptions = [...(formData.options || [])]
    newOptions.splice(index, 1)
    setFormData(prev => ({ ...prev, options: newOptions }))
  }

  if (showCustomFields) {
    return <CustomFieldsManager onBack={() => setShowCustomFields(false)} />
  }

  return (
    <div className="space-y-6">
      {/* الرأس */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">الإعدادات</h1>
          <p className="text-muted-foreground mt-2">
            إعدادات النظام وإدارة الحقول الديناميكية
          </p>
        </div>
        {activeTab === 'bramawi' && (
          <Button onClick={() => setShowFieldForm(true)}>
            <Plus className="h-4 w-4 ml-2" />
            إضافة حقل برماوي
          </Button>
        )}
      </div>

      {/* التبويبات */}
      <Card>
        <CardContent className="p-4">
          <div className="flex space-x-1 border-b">
            <button
              onClick={() => setActiveTab('general')}
              className={`px-4 py-2 text-sm font-medium rounded-t-lg ${
                activeTab === 'general'
                  ? 'bg-blue-100 text-blue-700 border-b-2 border-blue-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              عام
            </button>
            <button
              onClick={() => setActiveTab('salaries')}
              className={`px-4 py-2 text-sm font-medium rounded-t-lg ${
                activeTab === 'salaries'
                  ? 'bg-blue-100 text-blue-700 border-b-2 border-blue-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              الرواتب
            </button>
            <button
              onClick={() => setActiveTab('bramawi')}
              className={`px-4 py-2 text-sm font-medium rounded-t-lg ${
                activeTab === 'bramawi'
                  ? 'bg-blue-100 text-blue-700 border-b-2 border-blue-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              البرماوي
            </button>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6">
        {/* محتوى التبويب العام */}
        {activeTab === 'general' && (
          <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              🔧 الحقول الديناميكية
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              إدارة الحقول الديناميكية لجميع صفحات النظام (المساجد، التوزيع، المصروفات، وغيرها)
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <h3 className="font-medium mb-2">🕌 حقول المساجد</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    إدارة الحقول المخصصة لصفحة المساجد مثل اسم المسجد، الموقع، أرقام الاتصال
                  </p>
                  <Button 
                    onClick={() => window.open('/dynamic-fields?tab=mosques', '_blank')}
                    variant="outline" 
                    size="sm"
                  >
                    إدارة حقول المساجد
                  </Button>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h3 className="font-medium mb-2">📦 حقول التوزيع</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    إدارة الحقول المخصصة لصفحة التوزيع مثل نوع التوزيع، عدد الربطات، المسجد المستهدف
                  </p>
                  <Button 
                    onClick={() => window.open('/dynamic-fields?tab=distributions', '_blank')}
                    variant="outline" 
                    size="sm"
                  >
                    إدارة حقول التوزيع
                  </Button>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h3 className="font-medium mb-2">💰 حقول المصروفات</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    إدارة الحقول المخصصة لصفحة المصروفات مثل اسم الموقع، مزود الاستضافة
                  </p>
                  <Button 
                    onClick={() => window.open('/dynamic-fields?tab=expenses', '_blank')}
                    variant="outline" 
                    size="sm"
                  >
                    إدارة حقول المصروفات
                  </Button>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h3 className="font-medium mb-2">📋 حقول البرماوي</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    إدارة الحقول المخصصة لصفحة البرماوي (النظام التقليدي)
                  </p>
                  <Button 
                    onClick={() => {
                      const element = document.getElementById('bramawi-fields');
                      if (element) {
                        element.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    variant="outline" 
                    size="sm"
                  >
                    إدارة حقول البرماوي
                  </Button>
                </div>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-2">💡 نصائح مهمة:</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• كل صفحة لها حقول ديناميكية منفصلة ومستقلة</li>
                  <li>• يمكنك إضافة حقول جديدة أو تعديل الموجودة حسب احتياجاتك</li>
                  <li>• الحقول المطلوبة ستظهر بعلامة نجمة (*) في النماذج</li>
                  <li>• يمكن ترتيب الحقول حسب الأولوية المطلوبة</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
        )}

        {/* محتوى تبويب الرواتب */}
        {activeTab === 'salaries' && (
          <SalarySettingsTab />
        )}

        {/* محتوى تبويب البرماوي */}
        {activeTab === 'bramawi' && (
          <Card id="bramawi-fields">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <SettingsIcon className="h-5 w-5" />
              حقول البرماوي الديناميكية ({fields.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="mt-2 text-muted-foreground">جاري التحميل...</p>
              </div>
            ) : fields.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <div className="text-4xl mb-4">�</div>
                <h3 className="text-lg font-semibold mb-2">لا توجد حقول محددة</h3>
                <p>ابدأ بإضافة الحقول الأساسية لنظام البرماوي</p>
                <p className="text-sm mt-2">مثل: عدد الربطات، القيمة، المبلغ الإجمالي</p>
              </div>
            ) : (
              <div className="space-y-3">
                {fields
                  .sort((a, b) => a.display_order - b.display_order)
                  .map((field, index) => (
                    <div
                      key={field.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50"
                    >
                      <div className="flex items-center gap-4">
                        <div className="text-lg font-mono text-muted-foreground">
                          #{field.display_order || index + 1}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold">{field.label}</h3>
                            <Badge variant="outline">{getTypeLabel(field.type)}</Badge>
                            {field.is_required && (
                              <Badge variant="destructive">مطلوب</Badge>
                            )}
                            {field.type === 'calculated' && (
                              <Badge className="bg-blue-100 text-blue-800">
                                <Calculator className="h-3 w-3 ml-1" />
                                محسوب
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm text-muted-foreground mt-1">
                            اسم الحقل: <code className="bg-muted px-1 rounded">{field.name}</code>
                            {field.calculation_formula && (
                              <span className="mr-4">
                                الصيغة: <code className="bg-muted px-1 rounded">{field.calculation_formula}</code>
                              </span>
                            )}
                          </div>
                          {field.options && field.options.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {field.options.map((option, i) => (
                                <Badge key={i} variant="secondary" className="text-xs">
                                  {option}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleEdit(field)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDelete(field)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </CardContent>
        </Card>
        )}
      </div>

      {/* نموذج إضافة/تعديل الحقل */}
      <Dialog open={showFieldForm} onOpenChange={setShowFieldForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingField ? 'تعديل الحقل' : 'إضافة حقل جديد'}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {/* اسم الحقل */}
              <div className="space-y-2">
                <Label>اسم الحقل (بالإنجليزية)</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="num_bundles"
                  required
                />
                <p className="text-xs text-muted-foreground">
                  يستخدم في قاعدة البيانات (بدون مسافات)
                </p>
              </div>

              {/* العنوان */}
              <div className="space-y-2">
                <Label>العنوان (بالعربية)</Label>
                <Input
                  value={formData.label}
                  onChange={(e) => setFormData(prev => ({ ...prev, label: e.target.value }))}
                  placeholder="عدد الربطات"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* نوع الحقل */}
              <div className="space-y-2">
                <Label>نوع الحقل</Label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData(prev => ({ ...prev, type: e.target.value as any }))}
                  className="w-full p-2 border rounded-md bg-background"
                >
                  <option value="text">نص</option>
                  <option value="number">رقم</option>
                  <option value="date">تاريخ</option>
                  <option value="select">قائمة اختيار</option>
                  <option value="calculated">حقل محسوب</option>
                </select>
              </div>

              {/* ترتيب العرض */}
              <div className="space-y-2">
                <Label>ترتيب العرض</Label>
                <Input
                  type="number"
                  value={formData.display_order}
                  onChange={(e) => setFormData(prev => ({ ...prev, display_order: parseInt(e.target.value) || 0 }))}
                  placeholder="0"
                />
              </div>
            </div>

            {/* خيارات القائمة (للنوع select) */}
            {formData.type === 'select' && (
              <div className="space-y-2">
                <Label>خيارات القائمة</Label>
                <div className="space-y-2">
                  {(formData.options || []).map((option, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        value={option}
                        onChange={(e) => updateOption(index, e.target.value)}
                        placeholder={`الخيار ${index + 1}`}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeOption(index)}
                      >
                        حذف
                      </Button>
                    </div>
                  ))}
                  <Button
                    type="button"
                    variant="outline"
                    onClick={addOption}
                  >
                    <Plus className="h-4 w-4 ml-2" />
                    إضافة خيار
                  </Button>
                </div>
              </div>
            )}

            {/* صيغة الحساب (للنوع calculated) */}
            {formData.type === 'calculated' && (
              <div className="space-y-2">
                <Label>صيغة الحساب</Label>
                <Input
                  value={formData.calculation_formula || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, calculation_formula: e.target.value }))}
                  placeholder="num_bundles * unit_price"
                />
                <p className="text-xs text-muted-foreground">
                  مثال: num_bundles * unit_price (استخدم أسماء الحقول الموجودة)
                </p>
              </div>
            )}

            {/* الحقول المرتبطة (للنوع calculated) */}
            {formData.type === 'calculated' && (
              <div className="space-y-2">
                <Label>الحقول المرتبطة</Label>
                <Input
                  value={formData.dependent_fields?.join(', ') || ''}
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    dependent_fields: e.target.value.split(',').map(f => f.trim()).filter(f => f) 
                  }))}
                  placeholder="num_bundles, unit_price"
                />
                <p className="text-xs text-muted-foreground">
                  أسماء الحقول المطلوبة للحساب (مفصولة بفاصلة)
                </p>
              </div>
            )}

            {/* حقل القيمة الافتراضية */}
            {formData.type !== 'calculated' && (
              <div className="space-y-2">
                <Label htmlFor="default-value">القيمة الافتراضية</Label>
                <Input
                  id="default-value"
                  value={formData.default_value || ''}
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    default_value: e.target.value 
                  }))}
                  placeholder="أدخل القيمة الافتراضية (اختيارية)"
                />
                <p className="text-xs text-muted-foreground">
                  هذه القيمة ستظهر تلقائياً في النموذج ويمكن تعديلها
                </p>
              </div>
            )}

            {/* حقل مطلوب */}
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="required"
                checked={formData.is_required}
                onChange={(e) => setFormData(prev => ({ ...prev, is_required: e.target.checked }))}
              />
              <Label htmlFor="required">حقل مطلوب</Label>
            </div>

            {/* أزرار التحكم */}
            <div className="flex justify-end gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowFieldForm(false)
                  setEditingField(null)
                  resetForm()
                }}
              >
                إلغاء
              </Button>
              <Button 
                type="submit" 
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {editingField ? 'تحديث' : 'إضافة'} الحقل
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
