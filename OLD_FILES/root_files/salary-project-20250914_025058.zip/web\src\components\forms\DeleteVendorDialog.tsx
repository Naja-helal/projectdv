import { useMutation, useQueryClient } from '@tanstack/react-query'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { vendorApi } from '@/lib/api'
import type { Vendor } from '@/types'

interface DeleteVendorDialogProps {
  vendor: Vendor | null
  open: boolean
  onClose: () => void
}

export default function DeleteVendorDialog({ vendor, open, onClose }: DeleteVendorDialogProps) {
  const queryClient = useQueryClient()

  const deleteMutation = useMutation({
    mutationFn: (vendorId: number) => vendorApi.deleteVendor(vendorId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vendors'] })
      onClose()
    },
    onError: (error) => {
      console.error('خطأ في حذف المورد:', error)
    }
  })

  const handleDelete = () => {
    if (vendor) {
      deleteMutation.mutate(vendor.id)
    }
  }

  if (!vendor) return null

  return (
    <AlertDialog open={open} onOpenChange={onClose}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>حذف المورد</AlertDialogTitle>
          <AlertDialogDescription>
            هل أنت متأكد من حذف المورد "<strong>{vendor.name}</strong>"؟
            <br />
            هذا الإجراء لا يمكن التراجع عنه.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>إلغاء</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={deleteMutation.isPending}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {deleteMutation.isPending ? 'جاري الحذف...' : 'حذف'}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
