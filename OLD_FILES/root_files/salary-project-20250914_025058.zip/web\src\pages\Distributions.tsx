import React, { useState, useEffect } from 'react';
import { Package, Plus, Edit, Trash2, Building2, Calendar, Hash, FileText } from 'lucide-react';
import { getApiUrl } from '@/lib/api';

interface Mosque {
  id: number;
  name: string;
  location: string | null;
}

interface Distribution {
  id: number;
  mosque_id: number;
  mosque_name: string;
  mosque_location: string | null;
  type: 'تصوير' | 'تصريف';
  bundles_count: number;
  notes: string | null;
  created_at: number;
  updated_at: number;
}

export default function Distributions() {
  const [distributions, setDistributions] = useState<Distribution[]>([]);
  const [mosques, setMosques] = useState<Mosque[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingDistribution, setEditingDistribution] = useState<Distribution | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'تصوير' | 'تصريف'>('all');
  const [filterMosque, setFilterMosque] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    mosque_id: '',
    type: 'تصوير' as 'تصوير' | 'تصريف',
    bundles_count: '',
    notes: ''
  });

  useEffect(() => {
    fetchDistributions();
    fetchMosques();
  }, []);

  useEffect(() => {
    fetchDistributions();
  }, [filterType, filterMosque]);

  const fetchMosques = async () => {
    try {
      const response = await fetch(getApiUrl('/mosques'));
      const data = await response.json();
      setMosques(data);
    } catch (error) {
      console.error('خطأ في جلب المساجد:', error);
    }
  };

  const fetchDistributions = async () => {
    try {
      let url = getApiUrl('/distributions');
      const params = new URLSearchParams();
      
      if (filterType !== 'all') {
        params.append('type', filterType);
      }
      
      if (filterMosque) {
        params.append('mosque_id', filterMosque.toString());
      }
      
      if (params.toString()) {
        url += '?' + params.toString();
      }
      
      const response = await fetch(url);
      const data = await response.json();
      setDistributions(data);
    } catch (error) {
      console.error('خطأ في جلب التوزيعات:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.mosque_id || !formData.bundles_count) {
      alert('الرجاء ملء جميع الحقول المطلوبة');
      return;
    }
    
    try {
      const url = editingDistribution 
        ? getApiUrl(`/distributions/${editingDistribution.id}`)
        : getApiUrl('/distributions');
      
      const method = editingDistribution ? 'PATCH' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mosque_id: parseInt(formData.mosque_id),
          type: formData.type,
          bundles_count: parseInt(formData.bundles_count),
          notes: formData.notes || null
        })
      });

      if (response.ok) {
        fetchDistributions();
        resetForm();
      } else {
        const errorData = await response.json();
        alert(errorData.error || 'حدث خطأ');
      }
    } catch (error) {
      console.error('خطأ في حفظ التوزيع:', error);
      alert('حدث خطأ في الحفظ');
    }
  };

  const handleDelete = async (id: number, mosqueName: string, type: string) => {
    if (!confirm(`هل تريد حذف توزيع ${type} للمسجد "${mosqueName}"؟`)) return;
    
    try {
      const response = await fetch(getApiUrl(`/distributions/${id}`), {
        method: 'DELETE'
      });

      if (response.ok) {
        fetchDistributions();
      } else {
        const errorData = await response.json();
        alert(errorData.error || 'حدث خطأ في الحذف');
      }
    } catch (error) {
      console.error('خطأ في حذف التوزيع:', error);
      alert('حدث خطأ في الحذف');
    }
  };

  const resetForm = () => {
    setFormData({ mosque_id: '', type: 'تصوير', bundles_count: '', notes: '' });
    setEditingDistribution(null);
    setShowForm(false);
  };

  const startEdit = (distribution: Distribution) => {
    setFormData({
      mosque_id: distribution.mosque_id.toString(),
      type: distribution.type,
      bundles_count: distribution.bundles_count.toString(),
      notes: distribution.notes || ''
    });
    setEditingDistribution(distribution);
    setShowForm(true);
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTypeColor = (type: string) => {
    return type === 'تصوير' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800';
  };

  // حساب الإحصائيات
  const totalBundles = distributions.reduce((sum, dist) => sum + dist.bundles_count, 0);
  const totalTasweer = distributions.filter(d => d.type === 'تصوير').reduce((sum, d) => sum + d.bundles_count, 0);
  const totalTasreef = distributions.filter(d => d.type === 'تصريف').reduce((sum, d) => sum + d.bundles_count, 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Package className="h-8 w-8 text-green-600" />
          <div>
            <h1 className="text-2xl font-bold text-gray-900">إدارة التوزيع</h1>
            <p className="text-gray-600">تتبع عمليات توزيع الربطات على المساجد</p>
          </div>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-green-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-green-700 transition-colors"
        >
          <Plus className="h-4 w-4" />
          إضافة توزيع جديد
        </button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6 border-r-4 border-purple-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">إجمالي العمليات</p>
              <p className="text-2xl font-bold text-gray-900">{distributions.length}</p>
            </div>
            <Package className="h-8 w-8 text-purple-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 border-r-4 border-gray-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">إجمالي الربطات</p>
              <p className="text-2xl font-bold text-gray-900">{totalBundles}</p>
            </div>
            <Hash className="h-8 w-8 text-gray-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 border-r-4 border-blue-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">ربطات تصوير</p>
              <p className="text-2xl font-bold text-gray-900">{totalTasweer}</p>
            </div>
            <div className="h-8 w-8 bg-blue-100 rounded-lg flex items-center justify-center">
              <span className="text-blue-600 font-bold">ت</span>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 border-r-4 border-green-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">ربطات تصريف</p>
              <p className="text-2xl font-bold text-gray-900">{totalTasreef}</p>
            </div>
            <div className="h-8 w-8 bg-green-100 rounded-lg flex items-center justify-center">
              <span className="text-green-600 font-bold">ص</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium text-gray-700">فلترة حسب النوع:</label>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as any)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">جميع الأنواع</option>
              <option value="تصوير">تصوير</option>
              <option value="تصريف">تصريف</option>
            </select>
          </div>
          
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium text-gray-700">فلترة حسب المسجد:</label>
            <select
              value={filterMosque || ''}
              onChange={(e) => setFilterMosque(e.target.value ? parseInt(e.target.value) : null)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="">جميع المساجد</option>
              {mosques.map(mosque => (
                <option key={mosque.id} value={mosque.id}>{mosque.name}</option>
              ))}
            </select>
          </div>
          
          {(filterType !== 'all' || filterMosque) && (
            <button
              onClick={() => {
                setFilterType('all');
                setFilterMosque(null);
              }}
              className="text-sm text-gray-500 hover:text-gray-700"
            >
              إلغاء الفلاتر
            </button>
          )}
        </div>
      </div>

      {/* Distributions Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  المسجد
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  النوع
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  عدد الربطات
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الملاحظات
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  التاريخ
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الإجراءات
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {distributions.map((distribution) => (
                <tr key={distribution.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Building2 className="h-4 w-4 text-gray-400 ml-2" />
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {distribution.mosque_name}
                        </div>
                        {distribution.mosque_location && (
                          <div className="text-sm text-gray-500">
                            {distribution.mosque_location}
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getTypeColor(distribution.type)}`}>
                      {distribution.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Hash className="h-4 w-4 text-gray-400 ml-1" />
                      <span className="text-sm font-medium text-gray-900">
                        {distribution.bundles_count}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {distribution.notes ? (
                      <div className="flex items-start">
                        <FileText className="h-4 w-4 text-gray-400 ml-1 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-600">
                          {distribution.notes}
                        </span>
                      </div>
                    ) : (
                      <span className="text-sm text-gray-400">لا توجد ملاحظات</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 text-gray-400 ml-1" />
                      <span className="text-sm text-gray-500">
                        {formatDate(distribution.created_at)}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex gap-2">
                      <button
                        onClick={() => startEdit(distribution)}
                        className="text-amber-600 hover:text-amber-900"
                        title="تعديل"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(distribution.id, distribution.mosque_name, distribution.type)}
                        className="text-red-600 hover:text-red-900"
                        title="حذف"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {distributions.length === 0 && (
          <div className="text-center py-12">
            <Package className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">لا توجد عمليات توزيع</h3>
            <p className="mt-1 text-sm text-gray-500">ابدأ بإضافة أول عملية توزيع</p>
          </div>
        )}
      </div>

      {/* Add/Edit Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <h2 className="text-xl font-bold mb-4">
              {editingDistribution ? 'تعديل التوزيع' : 'إضافة توزيع جديد'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  اختيار المسجد *
                </label>
                <select
                  required
                  value={formData.mosque_id}
                  onChange={(e) => setFormData({ ...formData, mosque_id: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                  <option value="">اختر المسجد</option>
                  {mosques.map(mosque => (
                    <option key={mosque.id} value={mosque.id}>
                      {mosque.name} {mosque.location && `- ${mosque.location}`}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  نوع التوزيع *
                </label>
                <select
                  required
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                  <option value="تصوير">تصوير</option>
                  <option value="تصريف">تصريف</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  عدد الربطات *
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  value={formData.bundles_count}
                  onChange={(e) => setFormData({ ...formData, bundles_count: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  ملاحظات
                </label>
                <textarea
                  rows={3}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="أي ملاحظات إضافية..."
                />
              </div>
              
              <div className="flex gap-2 justify-end">
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-4 py-2 text-gray-600 bg-gray-200 rounded-md hover:bg-gray-300"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                >
                  {editingDistribution ? 'تحديث' : 'إضافة'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
