import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, User, Trash2, Edit, Phone, Calendar, DollarSign, RefreshCw } from 'lucide-react'
import { employeesApi, salariesApi } from '@/lib/api'
import type { Employee } from '@/types'
import EmployeeForm from '../components/forms/EmployeeForm'
import { formatCurrency, formatDate } from '@/lib/utils'

export default function EmployeesPage() {
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null)
  
  const queryClient = useQueryClient()

  // جلب الموظفين
  const { data: employees = [], isLoading } = useQuery({
    queryKey: ['employees'],
    queryFn: employeesApi.getAll,
  })

  // حذف موظف
  const deleteMutation = useMutation({
    mutationFn: employeesApi.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employees'] })
    },
  })

  // مزامنة رواتب الموظف
  const syncSalaryMutation = useMutation({
    mutationFn: salariesApi.syncEmployee,
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['salaries'] })
      alert(`تم تحديث ${data.updated_count} راتب بنجاح`)
    },
    onError: () => {
      alert('حدث خطأ في مزامنة الرواتب')
    }
  })

  const handleEdit = (employee: Employee) => {
    setEditingEmployee(employee)
    setIsFormOpen(true)
  }

  const handleDelete = async (id: number) => {
    if (window.confirm('هل أنت متأكد من حذف هذا الموظف؟ سيتم إلغاء تفعيله فقط.')) {
      try {
        await deleteMutation.mutateAsync(id)
      } catch (error) {
        console.error('خطأ في حذف الموظف:', error)
      }
    }
  }

  const handleSyncSalary = async (employee: Employee) => {
    if (window.confirm(`هل تريد مزامنة جميع الرواتب غير المسلمة للموظف ${employee.name} مع راتبه الحالي؟`)) {
      try {
        await syncSalaryMutation.mutateAsync(employee.id!)
      } catch (error) {
        console.error('خطأ في مزامنة الرواتب:', error)
      }
    }
  }

  const handleCloseForm = () => {
    setIsFormOpen(false)
    setEditingEmployee(null)
  }

  const getMonthsSinceHiring = (hireDate: string) => {
    if (!hireDate) return null
    const hire = new Date(hireDate)
    const now = new Date()
    const months = (now.getFullYear() - hire.getFullYear()) * 12 + (now.getMonth() - hire.getMonth())
    return months
  }

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-40 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <User className="h-8 w-8 text-blue-600" />
          <div>
            <h1 className="text-2xl font-bold text-gray-900">إدارة الموظفين</h1>
            <p className="text-sm text-gray-500">
              {employees.length} موظف نشط
            </p>
          </div>
        </div>
        
        <Button onClick={() => setIsFormOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          إضافة موظف جديد
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-blue-600" />
              <span className="text-sm text-gray-600">إجمالي الموظفين</span>
            </div>
            <div className="text-2xl font-bold mt-1">{employees.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-green-600" />
              <span className="text-sm text-gray-600">إجمالي الرواتب</span>
            </div>
            <div className="text-2xl font-bold mt-1">
              {formatCurrency(employees.reduce((sum, emp) => sum + emp.monthly_salary, 0))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-purple-600" />
              <span className="text-sm text-gray-600">متوسط سنوات الخبرة</span>
            </div>
            <div className="text-2xl font-bold mt-1">
              {employees.length > 0 
                ? Math.round(employees
                    .filter(emp => emp.hire_date)
                    .reduce((sum, emp) => sum + (getMonthsSinceHiring(emp.hire_date!) || 0), 0) 
                    / employees.filter(emp => emp.hire_date).length / 12 * 10) / 10
                : 0} سنة
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-orange-600" />
              <span className="text-sm text-gray-600">متوسط الراتب</span>
            </div>
            <div className="text-2xl font-bold mt-1">
              {employees.length > 0 
                ? formatCurrency(employees.reduce((sum, emp) => sum + emp.monthly_salary, 0) / employees.length)
                : formatCurrency(0)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Employees Grid */}
      {employees.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">لا يوجد موظفين</h3>
            <p className="text-gray-500 mb-4">ابدأ بإضافة موظف جديد لبدء إدارة الرواتب</p>
            <Button onClick={() => setIsFormOpen(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              إضافة أول موظف
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {employees.map((employee) => (
            <Card key={employee.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{employee.name}</CardTitle>
                      {employee.position && (
                        <p className="text-sm text-gray-500">{employee.position}</p>
                      )}
                    </div>
                  </div>
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    نشط
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-3">
                {/* معلومات الراتب */}
                <div className="flex items-center gap-2 text-sm">
                  <DollarSign className="h-4 w-4 text-green-600" />
                  <span className="text-gray-500">الراتب الشهري:</span>
                  <span className="font-medium">{formatCurrency(employee.monthly_salary)}</span>
                </div>

                {/* رقم الهاتف */}
                {employee.phone && (
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-blue-600" />
                    <span className="text-gray-500">الهاتف:</span>
                    <span className="font-medium">{employee.phone}</span>
                  </div>
                )}

                {/* تاريخ التوظيف */}
                {employee.hire_date && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-purple-600" />
                    <span className="text-gray-500">تاريخ التوظيف:</span>
                    <span className="font-medium">{formatDate(employee.hire_date)}</span>
                  </div>
                )}

                {/* مدة الخدمة */}
                {employee.hire_date && (
                  <div className="text-xs text-gray-500">
                    مدة الخدمة: {getMonthsSinceHiring(employee.hire_date)} شهر
                  </div>
                )}

                {/* أزرار الإجراءات */}
                <div className="flex gap-2 pt-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleEdit(employee)}
                    className="flex-1 gap-1"
                  >
                    <Edit className="h-3 w-3" />
                    تعديل
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleSyncSalary(employee)}
                    className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 gap-1"
                    disabled={syncSalaryMutation.isPending}
                    title="مزامنة الرواتب مع الراتب الحالي"
                  >
                    <RefreshCw className="h-3 w-3" />
                    مزامنة
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDelete(employee.id)}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Employee Form Dialog */}
      <EmployeeForm
        open={isFormOpen}
        onClose={handleCloseForm}
        editEmployee={editingEmployee}
      />
    </div>
  )
}