import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function Vendors() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">المورّدين</h1>
          <p className="text-muted-foreground mt-2">
            إدارة المورّدين ومقدمي الخدمات
          </p>
        </div>
        <button className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90">
          ➕ إضافة مورّد
        </button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>قائمة المورّدين</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12 text-muted-foreground">
            <div className="text-6xl mb-4">🏪</div>
            <p>سيتم إضافة جدول المورّدين هنا</p>
            <p className="text-sm mt-2">قريباً...</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
