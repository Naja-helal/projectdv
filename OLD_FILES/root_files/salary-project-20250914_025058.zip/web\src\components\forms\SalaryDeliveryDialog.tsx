import { useState, useEffect } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { salariesApi } from '@/lib/api'
import type { MonthlySalary } from '@/types'
import { formatCurrency, getMonthName } from '@/lib/utils'

interface SalaryDeliveryDialogProps {
  open: boolean
  onClose: () => void
  salary: MonthlySalary | null
}

export default function SalaryDeliveryDialog({ open, onClose, salary }: SalaryDeliveryDialogProps) {
  const [formData, setFormData] = useState({
    is_delivered: false,
    delivery_date: '',
    debt_amount: '',
    notes: '',
  })

  const queryClient = useQueryClient()

  // تحديث حالة التسليم
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: { is_delivered: boolean; delivery_date?: string; debt_amount?: number; notes?: string } }) => 
      salariesApi.updateDelivery(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['salaries'] })
      onClose()
      alert('تم تحديث حالة الراتب بنجاح')
    },
    onError: (error) => {
      console.error('خطأ في تحديث حالة الراتب:', error)
      alert('حدث خطأ في تحديث حالة الراتب')
    }
  })

  useEffect(() => {
    if (open && salary) {
      setFormData({
        is_delivered: salary.is_delivered,
        delivery_date: salary.delivery_date ? salary.delivery_date.split('T')[0] : new Date().toISOString().split('T')[0],
        debt_amount: salary.debt_amount.toString(),
        notes: salary.notes || '',
      })
    }
  }, [open, salary])

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!salary) return

    const debtAmount = parseFloat(formData.debt_amount) || 0
    if (debtAmount < 0) {
      alert('مبلغ الدين لا يمكن أن يكون سالباً')
      return
    }

    const submitData = {
      is_delivered: formData.is_delivered,
      delivery_date: formData.is_delivered ? formData.delivery_date : undefined,
      debt_amount: debtAmount,
      notes: formData.notes.trim() || undefined,
    }

    console.log('تحديث حالة الراتب:', { salaryId: salary.id, submitData })
    
    if (!salary.id) {
      alert('خطأ: معرف الراتب غير موجود')
      return
    }

    try {
      await updateMutation.mutateAsync({ id: salary.id, data: submitData })
    } catch (error) {
      console.error('خطأ في تحديث حالة الراتب:', error)
    }
  }

  if (!salary) return null

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            تسليم راتب {salary.employee_name}
          </DialogTitle>
          <p className="text-sm text-gray-500">
            {getMonthName(salary.month)} {salary.year} - {formatCurrency(salary.salary_amount)}
          </p>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Card>
            <CardContent className="p-4 space-y-4">
              {/* حالة التسليم */}
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="is_delivered"
                  checked={formData.is_delivered}
                  onCheckedChange={(checked) => handleInputChange('is_delivered', checked as boolean)}
                />
                <Label htmlFor="is_delivered" className="text-sm font-medium">
                  تم تسليم الراتب
                </Label>
              </div>

              {/* تاريخ التسليم */}
              {formData.is_delivered && (
                <div className="space-y-2">
                  <Label htmlFor="delivery_date">تاريخ التسليم</Label>
                  <Input
                    id="delivery_date"
                    type="date"
                    value={formData.delivery_date}
                    onChange={(e) => handleInputChange('delivery_date', e.target.value)}
                    required={formData.is_delivered}
                  />
                </div>
              )}

              {/* مبلغ الدين */}
              <div className="space-y-2">
                <Label htmlFor="debt_amount">مبلغ الدين (ريال)</Label>
                <Input
                  id="debt_amount"
                  type="number"
                  placeholder="0"
                  min="0"
                  step="0.01"
                  value={formData.debt_amount}
                  onChange={(e) => handleInputChange('debt_amount', e.target.value)}
                  className="text-right"
                  dir="ltr"
                />
                <p className="text-xs text-gray-500">
                  إذا كان هناك مبلغ مطلوب من الموظف
                </p>
              </div>

              {/* ملاحظات */}
              <div className="space-y-2">
                <Label htmlFor="notes">ملاحظات</Label>
                <Textarea
                  id="notes"
                  placeholder="أي ملاحظات إضافية..."
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  rows={3}
                  className="text-right"
                />
              </div>

              {/* معلومات إضافية */}
              <div className="p-3 bg-gray-50 rounded-lg">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-gray-500">اسم الموظف:</span>
                    <div className="font-medium">{salary.employee_name}</div>
                  </div>
                  {salary.position && (
                    <div>
                      <span className="text-gray-500">المنصب:</span>
                      <div className="font-medium">{salary.position}</div>
                    </div>
                  )}
                  <div>
                    <span className="text-gray-500">الشهر:</span>
                    <div className="font-medium">{getMonthName(salary.month)} {salary.year}</div>
                  </div>
                  <div>
                    <span className="text-gray-500">مبلغ الراتب:</span>
                    <div className="font-medium">{formatCurrency(salary.salary_amount)}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* أزرار الحفظ والإلغاء */}
          <div className="flex gap-3 pt-4">
            <Button
              type="submit"
              disabled={updateMutation.isPending}
              className="flex-1"
            >
              {updateMutation.isPending ? 'جاري الحفظ...' : 'حفظ'}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={updateMutation.isPending}
              className="flex-1"
            >
              إلغاء
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}