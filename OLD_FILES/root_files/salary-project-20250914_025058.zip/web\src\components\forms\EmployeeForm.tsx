import { useState, useEffect } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { employeesApi } from '@/lib/api'
import type { Employee } from '@/types'

interface EmployeeFormProps {
  open: boolean
  onClose: () => void
  editEmployee?: Employee | null
}

export default function EmployeeForm({ open, onClose, editEmployee }: EmployeeFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    position: '',
    phone: '',
    monthly_salary: '',
    hire_date: '',
  })

  const queryClient = useQueryClient()
  const isEditing = Boolean(editEmployee)

  // إضافة موظف جديد
  const createMutation = useMutation({
    mutationFn: employeesApi.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employees'] })
      resetForm()
      onClose()
    }
  })

  // تحديث موظف موجود
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => employeesApi.update(id, data),
    onSuccess: (response: any) => {
      queryClient.invalidateQueries({ queryKey: ['employees'] })
      queryClient.invalidateQueries({ queryKey: ['salaries'] }) // تحديث الرواتب أيضاً
      
      if (response.salary_updated) {
        alert('تم تحديث بيانات الموظف بنجاح!\n' + (response.updated_salaries || ''))
      }
      
      resetForm()
      onClose()
    }
  })

  useEffect(() => {
    if (open && editEmployee) {
      setFormData({
        name: editEmployee.name,
        position: editEmployee.position || '',
        phone: editEmployee.phone || '',
        monthly_salary: editEmployee.monthly_salary.toString(),
        hire_date: editEmployee.hire_date ? editEmployee.hire_date.split('T')[0] : '',
      })
    } else if (open && !editEmployee) {
      resetForm()
    }
  }, [open, editEmployee])

  const resetForm = () => {
    setFormData({
      name: '',
      position: '',
      phone: '',
      monthly_salary: '',
      hire_date: '',
    })
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name.trim() || !formData.monthly_salary.trim()) {
      alert('الاسم والراتب الشهري مطلوبان')
      return
    }

    const salary = parseFloat(formData.monthly_salary)
    if (isNaN(salary) || salary <= 0) {
      alert('يرجى إدخال راتب صحيح')
      return
    }

    const submitData = {
      name: formData.name.trim(),
      position: formData.position.trim() || undefined,
      phone: formData.phone.trim() || undefined,
      monthly_salary: salary,
      hire_date: formData.hire_date || undefined,
    }

    try {
      if (isEditing && editEmployee) {
        await updateMutation.mutateAsync({ id: editEmployee.id, data: submitData })
      } else {
        await createMutation.mutateAsync(submitData)
      }
    } catch (error) {
      console.error('خطأ في حفظ الموظف:', error)
    }
  }

  const isPending = createMutation.isPending || updateMutation.isPending

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? 'تعديل بيانات الموظف' : 'إضافة موظف جديد'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Card>
            <CardContent className="p-4 space-y-4">
              {/* اسم الموظف */}
              <div className="space-y-2">
                <Label htmlFor="name">اسم الموظف *</Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="أدخل اسم الموظف"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  required
                  className="text-right"
                />
              </div>

              {/* المنصب */}
              <div className="space-y-2">
                <Label htmlFor="position">المنصب</Label>
                <Input
                  id="position"
                  type="text"
                  placeholder="مثل: مطور، محاسب، مدير"
                  value={formData.position}
                  onChange={(e) => handleInputChange('position', e.target.value)}
                  className="text-right"
                />
              </div>

              {/* رقم الهاتف */}
              <div className="space-y-2">
                <Label htmlFor="phone">رقم الهاتف</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="05XXXXXXXX"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  className="text-right"
                  dir="ltr"
                />
              </div>

              {/* الراتب الشهري */}
              <div className="space-y-2">
                <Label htmlFor="monthly_salary">الراتب الشهري (ريال) *</Label>
                <Input
                  id="monthly_salary"
                  type="number"
                  placeholder="5000"
                  min="0"
                  step="0.01"
                  value={formData.monthly_salary}
                  onChange={(e) => handleInputChange('monthly_salary', e.target.value)}
                  required
                  className="text-right"
                  dir="ltr"
                />
              </div>

              {/* تاريخ التوظيف */}
              <div className="space-y-2">
                <Label htmlFor="hire_date">تاريخ التوظيف</Label>
                <Input
                  id="hire_date"
                  type="date"
                  value={formData.hire_date}
                  onChange={(e) => handleInputChange('hire_date', e.target.value)}
                  className="text-right"
                />
              </div>
            </CardContent>
          </Card>

          {/* أزرار الحفظ والإلغاء */}
          <div className="flex gap-3 pt-4">
            <Button
              type="submit"
              disabled={isPending}
              className="flex-1"
            >
              {isPending ? 'جاري الحفظ...' : (isEditing ? 'تحديث' : 'إضافة')}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isPending}
              className="flex-1"
            >
              إلغاء
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}