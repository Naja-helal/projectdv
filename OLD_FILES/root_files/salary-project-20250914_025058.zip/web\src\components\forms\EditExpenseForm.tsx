import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { expenseApi, categoryApi, vendorApi } from '@/lib/api'
import type { Expense, CreateExpenseData, ExpenseFormData } from '@/types'

interface EditExpenseFormProps {
  expense: Expense | null
  open: boolean
  onClose: () => void
}

export default function EditExpenseForm({ expense, open, onClose }: EditExpenseFormProps) {
  const queryClient = useQueryClient()
  const [customFields, setCustomFields] = useState<Record<string, string>>({})
  
    const { register, handleSubmit, formState: { errors }, setValue, watch, reset } = useForm<ExpenseFormData>()

  // جلب البيانات المرجعية
  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: categoryApi.getCategories
  })
  
  const { data: vendors } = useQuery({
    queryKey: ['vendors'],
    queryFn: vendorApi.getVendors
  })

  // تحديث القيم عند تغيير المصروف
  useEffect(() => {
    if (expense) {
      setValue('categoryId', expense.category_id)
      setValue('vendorId', expense.vendor_id || undefined)
      setValue('amount', expense.amount)
      setValue('taxRate', expense.tax_rate || 0)
      // تحويل التاريخ من timestamp إلى تنسيق date input
      const dateValue = typeof expense.date === 'number' 
        ? new Date(expense.date).toISOString().split('T')[0]
        : expense.date
      setValue('date', dateValue)
      setValue('paymentMethod', expense.payment_method || '')
      setValue('reference', expense.reference || '')
      setValue('invoiceNumber', expense.invoice_number || '')
      setValue('notes', expense.notes || '')
      
      // الحقول المخصصة
      if (expense.custom_fields) {
        const customFieldsData: Record<string, string> = {}
        Object.entries(expense.custom_fields).forEach(([key, field]) => {
          customFieldsData[key] = field.value
        })
        setCustomFields(customFieldsData)
      }
    }
  }, [expense, setValue])

  // مراقبة المبلغ ومعدل الضريبة لحساب الإجمالي
  const amount = watch('amount')
  const taxRate = watch('taxRate')
  
  const taxAmount = amount && taxRate ? (amount * (taxRate / 100)) : 0
  const totalAmount = (amount || 0) + taxAmount

  // mutation لتحديث المصروف
  const updateMutation = useMutation({
    mutationFn: (data: CreateExpenseData & { id: number }) => 
      expenseApi.updateExpense(data.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses'] })
      queryClient.invalidateQueries({ queryKey: ['stats'] })
      reset()
      setCustomFields({})
      onClose()
    },
    onError: (error) => {
      console.error('خطأ في تحديث المصروف:', error)
    }
  })

  const onSubmit = (data: ExpenseFormData) => {
    if (!expense) return
    
    // تحويل التاريخ من string إلى timestamp
    const dateValue = new Date(data.date).getTime()
    
    const submitData: CreateExpenseData & { id: number } = {
      ...data,
      id: expense.id,
      date: dateValue,
      customFields: Object.keys(customFields).length > 0 ? customFields : undefined
    }
    
    updateMutation.mutate(submitData)
  }

  const addCustomField = () => {
    const fieldName = prompt('اسم الحقل المخصص:')
    if (fieldName && !customFields[fieldName]) {
      setCustomFields(prev => ({ ...prev, [fieldName]: '' }))
    }
  }

  if (!expense) return null

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>تحرير المصروف</DialogTitle>
          <DialogDescription>
            تحديث تفاصيل المصروف
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* الفئة */}
            <div className="space-y-2">
              <Label htmlFor="categoryId">الفئة *</Label>
              <select
                {...register('categoryId', { 
                  required: 'الفئة مطلوبة',
                  valueAsNumber: true 
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">اختر الفئة</option>
                {categories?.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.icon} {category.name}
                  </option>
                ))}
              </select>
              {errors.categoryId && (
                <span className="text-sm text-destructive">{errors.categoryId.message}</span>
              )}
            </div>

            {/* المبلغ */}
            <div className="space-y-2">
              <Label htmlFor="amount">المبلغ (ريال) *</Label>
              <Input
                {...register('amount', { 
                  required: 'المبلغ مطلوب',
                  valueAsNumber: true,
                  min: { value: 0.01, message: 'المبلغ يجب أن يكون أكبر من صفر' }
                })}
                type="number"
                step="0.01"
                placeholder="100.00"
              />
              {errors.amount && (
                <span className="text-sm text-destructive">{errors.amount.message}</span>
              )}
            </div>

            {/* المورد */}
            <div className="space-y-2">
              <Label htmlFor="vendorId">المورد (اختياري)</Label>
              <select
                {...register('vendorId', { valueAsNumber: true })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">بدون مورد</option>
                {vendors?.map((vendor) => (
                  <option key={vendor.id} value={vendor.id}>
                    {vendor.name}
                  </option>
                ))}
              </select>
            </div>

            {/* معدل الضريبة */}
            <div className="space-y-2">
              <Label htmlFor="taxRate">معدل الضريبة (%)</Label>
              <Input
                {...register('taxRate', { valueAsNumber: true })}
                type="number"
                step="0.01"
                min="0"
                max="100"
                placeholder="15"
              />
            </div>

            {/* التاريخ */}
            <div className="space-y-2">
              <Label htmlFor="date">التاريخ *</Label>
              <Input
                {...register('date', { 
                  required: 'التاريخ مطلوب'
                })}
                type="date"
                defaultValue={new Date().toISOString().split('T')[0]}
              />
              {errors.date && (
                <span className="text-sm text-destructive">{errors.date.message}</span>
              )}
            </div>

            {/* طريقة الدفع */}
            <div className="space-y-2">
              <Label htmlFor="paymentMethod">طريقة الدفع</Label>
              <select
                {...register('paymentMethod')}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">اختر طريقة الدفع</option>
                <option value="cash">نقداً</option>
                <option value="card">بطاقة ائتمان</option>
                <option value="bank_transfer">تحويل بنكي</option>
                <option value="check">شيك</option>
                <option value="other">أخرى</option>
              </select>
            </div>

            {/* المرجع */}
            <div className="space-y-2">
              <Label htmlFor="reference">المرجع</Label>
              <Input
                {...register('reference')}
                placeholder="رقم المرجع أو الوصل"
              />
            </div>

            {/* رقم الفاتورة */}
            <div className="space-y-2">
              <Label htmlFor="invoiceNumber">رقم الفاتورة</Label>
              <Input
                {...register('invoiceNumber')}
                placeholder="رقم الفاتورة"
              />
            </div>
          </div>

          {/* الملاحظات */}
          <div className="space-y-2">
            <Label htmlFor="notes">الملاحظات</Label>
            <Textarea
              {...register('notes')}
              placeholder="ملاحظات إضافية..."
              rows={3}
            />
          </div>

          {/* الحقول المخصصة */}
          {Object.keys(customFields).length > 0 && (
            <div className="space-y-2">
              <Label>الحقول المخصصة</Label>
              {Object.entries(customFields).map(([fieldName, value]) => (
                <div key={fieldName} className="flex gap-2">
                  <Input
                    placeholder={fieldName}
                    value={value}
                    onChange={(e) => setCustomFields(prev => ({
                      ...prev,
                      [fieldName]: e.target.value
                    }))}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setCustomFields(prev => {
                        const { [fieldName]: _, ...rest } = prev
                        return rest
                      })
                    }}
                  >
                    حذف
                  </Button>
                </div>
              ))}
            </div>
          )}

          <Button
            type="button"
            variant="outline"
            onClick={addCustomField}
            className="w-full"
          >
            + إضافة حقل مخصص
          </Button>

          {/* ملخص المبالغ */}
          {amount && (
            <div className="bg-gray-50 p-4 rounded-md space-y-2">
              <div className="flex justify-between text-sm">
                <span>المبلغ الأساسي:</span>
                <span>{amount} ريال</span>
              </div>
              {taxRate && taxRate > 0 && (
                <div className="flex justify-between text-sm">
                  <span>الضريبة ({taxRate}%):</span>
                  <span>{taxAmount.toFixed(2)} ريال</span>
                </div>
              )}
              <div className="flex justify-between font-bold border-t pt-2">
                <span>الإجمالي:</span>
                <span>{totalAmount.toFixed(2)} ريال</span>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                reset()
                setCustomFields({})
                onClose()
              }}
            >
              إلغاء
            </Button>
            <Button
              type="submit"
              disabled={updateMutation.isPending}
            >
              {updateMutation.isPending ? 'جاري الحفظ...' : 'حفظ التغييرات'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
