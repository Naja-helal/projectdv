import { useMutation, useQueryClient } from '@tanstack/react-query'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { expenseApi } from '@/lib/api'
import type { Expense } from '@/types'

interface DeleteExpenseDialogProps {
  expense: Expense | null
  open: boolean
  onClose: () => void
}

export default function DeleteExpenseDialog({ expense, open, onClose }: DeleteExpenseDialogProps) {
  const queryClient = useQueryClient()

  const deleteMutation = useMutation({
    mutationFn: (expenseId: number) => expenseApi.deleteExpense(expenseId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses'] })
      queryClient.invalidateQueries({ queryKey: ['stats'] })
      onClose()
    },
    onError: (error) => {
      console.error('خطأ في حذف المصروف:', error)
    }
  })

  const handleDelete = () => {
    if (expense) {
      deleteMutation.mutate(expense.id)
    }
  }

  if (!expense) return null

  return (
    <AlertDialog open={open} onOpenChange={onClose}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>حذف المصروف</AlertDialogTitle>
          <AlertDialogDescription>
            هل أنت متأكد من حذف هذا المصروف؟
            <br />
            <strong>المبلغ:</strong> {expense.amount} ريال
            <br />
            <strong>الفئة:</strong> {expense.category_name}
            <br />
            هذا الإجراء لا يمكن التراجع عنه.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>إلغاء</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={deleteMutation.isPending}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {deleteMutation.isPending ? 'جاري الحذف...' : 'حذف'}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
