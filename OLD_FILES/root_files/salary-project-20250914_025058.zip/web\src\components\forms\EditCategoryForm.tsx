import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { categoryApi } from '@/lib/api'
import type { Category, CreateCategoryData } from '@/types'

interface EditCategoryFormProps {
  category: Category | null
  open: boolean
  onClose: () => void
}

export default function EditCategoryForm({ category, open, onClose }: EditCategoryFormProps) {
  const queryClient = useQueryClient()
  
  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<CreateCategoryData>({
    defaultValues: {
      name: category?.name || '',
      code: category?.code || '',
      color: category?.color || '#3b82f6',
      icon: category?.icon || '',
      description: category?.description || '',
    }
  })

  // تحديث القيم عند تغيير الفئة
  useEffect(() => {
    if (category) {
      setValue('name', category.name)
      setValue('code', category.code || '')
      setValue('color', category.color)
      setValue('icon', category.icon || '')
      setValue('description', category.description || '')
    }
  }, [category, setValue])

  // mutation لتحديث الفئة
  const updateMutation = useMutation({
    mutationFn: (data: CreateCategoryData) => 
      categoryApi.updateCategory(category!.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] })
      reset()
      onClose()
    },
    onError: (error) => {
      console.error('خطأ في تحديث الفئة:', error)
    }
  })

  const onSubmit = (data: CreateCategoryData) => {
    if (!category) return
    updateMutation.mutate(data)
  }

  const predefinedColors = [
    '#ef4444', '#f97316', '#06b6d4', '#10b981', '#6b7280',
    '#8b5cf6', '#f59e0b', '#ec4899', '#3b82f6', '#84cc16'
  ]

  const predefinedIcons = [
    '👷', '🚚', '🌐', '💰', '📋', '🧱', '🔧', '🚗', '🏪', '📱'
  ]

  if (!category) return null

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>تحرير الفئة</DialogTitle>
          <DialogDescription>
            تحديث تفاصيل فئة "{category.name}"
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">اسم الفئة *</Label>
            <Input
              {...register('name', { required: 'اسم الفئة مطلوب' })}
              placeholder="مثال: اشتراكات مواقع/هوست"
            />
            {errors.name && (
              <span className="text-sm text-destructive">{errors.name.message}</span>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="code">الرمز (اختياري)</Label>
            <Input
              {...register('code')}
              placeholder="مثال: hosting"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">الوصف (اختياري)</Label>
            <Textarea
              {...register('description')}
              placeholder="وصف مختصر للفئة..."
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label>اللون</Label>
            <div className="flex gap-2 flex-wrap">
              {predefinedColors.map((color) => (
                <button
                  key={color}
                  type="button"
                  className="w-8 h-8 rounded-full border-2 border-muted"
                  style={{ backgroundColor: color }}
                  onClick={() => setValue('color', color)}
                />
              ))}
            </div>
            <Input
              {...register('color')}
              type="color"
              className="w-20 h-10"
            />
          </div>

          <div className="space-y-2">
            <Label>الأيقونة</Label>
            <div className="flex gap-2 flex-wrap">
              {predefinedIcons.map((icon) => (
                <button
                  key={icon}
                  type="button"
                  className="w-8 h-8 border rounded flex items-center justify-center hover:bg-muted"
                  onClick={() => setValue('icon', icon)}
                >
                  {icon}
                </button>
              ))}
            </div>
            <Input
              {...register('icon')}
              placeholder="🏷️"
              maxLength={2}
            />
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                reset()
                onClose()
              }}
            >
              إلغاء
            </Button>
            <Button
              type="submit"
              disabled={updateMutation.isPending}
            >
              {updateMutation.isPending ? 'جاري الحفظ...' : 'حفظ التغييرات'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
