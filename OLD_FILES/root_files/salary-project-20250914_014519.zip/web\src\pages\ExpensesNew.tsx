import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import ExpenseForm from '@/components/forms/ExpenseForm'
import EditExpenseForm from '@/components/forms/EditExpenseForm'
import DeleteExpenseDialog from '@/components/forms/DeleteExpenseDialog'
import { Edit, Trash2 } from 'lucide-react'
import { expenseApi, categoryApi } from '@/lib/api'
import type { Expense, ExpenseFilters } from '@/types'
import { format } from 'date-fns'
import { ar } from 'date-fns/locale'

export default function Expenses() {
  const [showForm, setShowForm] = useState(false)
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null)
  const [deletingExpense, setDeletingExpense] = useState<Expense | null>(null)
  const [filters, setFilters] = useState<ExpenseFilters>({})
  const [searchTerm, setSearchTerm] = useState('')

  // جلب المصروفات
  const { data: expenses = [], isLoading, error } = useQuery({
    queryKey: ['expenses', filters],
    queryFn: () => expenseApi.getExpenses({
      ...filters,
      q: searchTerm || undefined,
    })
  })

  // جلب الفئات للفلترة
  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: categoryApi.getCategories
  })

  const handleSearch = () => {
    setFilters(prev => ({ ...prev, q: searchTerm }))
  }

  const clearFilters = () => {
    setFilters({})
    setSearchTerm('')
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">جاري تحميل المصروفات...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center text-destructive">
          <p>خطأ في تحميل المصروفات</p>
          <p className="text-sm text-muted-foreground mt-2">
            {error instanceof Error ? error.message : 'خطأ غير معروف'}
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">المصروفات</h1>
          <p className="text-muted-foreground mt-2">
            تتبع وإدارة جميع المصروفات والنفقات
          </p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          ➕ إضافة مصروف
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>قائمة المصروفات</CardTitle>
          
          {/* شريط البحث والفلاتر */}
          <div className="flex flex-wrap gap-4 mt-4">
            {/* البحث */}
            <div className="flex-1 min-w-[200px]">
              <div className="flex gap-2">
                <Input
                  placeholder="البحث في المصروفات..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                />
                <Button onClick={handleSearch}>بحث</Button>
              </div>
            </div>
          </div>

          {/* فلاتر إضافية */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            {/* فلتر الفئة */}
            <select
              value={filters.categoryId || ''}
              onChange={(e) => setFilters(prev => ({
                ...prev,
                categoryId: e.target.value ? parseInt(e.target.value) : undefined
              }))}
              className="w-full p-2 border rounded-md bg-background"
            >
              <option value="">جميع الفئات</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.icon} {category.name}
                </option>
              ))}
            </select>

            {/* فلتر التاريخ من */}
            <Input
              type="date"
              value={filters.from ? new Date(filters.from).toISOString().split('T')[0] : ''}
              onChange={(e) => setFilters(prev => ({
                ...prev,
                from: e.target.value ? new Date(e.target.value).getTime() : undefined
              }))}
              placeholder="من تاريخ"
            />

            {/* فلتر التاريخ إلى */}
            <Input
              type="date"
              value={filters.to ? new Date(filters.to).toISOString().split('T')[0] : ''}
              onChange={(e) => setFilters(prev => ({
                ...prev,
                to: e.target.value ? new Date(e.target.value).getTime() : undefined
              }))}
              placeholder="إلى تاريخ"
            />
          </div>

          {/* أزرار إضافية */}
          <div className="flex gap-2 mt-4">
            <Button variant="outline" onClick={clearFilters}>
              مسح الفلاتر
            </Button>
            <Button variant="outline">
              تصدير CSV
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          {expenses.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">💸</div>
              <h3 className="text-lg font-semibold mb-2">لا توجد مصروفات</h3>
              <p className="mb-4">
                {Object.keys(filters).length > 0 ? 
                  'لا توجد مصروفات تطابق الفلاتر المحددة' : 
                  'لم يتم إضافة أي مصروفات بعد'
                }
              </p>
              <Button onClick={() => setShowForm(true)}>
                إضافة أول مصروف
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-right p-3">التاريخ</th>
                    <th className="text-right p-3">الفئة</th>
                    <th className="text-right p-3">المبلغ</th>
                    <th className="text-right p-3">الضريبة</th>
                    <th className="text-right p-3">الإجمالي</th>
                    <th className="text-right p-3">المرجع</th>
                    <th className="text-right p-3">المورّد</th>
                    <th className="text-center p-3">الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {expenses.map((expense) => (
                    <tr key={expense.id} className="border-b hover:bg-muted/50">
                      <td className="p-3">
                        {format(new Date(expense.date), 'dd/MM/yyyy', { locale: ar })}
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          {expense.category_icon && (
                            <span>{expense.category_icon}</span>
                          )}
                          <span
                            className="w-3 h-3 rounded-full inline-block ml-2"
                            style={{ backgroundColor: expense.category_color }}
                          />
                          <span className="text-sm">{expense.category_name}</span>
                        </div>
                      </td>
                      <td className="p-3 text-right">
                        {expense.amount.toLocaleString()} ريال
                      </td>
                      <td className="p-3 text-right">
                        {expense.tax_rate ? `${expense.tax_rate}%` : '-'}
                      </td>
                      <td className="p-3 text-right font-semibold">
                        {(expense.amount + (expense.amount * (expense.tax_rate || 0) / 100)).toLocaleString()} ريال
                      </td>
                      <td className="p-3">
                        <span className="text-sm text-muted-foreground">
                          {expense.reference || expense.invoice_number || '-'}
                        </span>
                      </td>
                      <td className="p-3">
                        <span className="text-sm">
                          {expense.vendor_name || '-'}
                        </span>
                      </td>
                      <td className="p-3">
                        <div className="flex gap-1 justify-center">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setEditingExpense(expense)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setDeletingExpense(expense)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* نموذج إضافة المصروف */}
      <ExpenseForm
        open={showForm}
        onClose={() => setShowForm(false)}
      />

      {/* نموذج تحرير المصروف */}
      <EditExpenseForm
        expense={editingExpense}
        open={!!editingExpense}
        onClose={() => setEditingExpense(null)}
      />

      {/* حوار حذف المصروف */}
      <DeleteExpenseDialog
        expense={deletingExpense}
        open={!!deletingExpense}
        onClose={() => setDeletingExpense(null)}
      />
    </div>
  )
}
