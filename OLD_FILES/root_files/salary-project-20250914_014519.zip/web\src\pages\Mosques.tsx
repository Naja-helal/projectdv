import React, { useState, useEffect } from 'react';
import { Building2, Plus, Edit, Trash2, Phone, MapPin, Users } from 'lucide-react';
import { DynamicFieldsRenderer, DynamicFieldsDisplay } from '@/components/DynamicFieldsRenderer';

// دالة لتحويل رقم الهاتف إلى رابط واتساب
const formatWhatsAppLink = (phoneNumber: string): string => {
  if (!phoneNumber) return '';
  
  // إزالة المسافات والرموز الخاصة
  let cleanNumber = phoneNumber.replace(/[^\d]/g, '');
  
  // إذا كان الرقم يبدأ بـ 0، استبدله بـ 966
  if (cleanNumber.startsWith('0')) {
    cleanNumber = '966' + cleanNumber.substring(1);
  }
  // إذا لم يكن يبدأ بـ 966، أضفه
  else if (!cleanNumber.startsWith('966')) {
    cleanNumber = '966' + cleanNumber;
  }
  
  return `https://wa.me/${cleanNumber}`;
};

// مكون لعرض رقم الهاتف مع رابط واتساب
const WhatsAppPhoneLink = ({ phone, label }: { phone: string | null; label: string }) => {
  if (!phone) return null;
  
  const whatsappLink = formatWhatsAppLink(phone);
  
  return (
    <div className="flex items-center gap-2 text-gray-600 mb-2">
      <Phone className="h-4 w-4" />
      <span className="text-sm">{label}: </span>
      <a
        href={whatsappLink}
        target="_blank"
        rel="noopener noreferrer"
        className="text-green-600 hover:text-green-800 hover:underline transition-colors text-sm font-medium"
        title={`فتح واتساب مع ${phone}`}
      >
        {phone}
      </a>
    </div>
  );
};

// مكون لعرض الحقول الديناميكية لمسجد معين
function MosqueDynamicFields({ mosqueId }: { mosqueId: number }) {
  const [dynamicData, setDynamicData] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchDynamicData = async () => {
      setLoading(true);
      try {
        const response = await fetch(`http://localhost:5175/dynamic-records/mosques/${mosqueId}`);
        if (response.ok) {
          const data = await response.json();
          setDynamicData(data || {});
        }
      } catch (error) {
        console.error('خطأ في جلب البيانات الديناميكية:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDynamicData();
  }, [mosqueId]);

  if (loading) {
    return (
      <div className="text-xs text-gray-400 mb-2">
        جاري تحميل البيانات الإضافية...
      </div>
    );
  }

  return (
    <DynamicFieldsDisplay 
      pageType="mosques" 
      values={dynamicData}
      className="mb-3"
    />
  );
}

interface Mosque {
  id: number;
  name: string;
  location: string | null;
  imam_phone: string | null;
  guard_phone: string | null;
  created_at: number;
  updated_at: number;
}

export default function Mosques() {
  const [mosques, setMosques] = useState<Mosque[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingMosque, setEditingMosque] = useState<Mosque | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    imam_phone: '',
    guard_phone: ''
  });
  
  // الحقول الديناميكية
  const [dynamicFieldsData, setDynamicFieldsData] = useState<Record<string, any>>({});

  useEffect(() => {
    fetchMosques();
  }, []);

  const fetchMosques = async () => {
    try {
      const response = await fetch('http://localhost:5175/mosques');
      const data = await response.json();
      setMosques(data);
    } catch (error) {
      console.error('خطأ في جلب المساجد:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const url = editingMosque 
        ? `http://localhost:5175/mosques/${editingMosque.id}`
        : 'http://localhost:5175/mosques';
      
      const method = editingMosque ? 'PATCH' : 'POST';
      
      // دمج البيانات الأساسية مع الحقول الديناميكية
      const allData = {
        ...formData,
        dynamic_fields: dynamicFieldsData
      };

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(allData)
      });

      if (response.ok) {
        fetchMosques();
        resetForm();
      } else {
        const errorData = await response.json();
        alert(errorData.error || 'حدث خطأ');
      }
    } catch (error) {
      console.error('خطأ في حفظ المسجد:', error);
      alert('حدث خطأ في الحفظ');
    }
  };

  const handleDelete = async (id: number, name: string) => {
    if (!confirm(`هل تريد حذف المسجد "${name}"؟`)) return;
    
    try {
      const response = await fetch(`http://localhost:5175/mosques/${id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        fetchMosques();
      } else {
        const errorData = await response.json();
        alert(errorData.error || 'حدث خطأ في الحذف');
      }
    } catch (error) {
      console.error('خطأ في حذف المسجد:', error);
      alert('حدث خطأ في الحذف');
    }
  };

  const resetForm = () => {
    setFormData({ name: '', location: '', imam_phone: '', guard_phone: '' });
    setDynamicFieldsData({});
    setEditingMosque(null);
    setShowForm(false);
  };

  const startEdit = async (mosque: Mosque) => {
    setFormData({
      name: mosque.name,
      location: mosque.location || '',
      imam_phone: mosque.imam_phone || '',
      guard_phone: mosque.guard_phone || ''
    });
    
    // جلب البيانات الديناميكية للمسجد
    try {
      const response = await fetch(`http://localhost:5175/dynamic-records/mosques/${mosque.id}`);
      if (response.ok) {
        const dynamicData = await response.json();
        setDynamicFieldsData(dynamicData || {});
      } else {
        setDynamicFieldsData({});
      }
    } catch (error) {
      console.error('خطأ في جلب البيانات الديناميكية:', error);
      setDynamicFieldsData({});
    }
    
    setEditingMosque(mosque);
    setShowForm(true);
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleDateString('ar-SA');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Building2 className="h-8 w-8 text-blue-600" />
          <div>
            <h1 className="text-2xl font-bold text-gray-900">إدارة المساجد</h1>
            <p className="text-gray-600">إدارة بيانات المساجد وتتبع عمليات التوزيع</p>
          </div>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-4 w-4" />
          إضافة مسجد جديد
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6 border-r-4 border-blue-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">إجمالي المساجد</p>
              <p className="text-2xl font-bold text-gray-900">{mosques.length}</p>
            </div>
            <Building2 className="h-8 w-8 text-blue-500" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mosques.map((mosque) => (
          <div key={mosque.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">{mosque.name}</h3>
              <div className="flex gap-2">
                <button
                  onClick={() => startEdit(mosque)}
                  className="text-amber-600 hover:text-amber-800 p-1"
                  title="تعديل"
                >
                  <Edit className="h-4 w-4" />
                </button>
                <button
                  onClick={() => handleDelete(mosque.id, mosque.name)}
                  className="text-red-600 hover:text-red-800 p-1"
                  title="حذف"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
            
            {mosque.location && (
              <div className="flex items-center gap-2 text-gray-600 mb-2">
                <MapPin className="h-4 w-4" />
                <span className="text-sm">{mosque.location}</span>
              </div>
            )}
            
            <WhatsAppPhoneLink phone={mosque.imam_phone} label="إمام" />
            
            {mosque.guard_phone && (
              <div className="flex items-center gap-2 text-gray-600 mb-4">
                <Users className="h-4 w-4" />
                <span className="text-sm">حارس: </span>
                <a
                  href={formatWhatsAppLink(mosque.guard_phone)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-green-600 hover:text-green-800 hover:underline transition-colors text-sm font-medium"
                  title={`فتح واتساب مع ${mosque.guard_phone}`}
                >
                  {mosque.guard_phone}
                </a>
              </div>
            )}
            
            {/* عرض الحقول الديناميكية */}
            <MosqueDynamicFields mosqueId={mosque.id} />
            
            <div className="text-xs text-gray-500 border-t pt-2">
              تم الإضافة: {formatDate(mosque.created_at)}
            </div>
          </div>
        ))}
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <h2 className="text-xl font-bold mb-4">
              {editingMosque ? 'تعديل المسجد' : 'إضافة مسجد جديد'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  اسم المسجد *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  الموقع
                </label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  رقم الإمام
                </label>
                <input
                  type="text"
                  value={formData.imam_phone}
                  onChange={(e) => setFormData({ ...formData, imam_phone: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  رقم الحارس
                </label>
                <input
                  type="text"
                  value={formData.guard_phone}
                  onChange={(e) => setFormData({ ...formData, guard_phone: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              {/* الحقول الديناميكية */}
              <DynamicFieldsRenderer
                pageType="mosques"
                values={dynamicFieldsData}
                onChange={(fieldName, value) => 
                  setDynamicFieldsData(prev => ({ ...prev, [fieldName]: value }))
                }
              />
              
              <div className="flex gap-2 justify-end">
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-4 py-2 text-gray-600 bg-gray-200 rounded-md hover:bg-gray-300"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  {editingMosque ? 'تحديث' : 'إضافة'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
