const Database = require('better-sqlite3');
const db = new Database('./expenses.db');

try {
  console.log('بدء إنشاء النظام الجديد للرواتب...');

  // حذف الجداول القديمة أولاً
  console.log('حذف الجداول القديمة...');
  db.exec(`DROP TABLE IF EXISTS salary_attachments;`);
  db.exec(`DROP TABLE IF EXISTS salary_records;`);
  db.exec(`DROP TABLE IF EXISTS employees;`);

  // إنشاء جدول الموظفين البسيط
  console.log('إنشاء جدول الموظفين الجديد...');
  db.exec(`
    CREATE TABLE employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      position TEXT,
      phone TEXT,
      monthly_salary DECIMAL(10,2) NOT NULL DEFAULT 0,
      hire_date DATE,
      is_active BOOLEAN DEFAULT TRUE,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // إنشاء جدول الرواتب الشهرية البسيط
  console.log('إنشاء جدول الرواتب الشهرية...');
  db.exec(`
    CREATE TABLE monthly_salaries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER NOT NULL,
      month INTEGER NOT NULL CHECK (month >= 1 AND month <= 12),
      year INTEGER NOT NULL,
      salary_amount DECIMAL(10,2) NOT NULL,
      is_delivered BOOLEAN DEFAULT FALSE,
      delivery_date DATE,
      debt_amount DECIMAL(10,2) DEFAULT 0,
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
      UNIQUE(employee_id, month, year)
    );
  `);

  // إنشاء جدول الإعدادات
  console.log('إنشاء جدول الإعدادات...');
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings_new (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      key TEXT UNIQUE NOT NULL,
      value TEXT NOT NULL,
      type TEXT DEFAULT 'string',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // إضافة إعدادات افتراضية
  const insertSetting = db.prepare(`
    INSERT OR REPLACE INTO settings_new (key, value, type) VALUES (?, ?, ?)
  `);

  insertSetting.run('salary_generation_day', '1', 'number'); // اليوم الأول من كل شهر
  insertSetting.run('auto_generate_salaries', 'true', 'boolean');
  insertSetting.run('default_salary_amount', '5000', 'number');

  console.log('إضافة موظفين تجريبيين...');
  const insertEmployee = db.prepare(`
    INSERT INTO employees (name, position, phone, monthly_salary, hire_date)
    VALUES (?, ?, ?, ?, ?)
  `);

  insertEmployee.run('أحمد محمد العلي', 'مدير المشروع', '0501234567', 8000.00, '2024-01-15');
  insertEmployee.run('سارة أحمد الحسن', 'محاسبة', '0509876543', 6000.00, '2024-02-01');
  insertEmployee.run('محمد عبدالله السعيد', 'مطور', '0505551234', 7500.00, '2024-03-10');
  insertEmployee.run('فاطمة علي المحمد', 'مصممة', '0507778899', 5500.00, '2024-04-01');

  console.log('توليد رواتب الشهر الحالي...');
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth() + 1; // الشهر الحالي
  const currentYear = currentDate.getFullYear();

  // الحصول على جميع الموظفين النشطين
  const employees = db.prepare('SELECT * FROM employees WHERE is_active = 1').all();
  
  const insertSalary = db.prepare(`
    INSERT OR IGNORE INTO monthly_salaries 
    (employee_id, month, year, salary_amount)
    VALUES (?, ?, ?, ?)
  `);

  employees.forEach(employee => {
    insertSalary.run(employee.id, currentMonth, currentYear, employee.monthly_salary);
  });

  console.log('✅ تم إنشاء النظام الجديد بنجاح!');

  // عرض النتائج
  const employeesList = db.prepare('SELECT * FROM employees WHERE is_active = 1').all();
  console.log('\n📋 الموظفين:');
  console.table(employeesList);

  const salariesList = db.prepare(`
    SELECT 
      ms.id,
      e.name as employee_name,
      ms.month,
      ms.year,
      ms.salary_amount,
      ms.is_delivered,
      ms.debt_amount,
      ms.delivery_date
    FROM monthly_salaries ms 
    JOIN employees e ON ms.employee_id = e.id 
    ORDER BY ms.year DESC, ms.month DESC, e.name
  `).all();
  console.log('\n💰 الرواتب الشهرية:');
  console.table(salariesList);

  const settingsList = db.prepare('SELECT * FROM settings_new').all();
  console.log('\n⚙️ الإعدادات:');
  console.table(settingsList);

} catch (error) {
  console.error('❌ خطأ:', error.message);
  console.error(error.stack);
} finally {
  db.close();
}