import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { categoryApi } from '@/lib/api'
import type { CreateCategoryData } from '@/types'

interface AddCategoryFormProps {
  open: boolean
  onClose: () => void
}

export default function AddCategoryForm({ open, onClose }: AddCategoryFormProps) {
  const queryClient = useQueryClient()
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    color: '#3b82f6',
    icon: '',
    description: '',
  })

  const createMutation = useMutation({
    mutationFn: (data: CreateCategoryData) => categoryApi.createCategory(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] })
      setFormData({
        name: '',
        code: '',
        color: '#3b82f6',
        icon: '',
        description: '',
      })
      onClose()
    },
    onError: (error) => {
      console.error('خطأ في إنشاء الفئة:', error)
    }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name.trim()) return
    createMutation.mutate(formData)
  }

  if (!open) return null

  const predefinedColors = [
    '#ef4444', '#f97316', '#06b6d4', '#10b981', '#6b7280',
    '#8b5cf6', '#f59e0b', '#ec4899', '#3b82f6', '#84cc16'
  ]

  const predefinedIcons = [
    '👷', '🚚', '🌐', '💰', '📋', '🧱', '🔧', '🚗', '🏪', '📱'
  ]

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
        <h2 className="text-lg font-bold mb-4">إضافة فئة جديدة</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">اسم الفئة *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="مثال: اشتراكات مواقع/هوست"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="code">الرمز (اختياري)</Label>
            <Input
              id="code"
              value={formData.code}
              onChange={(e) => setFormData(prev => ({ ...prev, code: e.target.value }))}
              placeholder="مثال: hosting"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">الوصف (اختياري)</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="وصف مختصر للفئة..."
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label>اللون</Label>
            <div className="flex gap-2 flex-wrap">
              {predefinedColors.map((color) => (
                <button
                  key={color}
                  type="button"
                  className={`w-8 h-8 rounded-full border-2 ${formData.color === color ? 'border-gray-800' : 'border-gray-300'}`}
                  style={{ backgroundColor: color }}
                  onClick={() => setFormData(prev => ({ ...prev, color }))}
                />
              ))}
            </div>
            <Input
              type="color"
              value={formData.color}
              onChange={(e) => setFormData(prev => ({ ...prev, color: e.target.value }))}
              className="w-20 h-10"
            />
          </div>

          <div className="space-y-2">
            <Label>الأيقونة</Label>
            <div className="flex gap-2 flex-wrap">
              {predefinedIcons.map((icon) => (
                <button
                  key={icon}
                  type="button"
                  className={`w-8 h-8 border rounded flex items-center justify-center hover:bg-gray-100 ${formData.icon === icon ? 'bg-gray-200' : ''}`}
                  onClick={() => setFormData(prev => ({ ...prev, icon }))}
                >
                  {icon}
                </button>
              ))}
            </div>
            <Input
              value={formData.icon}
              onChange={(e) => setFormData(prev => ({ ...prev, icon: e.target.value }))}
              placeholder="🏷️"
              maxLength={2}
            />
          </div>

          <div className="flex gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setFormData({
                  name: '',
                  code: '',
                  color: '#3b82f6',
                  icon: '',
                  description: '',
                })
                onClose()
              }}
            >
              إلغاء
            </Button>
            <Button
              type="submit"
              disabled={createMutation.isPending || !formData.name.trim()}
            >
              {createMutation.isPending ? 'جاري الحفظ...' : 'حفظ'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
