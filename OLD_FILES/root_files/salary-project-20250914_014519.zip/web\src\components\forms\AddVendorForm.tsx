import { useForm } from 'react-hook-form'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { vendorApi } from '@/lib/api'
import type { CreateVendorData } from '@/types'

interface AddVendorFormProps {
  open: boolean
  onClose: () => void
}

export default function AddVendorForm({ open, onClose }: AddVendorFormProps) {
  const queryClient = useQueryClient()
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<CreateVendorData>()

  const createMutation = useMutation({
    mutationFn: vendorApi.createVendor,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vendors'] })
      reset()
      onClose()
    },
    onError: (error) => {
      console.error('خطأ في إنشاء المورد:', error)
    }
  })

  const onSubmit = (data: CreateVendorData) => {
    createMutation.mutate(data)
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>إضافة مورد جديد</DialogTitle>
          <DialogDescription>
            أضف مورداً أو مقدم خدمة جديد
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">اسم المورد *</Label>
            <Input
              {...register('name', { required: 'اسم المورد مطلوب' })}
              placeholder="مثال: شركة الاستضافة المتميزة"
            />
            {errors.name && (
              <span className="text-sm text-destructive">{errors.name.message}</span>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">البريد الإلكتروني (اختياري)</Label>
            <Input
              {...register('email')}
              type="email"
              placeholder="contact@company.com"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">رقم الهاتف (اختياري)</Label>
            <Input
              {...register('phone')}
              type="tel"
              placeholder="+966501234567"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">العنوان (اختياري)</Label>
            <Textarea
              {...register('address')}
              placeholder="العنوان..."
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tax_number">الرقم الضريبي (اختياري)</Label>
            <Input
              {...register('tax_number')}
              placeholder="1234567890"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="contact">جهة الاتصال (اختياري)</Label>
            <Input
              {...register('contact')}
              placeholder="اسم الشخص المسؤول..."
            />
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                reset()
                onClose()
              }}
            >
              إلغاء
            </Button>
            <Button
              type="submit"
              disabled={createMutation.isPending}
            >
              {createMutation.isPending ? 'جاري الحفظ...' : 'حفظ'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
