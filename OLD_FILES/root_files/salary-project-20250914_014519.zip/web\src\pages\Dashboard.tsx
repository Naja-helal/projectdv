import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useQuery } from "@tanstack/react-query"
import { statsApi } from "@/lib/api"

// مكون إحصائيات المساجد
function MosqueStatistics() {
  const { data: mosqueStats, isLoading, error } = useQuery({
    queryKey: ['mosque-stats'],
    queryFn: async () => {
      const response = await fetch('http://localhost:5175/mosques-stats')
      if (!response.ok) throw new Error('فشل في جلب إحصائيات المساجد')
      return await response.json()
    }
  })

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-right">إحصائيات المساجد</CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-sm text-muted-foreground">جاري التحميل...</p>
        </CardContent>
      </Card>
    )
  }

  if (error || !mosqueStats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-right">إحصائيات المساجد</CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <div className="text-destructive">
            <p>خطأ في تحميل البيانات</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-right">إحصائيات المساجد والتوزيع</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* عدد المساجد */}
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-primary mb-2">
              {mosqueStats.totalMosques}
            </div>
            <div className="text-sm text-muted-foreground">إجمالي المساجد</div>
          </CardContent>
        </Card>

        {/* إجمالي التصوير */}
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">
              {mosqueStats.totalTasweer}
            </div>
            <div className="text-sm text-muted-foreground">إجمالي التصوير</div>
          </CardContent>
        </Card>

        {/* إجمالي التصريف */}
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {mosqueStats.totalTasreef}
            </div>
            <div className="text-sm text-muted-foreground">إجمالي التصريف</div>
          </CardContent>
        </Card>
      </div>

      {/* أكثر المساجد نشاطاً */}
      {mosqueStats.topMosques && mosqueStats.topMosques.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-right">أكثر المساجد نشاطاً في التوزيع</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mosqueStats.topMosques.map((mosque: any, index: number) => (
                <div key={mosque.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </div>
                    <div className="text-right">
                      <div className="font-medium">{mosque.name}</div>
                      <div className="text-sm text-muted-foreground">{mosque.location}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold">{mosque.total_distributions}</div>
                    <div className="text-sm text-muted-foreground">توزيع</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* أزرار الانتقال السريع */}
      <div className="flex gap-4 justify-center">
        <Button
          onClick={() => window.location.href = '/mosques'}
          className="flex items-center gap-2"
        >
          <span>إدارة المساجد</span>
          🕌
        </Button>
        <Button
          variant="outline"
          onClick={() => window.location.href = '/distributions'}
          className="flex items-center gap-2"
        >
          <span>إدارة التوزيع</span>
          📦
        </Button>
      </div>
    </div>
  )
}

export default function Dashboard() {
  const { data: stats, isLoading, error } = useQuery({
    queryKey: ['stats'],
    queryFn: () => statsApi.getStats()
  })



  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">جاري تحميل الإحصائيات...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center text-destructive">
          <p>خطأ في تحميل الإحصائيات</p>
          <p className="text-sm text-muted-foreground mt-2">
            {error instanceof Error ? error.message : 'خطأ غير معروف'}
          </p>
        </div>
      </div>
    )
  }

  if (!stats) return null

  return (
    <div className="space-y-6">
      {/* الترحيب */}
      <div>
        <h1 className="text-3xl font-bold">لوحة التحكم</h1>
        <p className="text-muted-foreground mt-2">
          نظرة عامة على المصروفات والإحصائيات
        </p>
      </div>

      {/* إجمالي الإحصائيات */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              عدد المصروفات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total.count}</div>
            <p className="text-xs text-muted-foreground">إجمالي العمليات</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              المبلغ الأساسي
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.total.subtotal.toLocaleString()} {stats.currency}
            </div>
            <p className="text-xs text-muted-foreground">قبل الضريبة</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              الضريبة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.total.tax.toLocaleString()} {stats.currency}
            </div>
            <p className="text-xs text-muted-foreground">
              {stats.total.subtotal > 0 ? 
                `${((stats.total.tax / stats.total.subtotal) * 100).toFixed(1)}%` : 
                '0%'
              }
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              الإجمالي النهائي
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {stats.total.total.toLocaleString()} {stats.currency}
            </div>
            <p className="text-xs text-muted-foreground">شامل الضريبة</p>
          </CardContent>
        </Card>
      </div>

      {/* المصروفات حسب الفئة */}
      {stats.byCategory.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>المصروفات حسب الفئة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats.byCategory.map((category) => (
                <div
                  key={category.name}
                  className="flex items-center justify-between p-3 rounded-lg border"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: category.color }}
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span>{category.icon}</span>
                        <span className="font-medium">{category.name}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {category.count} عملية
                      </p>
                    </div>
                  </div>
                  <div className="text-left">
                    <div className="font-semibold">
                      {category.total.toLocaleString()} {stats.currency}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {stats.total.total > 0 ? 
                        `${((category.total / stats.total.total) * 100).toFixed(1)}%` : 
                        '0%'
                      }
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* رسالة عدم وجود بيانات */}
      {stats.total.count === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <div className="text-6xl mb-4">📊</div>
            <h3 className="text-lg font-semibold mb-2">لا توجد مصروفات بعد</h3>
            <p className="text-muted-foreground mb-4">
              ابدأ بإضافة أول مصروف لرؤية الإحصائيات هنا
            </p>
            <Button
              onClick={() => window.location.href = '/expenses'}
            >
              إضافة مصروف
            </Button>
          </CardContent>
        </Card>
      )}

      {/* إحصائيات المساجد */}
      <MosqueStatistics />
    </div>
  )
}
