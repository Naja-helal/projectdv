import { useForm } from 'react-hook-form'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { projectApi } from '@/lib/api'
import type { CreateProjectData } from '@/types'

interface AddProjectFormProps {
  open: boolean
  onClose: () => void
}

export default function AddProjectForm({ open, onClose }: AddProjectFormProps) {
  const queryClient = useQueryClient()
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<CreateProjectData>()

  const createMutation = useMutation({
    mutationFn: projectApi.createProject,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] })
      reset()
      onClose()
    },
    onError: (error) => {
      console.error('خطأ في إنشاء المشروع:', error)
    }
  })

  const onSubmit = (data: CreateProjectData) => {
    createMutation.mutate(data)
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>إضافة مشروع جديد</DialogTitle>
          <DialogDescription>
            أنشئ مشروعًا جديدًا لتنظيم المصروفات
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">اسم المشروع *</Label>
            <Input
              {...register('name', { required: 'اسم المشروع مطلوب' })}
              placeholder="مثال: تطوير موقع الشركة"
            />
            {errors.name && (
              <span className="text-sm text-destructive">{errors.name.message}</span>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="code">رمز المشروع (اختياري)</Label>
            <Input
              {...register('code')}
              placeholder="مثال: web-2024"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">وصف المشروع (اختياري)</Label>
            <Textarea
              {...register('description')}
              placeholder="وصف مختصر للمشروع..."
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                reset()
                onClose()
              }}
            >
              إلغاء
            </Button>
            <Button
              type="submit"
              disabled={createMutation.isPending}
            >
              {createMutation.isPending ? 'جاري الحفظ...' : 'حفظ'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
