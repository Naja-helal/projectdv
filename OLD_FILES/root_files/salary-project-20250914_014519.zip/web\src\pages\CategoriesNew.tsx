import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import AddCategoryForm from '@/components/forms/AddCategoryForm'
import EditCategoryForm from '@/components/forms/EditCategoryForm'
import DeleteCategoryDialog from '@/components/forms/DeleteCategoryDialog'
import { Edit, Trash2, Plus } from 'lucide-react'
import { categoryApi } from '@/lib/api'
import type { Category } from '@/types'

export default function CategoriesPage() {
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  const [deletingCategory, setDeletingCategory] = useState<Category | null>(null)

  const { data: categories, isLoading, error } = useQuery({
    queryKey: ['categories'],
    queryFn: categoryApi.getCategories
  })

  if (isLoading) return <div className="p-6">جاري التحميل...</div>
  if (error) return <div className="p-6 text-red-500">خطأ في تحميل البيانات</div>

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">الفئات</h1>
        <Button onClick={() => setShowAddForm(true)}>
          <Plus className="ml-2 h-4 w-4" />
          إضافة فئة جديدة
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {categories?.map((category) => (
          <Card key={category.id} className="relative">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {category.icon && (
                    <span className="text-xl">{category.icon}</span>
                  )}
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: category.color }}
                  />
                  <CardTitle className="text-lg">{category.name}</CardTitle>
                </div>
                
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setEditingCategory(category)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setDeletingCategory(category)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              {category.code && (
                <p className="text-sm text-muted-foreground mb-2">
                  الرمز: {category.code}
                </p>
              )}
              {category.description && (
                <p className="text-sm">{category.description}</p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* نموذج إضافة فئة جديدة */}
      <AddCategoryForm
        open={showAddForm}
        onClose={() => setShowAddForm(false)}
      />

      {/* نموذج تحرير الفئة */}
      <EditCategoryForm
        category={editingCategory}
        open={!!editingCategory}
        onClose={() => setEditingCategory(null)}
      />

      {/* حوار حذف الفئة */}
      <DeleteCategoryDialog
        category={deletingCategory}
        open={!!deletingCategory}
        onClose={() => setDeletingCategory(null)}
      />
    </div>
  )
}
