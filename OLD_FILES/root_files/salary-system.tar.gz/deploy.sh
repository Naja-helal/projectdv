#!/bin/bash

# سكريبت نشر المشروع على السيرفر
# Deploy script for salary management system

echo "🚀 بدء عملية النشر..."

# متغيرات السيرفر
SERVER_USER="root"
SERVER_HOST="91.108.112.8"
SERVER_PATH="/var/www/soqiamakkah.com/apps/salary"
DOMAIN="https://salary.soqiamakkah.com"

# إنشاء مجلد النسخ الاحتياطي
BACKUP_DIR="backup_$(date +%Y%m%d_%H%M%S)"

echo "📦 تحضير الملفات للرفع..."

# تنظيف ملفات التطوير
rm -rf node_modules/
rm -rf server/node_modules/
rm -rf web/node_modules/
rm -rf web/dist/
rm -rf server/dist/

# إنشاء أرشيف المشروع
echo "📁 إنشاء أرشيف المشروع..."
tar -czf salary-project.tar.gz \
    --exclude='.git' \
    --exclude='node_modules' \
    --exclude='*.log' \
    --exclude='.env.local' \
    --exclude='dist' \
    .

echo "📤 رفع المشروع للسيرفر..."

# رفع الملف المضغوط
scp salary-project.tar.gz $SERVER_USER@$SERVER_HOST:/tmp/

echo "🔧 تنصيب المشروع على السيرفر..."

# تنفيذ أوامر التنصيب على السيرفر
ssh $SERVER_USER@$SERVER_HOST << 'ENDSSH'
    # الذهاب لمجلد المشروع
    cd /var/www/soqiamakkah.com/apps/salary

    # إنشاء نسخة احتياطية إذا كان المشروع موجود
    if [ -d "server" ] || [ -d "web" ]; then
        echo "📋 إنشاء نسخة احتياطية..."
        BACKUP_DIR="backup_$(date +%Y%m%d_%H%M%S)"
        mkdir -p $BACKUP_DIR
        mv server web package.json $BACKUP_DIR/ 2>/dev/null || true
    fi

    # استخراج المشروع الجديد
    echo "📦 استخراج المشروع..."
    tar -xzf /tmp/salary-project.tar.gz

    # تنصيب المكتبات للمشروع الرئيسي
    echo "📚 تنصيب مكتبات المشروع الرئيسي..."
    npm install

    # تنصيب مكتبات الخادم
    echo "🖥️  تنصيب مكتبات الخادم..."
    cd server
    npm install

    # بناء الخادم
    echo "🔨 بناء الخادم..."
    npm run build

    # العودة للمجلد الرئيسي وتنصيب مكتبات الواجهة
    cd ../web
    echo "🌐 تنصيب مكتبات الواجهة..."
    npm install

    # بناء الواجهة للإنتاج
    echo "🎨 بناء الواجهة..."
    npm run build

    # العودة للمجلد الرئيسي
    cd ..

    echo "✅ تم تنصيب المشروع بنجاح!"
    echo "🔗 الموقع متاح على: https://salary.soqiamakkah.com"

ENDSSH

# تنظيف الملف المؤقت
rm salary-project.tar.gz

echo "🎉 تمت عملية النشر بنجاح!"
echo "🌐 يمكنك الوصول للموقع عبر: $DOMAIN"