import { Link, useLocation } from 'react-router-dom'
import { ReactNode } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { Button } from '@/components/ui/button'
import { LogOut } from 'lucide-react'

interface LayoutProps {
  children: ReactNode
}

const navigation = [
  { name: 'لوحة التحكم', href: '/', icon: '📊' },
  { name: 'التقارير والإحصائيات', href: '/reports', icon: '📈' },
  { name: 'المصروفات', href: '/expenses', icon: '💰' },
  { name: 'البرماوي', href: '/bramawi', icon: '📋' },
  { name: 'المساجد', href: '/mosques', icon: '🕌' },
  { name: 'التوزيع', href: '/distributions', icon: '📦' },
  { name: 'الموظفين', href: '/employees', icon: '👥' },
  { name: 'الرواتب', href: '/salaries', icon: '💸' },
  // { name: 'الرواتب القديمة', href: '/salaries-old', icon: '📜' },
  { name: 'الحقول الديناميكية', href: '/dynamic-fields', icon: '🔧' },
  { name: 'الفئات', href: '/categories', icon: '🏷️' },
  { name: 'المورّدين', href: '/vendors', icon: '🏪' },
  { name: 'الإعدادات', href: '/settings', icon: '⚙️' },
]

export default function Layout({ children }: LayoutProps) {
  const location = useLocation()
  const { logout } = useAuth()

  const handleLogout = () => {
    logout()
    window.location.href = '/login'
  }

  return (
    <div className="min-h-screen bg-background">
      {/* الشريط العلوي */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="text-2xl">💼</div>
              <div>
                <h1 className="text-xl font-bold">نظام إدارة المصروفات</h1>
                <p className="text-sm text-muted-foreground">إدارة مصروفات المشاريع</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-sm text-muted-foreground">
                {new Date().toLocaleDateString('ar-SA', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* الشريط الجانبي */}
        <aside className="w-64 min-h-screen border-l bg-card">
          <nav className="p-4">
            <ul className="space-y-2">
              {navigation.map((item) => {
                const isActive = location.pathname === item.href
                return (
                  <li key={item.href}>
                    <Link
                      to={item.href}
                      className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${
                        isActive
                          ? 'bg-primary text-primary-foreground'
                          : 'hover:bg-muted text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      <span className="text-lg">{item.icon}</span>
                      {item.name}
                    </Link>
                  </li>
                )
              })}
            </ul>
          </nav>
        </aside>

        {/* المحتوى الرئيسي */}
        <main className="flex-1 p-6">
          <div className="container mx-auto max-w-7xl">
            {children}
          </div>
        </main>
      </div>
    </div>
  )
}
