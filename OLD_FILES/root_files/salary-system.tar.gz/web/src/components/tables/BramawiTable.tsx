import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { bramawiApi } from '@/lib/api'
import type { BramawiRecord, BramawiField } from '@/types'
import { Trash2, Check, X, Calendar, Edit } from 'lucide-react'
import { format } from 'date-fns'
import { ar } from 'date-fns/locale'

interface BramawiTableProps {
  records: BramawiRecord[]
  fields: BramawiField[]
  status: 'paid' | 'unpaid'
  isLoading: boolean
  onEditRecord?: (record: BramawiRecord) => void
}

export default function BramawiTable({ records, fields, status, isLoading, onEditRecord }: BramawiTableProps) {
  const [selectedRecords, setSelectedRecords] = useState<number[]>([])
  
  const queryClient = useQueryClient()

  // تحديث حالة الدفع
  const updatePaymentMutation = useMutation({
    mutationFn: ({ recordIds, status, paymentDate }: { recordIds: number[], status: 'paid' | 'unpaid', paymentDate?: number }) =>
      bramawiApi.updatePaymentStatus(recordIds, status, paymentDate),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bramawi-records'] })
      setSelectedRecords([])
    }
  })

  // حذف السجلات
  const deleteMutation = useMutation({
    mutationFn: (id: number) => bramawiApi.deleteRecord(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bramawi-records'] })
      setSelectedRecords([])
    }
  })

  // تحديد/إلغاء تحديد سجل
  const toggleSelection = (recordId: number) => {
    setSelectedRecords(prev => 
      prev.includes(recordId) 
        ? prev.filter(id => id !== recordId)
        : [...prev, recordId]
    )
  }

  // تحديد/إلغاء تحديد الكل
  const toggleSelectAll = () => {
    setSelectedRecords(prev => 
      prev.length === records.length 
        ? [] 
        : records.map(record => record.id)
    )
  }

  // تغيير حالة الدفع للمحددين
  const handlePaymentStatusChange = (newStatus: 'paid' | 'unpaid') => {
    if (selectedRecords.length === 0) return
    
    const paymentDate = newStatus === 'paid' ? Date.now() : undefined
    updatePaymentMutation.mutate({
      recordIds: selectedRecords,
      status: newStatus,
      paymentDate
    })
  }

  // حذف السجل
  const handleDelete = (record: BramawiRecord) => {
    if (confirm('هل أنت متأكد من حذف هذا السجل؟')) {
      deleteMutation.mutate(record.id)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  if (records.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <div className="text-4xl mb-4">
          {status === 'paid' ? '💰' : '⏳'}
        </div>
        <h3 className="text-lg font-semibold mb-2">
          {status === 'paid' ? 'لا توجد مدفوعات' : 'لا توجد مستحقات'}
        </h3>
        <p>
          {status === 'paid' 
            ? 'لم يتم تسجيل أي دفعات بعد' 
            : 'جميع المستحقات مدفوعة أو لا توجد بيانات مسجلة'
          }
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4" dir="rtl">
      {/* أزرار التحكم */}
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            {selectedRecords.length > 0 && `${selectedRecords.length} محدد`}
          </span>
          <Button 
            onClick={toggleSelectAll} 
            variant="outline" 
            size="sm"
            disabled={records.length === 0}
          >
            {selectedRecords.length === records.length ? 'إلغاء تحديد الكل' : 'تحديد الكل'}
          </Button>
        </div>
        
        {selectedRecords.length > 0 && (
          <div className="flex gap-2">
            {status === 'unpaid' && (
              <Button 
                onClick={() => handlePaymentStatusChange('paid')}
                disabled={updatePaymentMutation.isPending}
                className="bg-green-600 hover:bg-green-700"
                size="sm"
              >
                تحديد كمدفوع ({selectedRecords.length})
                <Check className="h-4 w-4 mr-2" />
              </Button>
            )}
            
            {status === 'paid' && (
              <Button 
                onClick={() => handlePaymentStatusChange('unpaid')}
                disabled={updatePaymentMutation.isPending}
                className="bg-orange-600 hover:bg-orange-700"
                size="sm"
              >
                تحديد كغير مدفوع ({selectedRecords.length})
                <X className="h-4 w-4 mr-2" />
              </Button>
            )}
          </div>
        )}
      </div>

      {/* الجدول */}
      <div className="overflow-x-auto" dir="rtl">
        <table className="w-full border-collapse" dir="rtl" style={{ direction: 'rtl' }}>
          <thead>
            <tr className="border-b">
              <th className="text-center p-3 w-12">
                <input
                  type="checkbox"
                  checked={selectedRecords.length === records.length && records.length > 0}
                  onChange={toggleSelectAll}
                  className="rounded border-gray-300"
                />
              </th>
              <th className="text-center p-3 font-semibold">التاريخ</th>
              {fields.map(field => (
                <th key={field.id} className="text-center p-3 font-semibold">
                  {field.label}
                </th>
              ))}
              <th className="text-center p-3 font-semibold">الحالة</th>
              <th className="text-center p-3 font-semibold">الملاحظات</th>
              <th className="text-center p-3">الإجراءات</th>
            </tr>
          </thead>
          <tbody>
            {records.map((record) => (
              <tr key={record.id} className="border-b hover:bg-muted/50">
                <td className="text-center p-3">
                  <input
                    type="checkbox"
                    checked={selectedRecords.includes(record.id)}
                    onChange={() => toggleSelection(record.id)}
                    className="rounded border-gray-300"
                  />
                </td>
                <td className="p-3 text-sm text-center">
                  <div>
                    {format(new Date(record.created_at), 'dd/MM/yyyy', { locale: ar })}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {format(new Date(record.created_at), 'HH:mm')}
                  </div>
                </td>
                {fields.map(field => (
                  <td key={field.id} className="p-3 text-center">
                    <div className="text-sm">
                      {record.values?.[field.name] ? (
                        field.type === 'calculated' || field.type === 'number' ? (
                          <span className="font-mono font-semibold">
                            {parseFloat(record.values[field.name].value).toLocaleString('en-US')}
                          </span>
                        ) : field.type === 'date' ? (
                          format(new Date(record.values[field.name].value), 'dd/MM/yyyy', { locale: ar })
                        ) : (
                          record.values[field.name].value
                        )
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </div>
                  </td>
                ))}
                <td className="p-3 text-center">
                  <Badge variant={record.payment_status === 'paid' ? 'default' : 'secondary'} dir="rtl">
                    {record.payment_status === 'paid' ? (
                      <div className="flex items-center gap-1">
                        <Check className="h-3 w-3" />
                        مدفوع
                      </div>
                    ) : (
                      <div className="flex items-center gap-1">
                        <X className="h-3 w-3" />
                        غير مدفوع
                      </div>
                    )}
                  </Badge>
                  {record.payment_date && (
                    <div className="text-xs text-muted-foreground mt-1 flex items-center gap-1 justify-center" dir="rtl">
                      <Calendar className="h-3 w-3" />
                      {format(new Date(record.payment_date), 'dd/MM/yyyy', { locale: ar })}
                    </div>
                  )}
                </td>
                <td className="p-3 text-sm text-muted-foreground text-center">
                  {record.notes || '-'}
                </td>
                <td className="p-3">
                  <div className="flex gap-1 justify-center">
                    {onEditRecord && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => onEditRecord(record)}
                        title="تعديل"
                      >
                        <Edit className="h-4 w-4 text-blue-600" />
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(record)}
                      title="حذف"
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
