import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { projectApi } from '@/lib/api'
import type { Project, CreateProjectData } from '@/types'

interface EditProjectFormProps {
  project: Project | null
  open: boolean
  onClose: () => void
}

export default function EditProjectForm({ project, open, onClose }: EditProjectFormProps) {
  const queryClient = useQueryClient()
  
  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<CreateProjectData>({
    defaultValues: {
      name: project?.name || '',
      code: project?.code || '',
      description: project?.description || '',
    }
  })

  // تحديث القيم عند تغيير المشروع
  useEffect(() => {
    if (project) {
      setValue('name', project.name)
      setValue('code', project.code || '')
      setValue('description', project.description || '')
    }
  }, [project, setValue])

  // mutation لتحديث المشروع
  const updateMutation = useMutation({
    mutationFn: (data: CreateProjectData) => 
      projectApi.updateProject(project!.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] })
      reset()
      onClose()
    },
    onError: (error) => {
      console.error('خطأ في تحديث المشروع:', error)
    }
  })

  const onSubmit = (data: CreateProjectData) => {
    if (!project) return
    updateMutation.mutate(data)
  }

  if (!project) return null

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>تحرير المشروع</DialogTitle>
          <DialogDescription>
            تحديث تفاصيل مشروع "{project.name}"
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">اسم المشروع *</Label>
            <Input
              {...register('name', { required: 'اسم المشروع مطلوب' })}
              placeholder="مثال: تطوير موقع الشركة"
            />
            {errors.name && (
              <span className="text-sm text-destructive">{errors.name.message}</span>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="code">رمز المشروع (اختياري)</Label>
            <Input
              {...register('code')}
              placeholder="مثال: company-website"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">وصف المشروع (اختياري)</Label>
            <Textarea
              {...register('description')}
              placeholder="وصف مختصر للمشروع..."
              rows={3}
            />
          </div>



          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                reset()
                onClose()
              }}
            >
              إلغاء
            </Button>
            <Button
              type="submit"
              disabled={updateMutation.isPending}
            >
              {updateMutation.isPending ? 'جاري الحفظ...' : 'حفظ التغييرات'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
