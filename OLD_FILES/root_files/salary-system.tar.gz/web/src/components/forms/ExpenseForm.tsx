import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { expenseApi, categoryApi, vendorApi } from '@/lib/api'
import type { CreateExpenseData } from '@/types'

interface ExpenseFormProps {
  open: boolean
  onClose: () => void
}

interface FormData {
  categoryId: string
  vendorId: string
  amount: string
  taxRate: string
  date: string
  paymentMethod: string
  reference: string
  invoiceNumber: string
  notes: string
}

export default function ExpenseForm({ open, onClose }: ExpenseFormProps) {
  const [customFieldsData, setCustomFieldsData] = useState<Record<string, string>>({})
  const queryClient = useQueryClient()
  
  const { register, handleSubmit, reset, watch, formState: { errors } } = useForm<FormData>({
    defaultValues: {
      categoryId: '',
      vendorId: '',
      amount: '',
      taxRate: '0',
      date: new Date().toISOString().split('T')[0],
      paymentMethod: '',
      reference: '',
      invoiceNumber: '',
      notes: '',
    }
  })

  // جلب البيانات المرجعية
  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: categoryApi.getCategories
  })

  const { data: vendors = [] } = useQuery({
    queryKey: ['vendors'],
    queryFn: vendorApi.getVendors
  })

  // mutation لإضافة المصروف
  const createMutation = useMutation({
    mutationFn: (data: CreateExpenseData) => expenseApi.createExpense(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses'] })
      queryClient.invalidateQueries({ queryKey: ['stats'] })
      reset()
      setCustomFieldsData({})
      onClose()
    },
    onError: (error) => {
      console.error('خطأ في إضافة المصروف:', error)
    }
  })

  const onSubmit = (data: FormData) => {
    const expenseData: CreateExpenseData = {
      categoryId: parseInt(data.categoryId),
      vendorId: data.vendorId ? parseInt(data.vendorId) : undefined,
      amount: parseFloat(data.amount),
      taxRate: parseFloat(data.taxRate),
      date: new Date(data.date).getTime(),
      paymentMethod: data.paymentMethod || undefined,
      reference: data.reference || undefined,
      invoiceNumber: data.invoiceNumber || undefined,
      notes: data.notes || undefined,
      customFields: Object.keys(customFieldsData).length > 0 ? customFieldsData : undefined,
    }

    createMutation.mutate(expenseData)
  }

  const watchedAmount = watch('amount')
  const watchedTaxRate = watch('taxRate')
  
  // حساب الضريبة والإجمالي
  const amount = parseFloat(watchedAmount) || 0
  const taxRate = parseFloat(watchedTaxRate) || 0
  const taxAmount = (amount * taxRate / 100)
  const totalAmount = amount + taxAmount

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>إضافة مصروف جديد</DialogTitle>
          <DialogDescription>
            أدخل تفاصيل المصروف الجديد
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {/* الحقول الأساسية */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* الفئة */}
            <div className="space-y-2">
              <Label htmlFor="categoryId">الفئة *</Label>
              <select
                {...register('categoryId', { required: 'الفئة مطلوبة' })}
                className="w-full p-2 border rounded-md bg-background"
              >
                <option value="">اختر الفئة</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.icon} {category.name}
                  </option>
                ))}
              </select>
              {errors.categoryId && (
                <span className="text-sm text-destructive">{errors.categoryId.message}</span>
              )}
            </div>

            {/* المبلغ */}
            <div className="space-y-2">
              <Label htmlFor="amount">المبلغ (ريال) *</Label>
              <Input
                {...register('amount', { required: 'المبلغ مطلوب', min: { value: 0.01, message: 'يجب أن يكون المبلغ أكبر من صفر' } })}
                type="number"
                step="0.01"
                placeholder="0.00"
              />
              {errors.amount && (
                <span className="text-sm text-destructive">{errors.amount.message}</span>
              )}
            </div>

            {/* معدل الضريبة */}
            <div className="space-y-2">
              <Label htmlFor="taxRate">معدل الضريبة (%)</Label>
              <Input
                {...register('taxRate')}
                type="number"
                step="0.01"
                placeholder="0"
              />
            </div>

            {/* التاريخ */}
            <div className="space-y-2">
              <Label htmlFor="date">التاريخ *</Label>
              <Input
                {...register('date', { required: 'التاريخ مطلوب' })}
                type="date"
              />
              {errors.date && (
                <span className="text-sm text-destructive">{errors.date.message}</span>
              )}
            </div>

            {/* المورّد */}
            <div className="space-y-2">
              <Label htmlFor="vendorId">المورّد</Label>
              <select
                {...register('vendorId')}
                className="w-full p-2 border rounded-md bg-background"
              >
                <option value="">بدون مورّد</option>
                {vendors.map((vendor) => (
                  <option key={vendor.id} value={vendor.id}>
                    {vendor.name}
                  </option>
                ))}
              </select>
            </div>

            {/* طريقة الدفع */}
            <div className="space-y-2">
              <Label htmlFor="paymentMethod">طريقة الدفع</Label>
              <select
                {...register('paymentMethod')}
                className="w-full p-2 border rounded-md bg-background"
              >
                <option value="">اختر طريقة الدفع</option>
                <option value="نقدي">نقدي</option>
                <option value="بنك">تحويل بنكي</option>
                <option value="شيك">شيك</option>
                <option value="بطاقة ائتمان">بطاقة ائتمان</option>
                <option value="محفظة إلكترونية">محفظة إلكترونية</option>
              </select>
            </div>

            {/* المرجع */}
            <div className="space-y-2">
              <Label htmlFor="reference">المرجع</Label>
              <Input
                {...register('reference')}
                placeholder="رقم المرجع أو الشيك"
              />
            </div>

            {/* رقم الفاتورة */}
            <div className="space-y-2">
              <Label htmlFor="invoiceNumber">رقم الفاتورة</Label>
              <Input
                {...register('invoiceNumber')}
                placeholder="رقم الفاتورة"
              />
            </div>
          </div>

          {/* الملاحظات */}
          <div className="space-y-2">
            <Label htmlFor="notes">الملاحظات</Label>
            <Textarea
              {...register('notes')}
              placeholder="أي ملاحظات إضافية..."
              rows={3}
            />
          </div>

          {/* تم تعطيل الحقول المخصصة من الظهور في فورم المصروفات */}

          {/* ملخص الحساب */}
          {amount > 0 && (
            <div className="bg-muted p-4 rounded-lg space-y-2">
              <h4 className="font-medium">ملخص الحساب</h4>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">المبلغ الأساسي:</span>
                  <div className="font-medium">{amount.toFixed(2)} ريال</div>
                </div>
                <div>
                  <span className="text-muted-foreground">الضريبة ({taxRate}%):</span>
                  <div className="font-medium">{taxAmount.toFixed(2)} ريال</div>
                </div>
                <div>
                  <span className="text-muted-foreground">الإجمالي:</span>
                  <div className="font-semibold text-primary">{totalAmount.toFixed(2)} ريال</div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                reset()
                setCustomFieldsData({})
                onClose()
              }}
            >
              إلغاء
            </Button>
            <Button
              type="submit"
              disabled={createMutation.isPending}
            >
              {createMutation.isPending ? 'جاري الحفظ...' : 'حفظ المصروف'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
