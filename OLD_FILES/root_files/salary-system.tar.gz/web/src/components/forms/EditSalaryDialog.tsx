import React, { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../ui/dialog"
import { Button } from "../ui/button"
import { Input } from "../ui/input"
import { Label } from "../ui/label"
import { Textarea } from "../ui/textarea"
import { salariesApi } from '@/lib/api'
import type { MonthlySalary } from '@/types'
import { formatCurrency } from '@/lib/utils'

interface EditSalaryDialogProps {
  salary: MonthlySalary | null
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function EditSalaryDialog({ salary, open, onOpenChange }: EditSalaryDialogProps) {
  const [formData, setFormData] = useState({
    salary_amount: salary?.salary_amount || 0,
    notes: salary?.notes || ''
  })

  const queryClient = useQueryClient()

  const updateMutation = useMutation({
    mutationFn: (data: { salary_amount: number; notes?: string }) =>
      salariesApi.update(salary!.id!, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['salaries'] })
      onOpenChange(false)
      alert('تم تحديث الراتب بنجاح')
    },
    onError: (error) => {
      console.error('خطأ في تحديث الراتب:', error)
      alert('حدث خطأ في تحديث الراتب')
    }
  })

  const deleteMutation = useMutation({
    mutationFn: () => salariesApi.delete(salary!.id!),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['salaries'] })
      onOpenChange(false)
      alert('تم حذف الراتب بنجاح')
    },
    onError: (error) => {
      console.error('خطأ في حذف الراتب:', error)
      alert('حدث خطأ في حذف الراتب')
    }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (formData.salary_amount <= 0) {
      alert('يجب أن يكون مبلغ الراتب أكبر من صفر')
      return
    }

    console.log('تحديث الراتب:', {
      id: salary?.id,
      oldAmount: salary?.salary_amount,
      newAmount: formData.salary_amount
    })

    updateMutation.mutate({
      salary_amount: formData.salary_amount,
      notes: formData.notes || undefined
    })
  }

  const handleDelete = () => {
    if (window.confirm('هل أنت متأكد من حذف هذا الراتب؟ لا يمكن التراجع عن هذا الإجراء.')) {
      deleteMutation.mutate()
    }
  }

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  // تحديث البيانات عندما يتغير الراتب المحدد
  React.useEffect(() => {
    if (salary) {
      setFormData({
        salary_amount: salary.salary_amount,
        notes: salary.notes || ''
      })
    }
  }, [salary])

  if (!salary) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>تعديل راتب {salary.employee_name}</DialogTitle>
          <div className="text-sm text-gray-600">
            {salary.month}/{salary.year} - {salary.is_delivered ? 'مُسلم' : 'غير مُسلم'}
          </div>
          <div className="text-xs text-blue-600 bg-blue-50 p-2 rounded">
            يمكنك تعديل مبلغ الراتب لهذا الشهر مباشرة هنا
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="salary_amount">مبلغ الراتب الجديد *</Label>
            <Input
              id="salary_amount"
              type="number"
              min="1"
              step="0.01"
              value={formData.salary_amount}
              onChange={(e) => handleChange('salary_amount', parseFloat(e.target.value) || 0)}
              placeholder="مبلغ الراتب الجديد"
              required
              className="text-lg font-semibold"
            />
            <div className="flex justify-between text-xs">
              <span className="text-gray-500">المبلغ الأصلي: {formatCurrency(salary.salary_amount)}</span>
              {formData.salary_amount !== salary.salary_amount && (
                <span className="text-green-600 font-medium">
                  التغيير: {formatCurrency(formData.salary_amount - salary.salary_amount)}
                </span>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">ملاحظات</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => handleChange('notes', e.target.value)}
              placeholder="أي ملاحظات إضافية..."
              rows={3}
            />
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button
              type="submit"
              disabled={updateMutation.isPending}
              className="flex-1"
            >
              {updateMutation.isPending ? 'جاري الحفظ...' : 'حفظ التعديلات'}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={updateMutation.isPending}
            >
              إلغاء
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              {deleteMutation.isPending ? 'جاري الحذف...' : 'حذف'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}