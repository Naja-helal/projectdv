import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Plus, Edit, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import AddProjectForm from '@/components/forms/AddProjectForm'
import EditProjectForm from '@/components/forms/EditProjectForm'
import DeleteProjectDialog from '@/components/forms/DeleteProjectDialog'
import { projectApi } from '@/lib/api'
import type { Project } from '@/types'

export default function ProjectsPage() {
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingProject, setEditingProject] = useState<Project | null>(null)
  const [deletingProject, setDeletingProject] = useState<Project | null>(null)

  const { data: projects = [], isLoading } = useQuery({
    queryKey: ['projects'],
    queryFn: projectApi.getProjects
  })

  if (isLoading) {
    return <div className="p-6">جاري تحميل المشاريع...</div>
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">إدارة المشاريع</h1>
          <p className="text-muted-foreground">
            إدارة مشاريعك وتتبع مصروفات كل مشروع
          </p>
        </div>
        <Button onClick={() => setShowAddForm(true)}>
          <Plus className="w-4 h-4 ml-2" />
          إضافة مشروع جديد
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {projects.map((project) => (
          <Card key={project.id} className="relative">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CardTitle className="text-lg">{project.name}</CardTitle>
                </div>
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setEditingProject(project)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setDeletingProject(project)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              {project.code && (
                <CardDescription>الرمز: {project.code}</CardDescription>
              )}
            </CardHeader>
            <CardContent className="space-y-2">
              {project.description && (
                <p className="text-sm text-muted-foreground">
                  {project.description}
                </p>
              )}
              <div className="text-xs text-muted-foreground">
                تم الإنشاء: {new Date(project.created_at).toLocaleDateString('ar-SA')}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {projects.length === 0 && (
        <Card className="p-8 text-center">
          <CardTitle className="mb-2">لا توجد مشاريع</CardTitle>
          <CardDescription className="mb-4">
            قم بإضافة أول مشروع لتنظيم مصروفاتك حسب المشاريع
          </CardDescription>
          <Button onClick={() => setShowAddForm(true)}>
            <Plus className="w-4 h-4 ml-2" />
            إضافة مشروع جديد
          </Button>
        </Card>
      )}

      <AddProjectForm 
        open={showAddForm} 
        onClose={() => setShowAddForm(false)} 
      />
      
      <EditProjectForm
        project={editingProject}
        open={!!editingProject}
        onClose={() => setEditingProject(null)}
      />
      
      <DeleteProjectDialog
        project={deletingProject}
        open={!!deletingProject}
        onClose={() => setDeletingProject(null)}
      />
    </div>
  )
}
