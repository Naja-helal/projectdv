import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Settings as SettingsIcon } from 'lucide-react'

export default function Settings() {
  return (
    <div className="space-y-6">
      {/* الرأس */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">الإعدادات</h1>
          <p className="text-muted-foreground mt-2">
            إعدادات النظام العامة
          </p>
        </div>
      </div>

      <div className="grid gap-6">
        {/* إعدادات عامة */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <SettingsIcon className="h-5 w-5" />
              إعدادات عامة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center py-3 border-b">
                <div>
                  <h4 className="font-medium">العملة الافتراضية</h4>
                  <p className="text-sm text-muted-foreground">العملة المستخدمة في النظام</p>
                </div>
                <span className="text-sm bg-muted px-2 py-1 rounded">ريال سعودي (SAR)</span>
              </div>
              
              <div className="flex justify-between items-center py-3 border-b">
                <div>
                  <h4 className="font-medium">معدل الضريبة الافتراضي</h4>
                  <p className="text-sm text-muted-foreground">ضريبة القيمة المضافة</p>
                </div>
                <span className="text-sm bg-muted px-2 py-1 rounded">15%</span>
              </div>

              <div className="flex justify-between items-center py-3">
                <div>
                  <h4 className="font-medium">تصدير البيانات</h4>
                  <p className="text-sm text-muted-foreground">تصدير المصروفات إلى CSV</p>
                </div>
                <button className="text-sm px-3 py-1 border rounded hover:bg-muted">
                  تصدير
                </button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* معلومات النظام */}
        <Card>
          <CardHeader>
            <CardTitle>معلومات النظام</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="font-medium">اسم النظام:</span>
                <span>نظام إدارة المصروفات والبرماوي</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">الإصدار:</span>
                <span>1.0.0</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">تاريخ آخر تحديث:</span>
                <span>12 سبتمبر 2025</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
