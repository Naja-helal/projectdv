import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Plus, Edit, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import AddCategoryForm from '@/components/forms/AddCategoryForm'
import EditCategoryForm from '@/components/forms/EditCategoryForm'
import DeleteCategoryDialog from '@/components/forms/DeleteCategoryDialog'
import { categoryApi } from '@/lib/api'
import type { Category } from '@/types'

export default function CategoriesPage() {
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  const [deletingCategory, setDeletingCategory] = useState<Category | null>(null)

  const { data: categories = [], isLoading } = useQuery({
    queryKey: ['categories'],
    queryFn: categoryApi.getCategories
  })

  if (isLoading) {
    return <div className="p-6">جاري تحميل الفئات...</div>
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">إدارة الفئات</h1>
          <p className="text-muted-foreground">
            إدارة فئات المصروفات مثل اشتراكات المواقع والخدمات
          </p>
        </div>
        <Button onClick={() => setShowAddForm(true)}>
          <Plus className="w-4 h-4 ml-2" />
          إضافة فئة جديدة
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map((category) => (
          <Card key={category.id} className="relative">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: category.color }}
                  />
                  <span className="text-lg">{category.icon}</span>
                  <CardTitle className="text-lg">{category.name}</CardTitle>
                </div>
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setEditingCategory(category)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setDeletingCategory(category)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              {category.code && (
                <CardDescription>الرمز: {category.code}</CardDescription>
              )}
            </CardHeader>
            {category.description && (
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  {category.description}
                </p>
              </CardContent>
            )}
          </Card>
        ))}
      </div>

      {categories.length === 0 && (
        <Card className="p-8 text-center">
          <CardTitle className="mb-2">لا توجد فئات</CardTitle>
          <CardDescription className="mb-4">
            قم بإضافة أول فئة لتنظيم مصروفاتك
          </CardDescription>
          <Button onClick={() => setShowAddForm(true)}>
            <Plus className="w-4 h-4 ml-2" />
            إضافة فئة جديدة
          </Button>
        </Card>
      )}

      <AddCategoryForm 
        open={showAddForm} 
        onClose={() => setShowAddForm(false)} 
      />
      
      <EditCategoryForm
        category={editingCategory}
        open={!!editingCategory}
        onClose={() => setEditingCategory(null)}
      />
      
      <DeleteCategoryDialog
        category={deletingCategory}
        open={!!deletingCategory}
        onClose={() => setDeletingCategory(null)}
      />
    </div>
  )
}
