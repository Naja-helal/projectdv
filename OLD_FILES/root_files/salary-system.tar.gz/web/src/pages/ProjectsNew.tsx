import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import EditProjectForm from '@/components/forms/EditProjectForm'
import DeleteProjectDialog from '@/components/forms/DeleteProjectDialog'
import { Edit, Trash2, Plus } from 'lucide-react'
import { projectApi } from '@/lib/api'
import type { Project, CreateProjectData } from '@/types'
import { useMutation, useQueryClient } from '@tanstack/react-query'

export default function Projects() {
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingProject, setEditingProject] = useState<Project | null>(null)
  const [deletingProject, setDeletingProject] = useState<Project | null>(null)
  
  const queryClient = useQueryClient()
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    description: '',
  })

  const { data: projects, isLoading, error } = useQuery({
    queryKey: ['projects'],
    queryFn: projectApi.getProjects
  })

  const createMutation = useMutation({
    mutationFn: (data: CreateProjectData) => projectApi.createProject(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] })
      setFormData({
        name: '',
        code: '',
        description: '',
      })
      setShowAddForm(false)
    },
    onError: (error) => {
      console.error('خطأ في إنشاء المشروع:', error)
    }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name.trim()) return
    createMutation.mutate(formData)
  }

  if (isLoading) return <div className="p-6">جاري التحميل...</div>
  if (error) return <div className="p-6 text-red-500">خطأ في تحميل البيانات</div>

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">المشاريع</h1>
        <Button onClick={() => setShowAddForm(true)}>
          <Plus className="ml-2 h-4 w-4" />
          إضافة مشروع جديد
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {projects?.map((project) => (
          <Card key={project.id} className="relative">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{project.name}</CardTitle>
                
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setEditingProject(project)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setDeletingProject(project)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              {project.code && (
                <p className="text-sm text-muted-foreground mb-2">
                  الرمز: {project.code}
                </p>
              )}
              {project.description && (
                <p className="text-sm">{project.description}</p>
              )}
              <div className="mt-3 flex items-center gap-2">
                <span className={`px-2 py-1 rounded-full text-xs ${
                  project.status === 'active' ? 'bg-green-100 text-green-800' :
                  project.status === 'completed' ? 'bg-blue-100 text-blue-800' :
                  project.status === 'on_hold' ? 'bg-yellow-100 text-yellow-800' :
                  project.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {project.status === 'active' ? 'نشط' :
                   project.status === 'completed' ? 'مكتمل' :
                   project.status === 'on_hold' ? 'متوقف' :
                   project.status === 'cancelled' ? 'ملغي' :
                   'غير معروف'}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* نموذج إضافة مشروع جديد */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
            <h2 className="text-lg font-bold mb-4">إضافة مشروع جديد</h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">اسم المشروع *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="مثال: تطوير موقع الشركة"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">رمز المشروع (اختياري)</label>
                <input
                  type="text"
                  value={formData.code}
                  onChange={(e) => setFormData(prev => ({ ...prev, code: e.target.value }))}
                  placeholder="مثال: company-website"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">وصف المشروع (اختياري)</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="وصف مختصر للمشروع..."
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex gap-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setFormData({
                      name: '',
                      code: '',
                      description: '',
                    })
                    setShowAddForm(false)
                  }}
                >
                  إلغاء
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || !formData.name.trim()}
                >
                  {createMutation.isPending ? 'جاري الحفظ...' : 'حفظ'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* نموذج تحرير المشروع */}
      <EditProjectForm
        project={editingProject}
        open={!!editingProject}
        onClose={() => setEditingProject(null)}
      />

      {/* حوار حذف المشروع */}
      <DeleteProjectDialog
        project={deletingProject}
        open={!!deletingProject}
        onClose={() => setDeletingProject(null)}
      />
    </div>
  )
}
