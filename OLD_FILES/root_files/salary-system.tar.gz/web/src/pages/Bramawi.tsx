import { useState, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

import BramawiForm from '@/components/forms/BramawiForm'
import BramawiTable from '@/components/tables/BramawiTable'
import { bramawiApi } from '@/lib/api'
import { Settings, Plus, FileText, CheckCircle, Clock, DollarSign, TrendingUp, TrendingDown } from 'lucide-react'
import { startOfWeek, startOfMonth, startOfYear, isAfter } from 'date-fns'

export default function Bramawi() {
  const [showForm, setShowForm] = useState(false)
  const [editRecord, setEditRecord] = useState<any>(null)
  const [activeTab, setActiveTab] = useState<'unpaid' | 'paid'>('unpaid')
  const [timeFilter, setTimeFilter] = useState<'all' | 'week' | 'month' | 'year'>('all')

  // جلب الحقول الديناميكية
  const { data: fields = [] } = useQuery({
    queryKey: ['bramawi-fields'],
    queryFn: bramawiApi.getFields
  })

  // جلب السجلات غير المدفوعة
  const { data: unpaidRecords = [], isLoading: unpaidLoading } = useQuery({
    queryKey: ['bramawi-records', 'unpaid'],
    queryFn: () => bramawiApi.getRecords({ status: 'unpaid' })
  })

  // جلب السجلات المدفوعة
  const { data: paidRecords = [], isLoading: paidLoading } = useQuery({
    queryKey: ['bramawi-records', 'paid'],
    queryFn: () => bramawiApi.getRecords({ status: 'paid' })
  })

  // فلترة البيانات حسب الفترة الزمنية وحساب المبالغ
  const financialSummary = useMemo(() => {
    const now = new Date()
    let filterDate: Date | null = null

    switch (timeFilter) {
      case 'week':
        filterDate = startOfWeek(now, { weekStartsOn: 0 }) // الأحد بداية الأسبوع
        break
      case 'month':
        filterDate = startOfMonth(now)
        break
      case 'year':
        filterDate = startOfYear(now)
        break
      case 'all':
      default:
        filterDate = null
        break
    }

    const filterRecords = (records: any[]) => {
      if (!filterDate) return records
      return records.filter(record => isAfter(new Date(record.created_at), filterDate!))
    }

    const filteredUnpaid = filterRecords(unpaidRecords)
    const filteredPaid = filterRecords(paidRecords)

    const calculateTotal = (records: any[]) => {
      return records.reduce((total, record) => {
        const totalAmountField = record.values?.['total_amount']
        if (totalAmountField && totalAmountField.value) {
          return total + parseFloat(totalAmountField.value)
        }
        return total
      }, 0)
    }

    const unpaidTotal = calculateTotal(filteredUnpaid)
    const paidTotal = calculateTotal(filteredPaid)

    return {
      unpaidTotal,
      paidTotal,
      grandTotal: unpaidTotal + paidTotal,
      filteredUnpaidCount: filteredUnpaid.length,
      filteredPaidCount: filteredPaid.length
    }
  }, [unpaidRecords, paidRecords, timeFilter])

  // دالة لفتح نموذج التعديل
  const handleEditRecord = (record: any) => {
    setEditRecord(record)
    setShowForm(true)
  }

  // دالة إغلاق النموذج
  const handleCloseForm = () => {
    setShowForm(false)
    setEditRecord(null)
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* الرأس */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">البرماوي</h1>
          <p className="text-muted-foreground mt-2">
            نظام إدارة البيانات الديناميكي
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => setShowForm(true)}
            className="bg-green-600 hover:bg-green-700"
          >
            إضافة بيانات
            <Plus className="h-4 w-4 mr-2" />
          </Button>
          <Button 
            variant="outline"
            onClick={() => window.open('/settings', '_blank')}
          >
            إعدادات الحقول
            <Settings className="h-4 w-4 mr-2" />
          </Button>
        </div>
      </div>

      {/* الملخص المالي */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              الملخص المالي
            </CardTitle>
            <select 
              value={timeFilter} 
              onChange={(e) => setTimeFilter(e.target.value as any)}
              className="flex h-10 w-32 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <option value="all">الكل</option>
              <option value="week">هذا الأسبوع</option>
              <option value="month">هذا الشهر</option>
              <option value="year">هذا العام</option>
            </select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* إجمالي غير مدفوع */}
            <div className="flex items-center gap-4 p-4 bg-red-50 rounded-lg border border-red-200">
              <div className="p-3 bg-red-100 rounded-full">
                <TrendingDown className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-red-700 font-medium">إجمالي غير مدفوع</p>
                <p className="text-2xl font-bold text-red-900">
                  {financialSummary.unpaidTotal.toLocaleString('en-US')} ر.س
                </p>
                <p className="text-xs text-red-600">
                  ({financialSummary.filteredUnpaidCount} سجل)
                </p>
              </div>
            </div>

            {/* إجمالي مدفوع */}
            <div className="flex items-center gap-4 p-4 bg-green-50 rounded-lg border border-green-200">
              <div className="p-3 bg-green-100 rounded-full">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-green-700 font-medium">إجمالي مدفوع</p>
                <p className="text-2xl font-bold text-green-900">
                  {financialSummary.paidTotal.toLocaleString('en-US')} ر.س
                </p>
                <p className="text-xs text-green-600">
                  ({financialSummary.filteredPaidCount} سجل)
                </p>
              </div>
            </div>

            {/* إجمالي عام */}
            <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="p-3 bg-blue-100 rounded-full">
                <DollarSign className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-blue-700 font-medium">المبلغ الإجمالي</p>
                <p className="text-2xl font-bold text-blue-900">
                  {financialSummary.grandTotal.toLocaleString('en-US')} ر.س
                </p>
                <p className="text-xs text-blue-600">
                  ({financialSummary.filteredUnpaidCount + financialSummary.filteredPaidCount} سجل)
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <FileText className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">إجمالي السجلات</p>
                <p className="text-2xl font-bold">{unpaidRecords.length + paidRecords.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Clock className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">غير مدفوع</p>
                <p className="text-2xl font-bold">{unpaidRecords.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">مدفوع</p>
                <p className="text-2xl font-bold">{paidRecords.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Settings className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">الحقول المتاحة</p>
                <p className="text-2xl font-bold">{fields.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* التبويبات الرئيسية */}
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as 'unpaid' | 'paid')}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="unpaid" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            غير مدفوع ({unpaidRecords.length})
          </TabsTrigger>
          <TabsTrigger value="paid" className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            مدفوع ({paidRecords.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="unpaid" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-orange-600" />
                السجلات غير المدفوعة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <BramawiTable
                records={unpaidRecords}
                fields={fields}
                status="unpaid"
                isLoading={unpaidLoading}
                onEditRecord={handleEditRecord}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="paid" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                السجلات المدفوعة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <BramawiTable
                records={paidRecords}
                fields={fields}
                status="paid"
                isLoading={paidLoading}
                onEditRecord={handleEditRecord}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* نموذج إضافة/تعديل البيانات */}
      <BramawiForm
        fields={fields}
        open={showForm}
        onClose={handleCloseForm}
        editRecord={editRecord}
      />
    </div>
  )
}
