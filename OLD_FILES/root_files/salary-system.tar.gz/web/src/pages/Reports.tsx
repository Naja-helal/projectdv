import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { reportsAPI } from '@/lib/api'
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Wallet, 
  Calendar,
  FileText,
  AlertCircle,
  DollarSign
} from 'lucide-react'

interface OverviewStats {
  total_expenses: { count: number; total: number }
  total_categories: { count: number }
  total_vendors: { count: number }
  total_employees: { count: number }
  this_month_expenses: { count: number; total: number }
  this_month_salaries: { count: number; total: number }
  pending_advances: { count: number; total: number }
}

interface ExpensesByCategory {
  name: string
  color: string
  icon: string
  count: number
  total: number
}

interface MonthlyTrend {
  month: string
  count: number
  total: number
}

interface SalaryByDepartment {
  department: string
  employee_count: number
  avg_base_salary: number
  total_paid: number
}

export default function Reports() {
  const [overview, setOverview] = useState<OverviewStats | null>(null)
  const [expensesByCategory, setExpensesByCategory] = useState<ExpensesByCategory[]>([])
  const [monthlyTrend, setMonthlyTrend] = useState<MonthlyTrend[]>([])
  const [salaryByDepartment, setSalaryByDepartment] = useState<SalaryByDepartment[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchReports = async () => {
      try {
        setLoading(true)
        
        // جلب النظرة العامة
        try {
          const overviewData = await reportsAPI.getOverview()
          setOverview(overviewData.overview)
        } catch (error) {
          console.error('خطأ في جلب النظرة العامة:', error)
        }

        // جلب تقارير المصروفات
        try {
          const expensesData = await reportsAPI.getExpenses()
          setExpensesByCategory(expensesData.by_category)
          setMonthlyTrend(expensesData.monthly_trend)
        } catch (error) {
          console.error('خطأ في جلب تقارير المصروفات:', error)
        }

        // جلب تقارير الرواتب
        try {
          const salariesData = await reportsAPI.getSalaries()
          setSalaryByDepartment(salariesData.by_department)
        } catch (error) {
          console.error('خطأ في جلب تقارير الرواتب:', error)
        }

      } catch (error) {
        console.error('خطأ في جلب التقارير:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchReports()
  }, [])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR'
    }).format(amount)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">جاري تحميل التقارير...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* رأس الصفحة */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">التقارير والإحصائيات</h1>
          <p className="text-muted-foreground">نظرة شاملة على أداء النظام المالي</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="w-4 h-4" />
          {new Date().toLocaleDateString('ar-SA', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          })}
        </div>
      </div>

      {/* بطاقات الإحصائيات العامة */}
      {overview && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">إجمالي المصروفات</CardTitle>
              <Wallet className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overview.total_expenses.count}</div>
              <p className="text-xs text-muted-foreground">
                {formatCurrency(overview.total_expenses.total || 0)}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">الموظفين النشطين</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overview.total_employees.count}</div>
              <p className="text-xs text-muted-foreground">
                موظف نشط
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">مصروفات هذا الشهر</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overview.this_month_expenses.count}</div>
              <p className="text-xs text-muted-foreground">
                {formatCurrency(overview.this_month_expenses.total || 0)}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">رواتب هذا الشهر</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overview.this_month_salaries.count}</div>
              <p className="text-xs text-muted-foreground">
                {formatCurrency(overview.this_month_salaries.total || 0)}
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* المصروفات حسب الفئة */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              المصروفات حسب الفئة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {expensesByCategory.slice(0, 8).map((category, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">{category.icon}</span>
                    <div>
                      <p className="font-medium">{category.name}</p>
                      <p className="text-sm text-muted-foreground">{category.count} مصروف</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{formatCurrency(category.total || 0)}</p>
                    <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full rounded-full transition-all"
                        style={{ 
                          backgroundColor: category.color,
                          width: `${Math.min((category.total / Math.max(...expensesByCategory.map(c => c.total))) * 100, 100)}%`
                        }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* الرواتب حسب القسم */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              الرواتب حسب القسم
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {salaryByDepartment.map((dept, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div>
                    <p className="font-medium">{dept.department || 'غير محدد'}</p>
                    <p className="text-sm text-muted-foreground">
                      {dept.employee_count} موظف
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{formatCurrency(dept.total_paid || 0)}</p>
                    <p className="text-sm text-muted-foreground">
                      متوسط: {formatCurrency(dept.avg_base_salary || 0)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* الاتجاه الشهري */}
      {monthlyTrend.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              اتجاه المصروفات الشهرية
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {monthlyTrend.slice(-6).map((month, index) => (
                <div key={index} className="text-center p-3 bg-muted/50 rounded-lg">
                  <p className="text-sm font-medium">{month.month}</p>
                  <p className="text-lg font-bold text-primary">{month.count}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatCurrency(month.total)}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* السُلف المعلقة */}
      {overview?.pending_advances && overview.pending_advances.count > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-800">
              <AlertCircle className="w-5 h-5" />
              السُلف والمديونيات المعلقة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-800 font-medium">
                  {overview.pending_advances.count} سلفة معلقة
                </p>
                <p className="text-sm text-orange-600">
                  تحتاج لمتابعة أو تسديد
                </p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-orange-800">
                  {formatCurrency(overview.pending_advances.total)}
                </p>
                <Badge variant="outline" className="border-orange-300 text-orange-700">
                  مبلغ متبقي
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ملاحظة */}
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <FileText className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <p className="text-blue-800 font-medium">تحديث تلقائي</p>
              <p className="text-sm text-blue-600">
                يتم تحديث هذه التقارير تلقائياً عند إضافة أو تعديل البيانات في النظام.
                آخر تحديث: {new Date().toLocaleTimeString('ar-SA')}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}