import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import ExpenseForm from '@/components/forms/ExpenseForm'
import { Trash2 } from 'lucide-react'
import { expenseApi, categoryApi } from '@/lib/api'
import type { Expense, ExpenseFilters } from '@/types'
import { format } from 'date-fns'
import { ar } from 'date-fns/locale'

export default function Expenses() {
  const [showForm, setShowForm] = useState(false)
  const [filters, setFilters] = useState<ExpenseFilters>({})
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedExpenses, setSelectedExpenses] = useState<number[]>([])
  
  const queryClient = useQueryClient()

  // جلب المصروفات
  const { data: expenses = [], isLoading, error } = useQuery({
    queryKey: ['expenses', filters],
    queryFn: () => expenseApi.getExpenses({
      ...filters,
      q: searchTerm || undefined,
    })
  })

  // جلب الفئات للفلترة
  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: categoryApi.getCategories
  })

  // حذف مصروف
  const deleteMutation = useMutation({
    mutationFn: (id: number) => expenseApi.deleteExpense(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses'] })
      queryClient.invalidateQueries({ queryKey: ['stats'] })
    }
  })

  const handleDelete = (expense: Expense) => {
    if (confirm('هل أنت متأكد من حذف هذا المصروف؟')) {
      deleteMutation.mutate(expense.id)
    }
  }

  // حذف المصروفات المحددة
  const deleteSelectedMutation = useMutation({
    mutationFn: async (ids: number[]) => {
      for (const id of ids) {
        await expenseApi.deleteExpense(id)
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses'] })
      queryClient.invalidateQueries({ queryKey: ['stats'] })
      setSelectedExpenses([])
    }
  })

  const handleDeleteSelected = () => {
    if (selectedExpenses.length === 0) return
    
    if (confirm(`هل أنت متأكد من حذف ${selectedExpenses.length} مصروف محدد؟`)) {
      deleteSelectedMutation.mutate(selectedExpenses)
    }
  }

  // تحديد/إلغاء تحديد مصروف واحد
  const toggleExpenseSelection = (expenseId: number) => {
    setSelectedExpenses(prev => 
      prev.includes(expenseId) 
        ? prev.filter(id => id !== expenseId)
        : [...prev, expenseId]
    )
  }

  // تحديد/إلغاء تحديد جميع المصروفات
  const toggleSelectAll = () => {
    setSelectedExpenses(prev => 
      prev.length === expenses.length 
        ? [] 
        : expenses.map(expense => expense.id)
    )
  }

  const handleSearch = () => {
    setFilters(prev => ({ ...prev, q: searchTerm }))
  }

  const clearFilters = () => {
    setFilters({})
    setSearchTerm('')
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">جاري تحميل المصروفات...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center text-destructive">
          <p>خطأ في تحميل المصروفات</p>
          <p className="text-sm text-muted-foreground mt-2">
            {error instanceof Error ? error.message : 'خطأ غير معروف'}
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* الرأس */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">المصروفات</h1>
          <p className="text-muted-foreground mt-2">
            إدارة وعرض جميع المصروفات ({expenses.length} مصروف)
          </p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          ➕ إضافة مصروف
        </Button>
      </div>

      {/* الفلاتر والبحث */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* البحث */}
            <div className="flex gap-2">
              <Input
                placeholder="البحث في المراجع والملاحظات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <Button onClick={handleSearch} variant="outline" size="sm">
                🔍
              </Button>
            </div>

            {/* فلتر الفئة */}
            <select
              value={filters.categoryId || ''}
              onChange={(e) => setFilters(prev => ({
                ...prev,
                categoryId: e.target.value ? parseInt(e.target.value) : undefined
              }))}
              className="w-full p-2 border rounded-md bg-background"
            >
              <option value="">جميع الفئات</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.icon} {category.name}
                </option>
              ))}
            </select>

            {/* فلتر التاريخ من */}
            <Input
              type="date"
              value={filters.from ? new Date(filters.from).toISOString().split('T')[0] : ''}
              onChange={(e) => setFilters(prev => ({
                ...prev,
                from: e.target.value ? new Date(e.target.value).getTime() : undefined
              }))}
              placeholder="من تاريخ"
            />

            {/* فلتر التاريخ إلى */}
            <Input
              type="date"
              value={filters.to ? new Date(filters.to).toISOString().split('T')[0] : ''}
              onChange={(e) => setFilters(prev => ({
                ...prev,
                to: e.target.value ? new Date(e.target.value).getTime() : undefined
              }))}
              placeholder="إلى تاريخ"
            />
          </div>

          {/* أزرار التحكم */}
          <div className="flex justify-between items-center mt-4">
            <div className="flex gap-2">
              <Button onClick={clearFilters} variant="outline" size="sm">
                مسح الفلاتر
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>



      {/* قائمة المصروفات */}
      <Card>
        <CardHeader>
          <CardTitle>قائمة المصروفات</CardTitle>
        </CardHeader>
        <CardContent>
          {expenses.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <div className="text-6xl mb-4">💰</div>
              <h3 className="text-lg font-semibold mb-2">لا توجد مصروفات</h3>
              <p className="mb-4">
                {Object.keys(filters).length > 0 ? 
                  'لا توجد مصروفات تطابق الفلاتر المحددة' : 
                  'لم يتم إضافة أي مصروفات بعد'
                }
              </p>
              <Button onClick={() => setShowForm(true)}>
                إضافة أول مصروف
              </Button>
            </div>
          ) : (
            <div className="space-y-4" dir="rtl">
              {/* أزرار التحكم */}
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">
                    {selectedExpenses.length > 0 && `${selectedExpenses.length} محدد`}
                  </span>
                  <Button 
                    onClick={toggleSelectAll} 
                    variant="outline" 
                    size="sm"
                    disabled={expenses.length === 0}
                  >
                    {selectedExpenses.length === expenses.length ? 'إلغاء تحديد الكل' : 'تحديد الكل'}
                  </Button>
                </div>
                
                {selectedExpenses.length > 0 && (
                  <div className="flex gap-2">
                    <Button 
                      onClick={handleDeleteSelected}
                      variant="destructive" 
                      size="sm"
                      disabled={deleteSelectedMutation.isPending}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      حذف المحدد ({selectedExpenses.length})
                      <Trash2 className="h-4 w-4 mr-2" />
                    </Button>
                  </div>
                )}
              </div>

              {/* الجدول */}
            <div className="overflow-x-auto" dir="rtl">
              <table className="w-full border-collapse" dir="rtl" style={{ direction: 'rtl' }}>
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="text-center p-3 w-12 font-semibold">
                      <input
                        type="checkbox"
                        checked={selectedExpenses.length === expenses.length && expenses.length > 0}
                        onChange={toggleSelectAll}
                        className="rounded border-gray-300"
                      />
                    </th>
                    <th className="text-center p-3 font-semibold">التاريخ</th>
                    <th className="text-center p-3 font-semibold">الفئة</th>
                    <th className="text-center p-3 font-semibold">المبلغ</th>
                    <th className="text-center p-3 font-semibold">الضريبة</th>
                    <th className="text-center p-3 font-semibold">الإجمالي</th>
                    <th className="text-center p-3 font-semibold">المرجع</th>
                    <th className="text-center p-3 font-semibold">المورّد</th>
                    <th className="text-center p-3 font-semibold">الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {expenses.map((expense) => (
                    <tr key={expense.id} className={`border-b hover:bg-muted/50 ${selectedExpenses.includes(expense.id) ? 'bg-orange-50' : ''}`}>
                      <td className="text-center p-3">
                        <input
                          type="checkbox"
                          checked={selectedExpenses.includes(expense.id)}
                          onChange={() => toggleExpenseSelection(expense.id)}
                          className="rounded border-gray-300"
                        />
                      </td>
                      <td className="p-3 text-center">
                        <div className="text-sm">
                          {format(new Date(expense.date), 'dd/MM/yyyy', { locale: ar })}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {format(new Date(expense.date), 'HH:mm')}
                        </div>
                      </td>
                      <td className="p-3 text-center">
                        <div className="flex items-center justify-center gap-2">
                          {expense.category_icon && (
                            <span className="text-lg">{expense.category_icon}</span>
                          )}
                          <span
                            className="w-3 h-3 rounded-full inline-block"
                            style={{ backgroundColor: expense.category_color }}
                          />
                          <span className="text-sm font-medium">{expense.category_name}</span>
                        </div>
                      </td>
                      <td className="p-3 text-center">
                        <span className="font-mono font-semibold">
                          {expense.amount.toLocaleString('en-US')}
                        </span>
                        <div className="text-xs text-muted-foreground">{expense.currency}</div>
                      </td>
                      <td className="p-3 text-center">
                        <span className="font-mono text-sm">
                          {expense.tax_amount.toFixed(2)}
                        </span>
                        <div className="text-xs text-muted-foreground">({expense.tax_rate}%)</div>
                      </td>
                      <td className="p-3 text-center">
                        <span className="font-mono font-bold text-lg text-primary">
                          {expense.total_amount.toLocaleString('en-US')}
                        </span>
                        <div className="text-xs text-muted-foreground">{expense.currency}</div>
                      </td>
                      <td className="p-3 text-center">
                        <div className="text-sm font-medium">
                          {expense.reference || expense.invoice_number || '-'}
                        </div>
                      </td>
                      <td className="p-3 text-center">
                        <div className="text-sm">
                          {expense.vendor_name || '-'}
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex gap-1 justify-center">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDelete(expense)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* نموذج إضافة المصروف */}
      <ExpenseForm
        open={showForm}
        onClose={() => setShowForm(false)}
      />
    </div>
  )
}
