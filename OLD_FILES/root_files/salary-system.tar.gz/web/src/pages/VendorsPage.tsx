import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Plus, Edit, Trash2, Mail, Phone, MapPin } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import AddVendorForm from '@/components/forms/AddVendorForm'
import EditVendorForm from '@/components/forms/EditVendorForm'
import DeleteVendorDialog from '@/components/forms/DeleteVendorDialog'
import { vendorApi } from '@/lib/api'
import type { Vendor } from '@/types'

export default function VendorsPage() {
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingVendor, setEditingVendor] = useState<Vendor | null>(null)
  const [deletingVendor, setDeletingVendor] = useState<Vendor | null>(null)

  const { data: vendors = [], isLoading } = useQuery({
    queryKey: ['vendors'],
    queryFn: vendorApi.getVendors
  })

  if (isLoading) {
    return <div className="p-6">جاري تحميل الموردين...</div>
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">إدارة الموردين</h1>
          <p className="text-muted-foreground">
            إدارة بيانات الموردين ومقدمي الخدمات
          </p>
        </div>
        <Button onClick={() => setShowAddForm(true)}>
          <Plus className="w-4 h-4 ml-2" />
          إضافة مورد جديد
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {vendors.map((vendor) => (
          <Card key={vendor.id} className="relative">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{vendor.name}</CardTitle>
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setEditingVendor(vendor)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setDeletingVendor(vendor)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              {vendor.contact && (
                <CardDescription>جهة الاتصال: {vendor.contact}</CardDescription>
              )}
            </CardHeader>
            <CardContent className="space-y-2">
              {vendor.email && (
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <span>{vendor.email}</span>
                </div>
              )}
              {vendor.phone && (
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span>{vendor.phone}</span>
                </div>
              )}
              {vendor.address && (
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="line-clamp-2">{vendor.address}</span>
                </div>
              )}
              {vendor.tax_number && (
                <div className="text-sm">
                  <span className="font-medium">الرقم الضريبي: </span>
                  <span>{vendor.tax_number}</span>
                </div>
              )}
              <div className="text-xs text-muted-foreground">
                تم الإنشاء: {new Date(vendor.created_at).toLocaleDateString('ar-SA')}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {vendors.length === 0 && (
        <Card className="p-8 text-center">
          <CardTitle className="mb-2">لا توجد موردين</CardTitle>
          <CardDescription className="mb-4">
            قم بإضافة أول مورد أو مقدم خدمة
          </CardDescription>
          <Button onClick={() => setShowAddForm(true)}>
            <Plus className="w-4 h-4 ml-2" />
            إضافة مورد جديد
          </Button>
        </Card>
      )}

      <AddVendorForm 
        open={showAddForm} 
        onClose={() => setShowAddForm(false)} 
      />
      
      <EditVendorForm
        vendor={editingVendor}
        open={!!editingVendor}
        onClose={() => setEditingVendor(null)}
      />
      
      <DeleteVendorDialog
        vendor={deletingVendor}
        open={!!deletingVendor}
        onClose={() => setDeletingVendor(null)}
      />
    </div>
  )
}
