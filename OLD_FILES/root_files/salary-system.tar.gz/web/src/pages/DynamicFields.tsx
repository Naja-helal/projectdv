import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Plus, Settings, Trash2, Edit, DollarSign } from 'lucide-react'
import { getApiUrl } from '@/lib/api';

// أنواع البيانات
interface DynamicField {
  id: number
  name: string
  label: string
  type: 'text' | 'number' | 'date' | 'select' | 'calculated' | 'url' | 'phone'
  page_type: string
  options?: string[]
  calculation_formula?: string
  is_required: boolean
  display_order: number
  default_value?: string
  created_at: string
}

interface CreateDynamicFieldData {
  name: string
  label: string
  type: 'text' | 'number' | 'date' | 'select' | 'calculated' | 'url' | 'phone'
  page_type: string
  options?: string[]
  calculation_formula?: string
  is_required: boolean
  display_order: number
  default_value?: string
}

export default function DynamicFields() {
  // استخراج نوع الصفحة من URL إذا كان متوفراً
  const urlParams = new URLSearchParams(window.location.search)
  const initialPage = urlParams.get('tab') || 'expenses'
  
  const [showForm, setShowForm] = useState(false)
  const [editingField, setEditingField] = useState<DynamicField | null>(null)
  const [selectedPage, setSelectedPage] = useState<string>(initialPage)
  const [formData, setFormData] = useState<CreateDynamicFieldData>({
    name: '',
    label: '',
    type: 'text',
    page_type: initialPage,
    is_required: false,
    display_order: 0
  })

  const queryClient = useQueryClient()

  // الصفحات المتاحة
  const pageTypes = [
    { id: 'expenses', name: 'المصاريف', icon: DollarSign, color: 'bg-red-100 text-red-700' },
    { id: 'mosques', name: 'المساجد', icon: Settings, color: 'bg-blue-100 text-blue-700' }
  ]

  // جلب الحقول حسب نوع الصفحة
  const { data: fields = [], isLoading } = useQuery({
    queryKey: ['dynamic-fields', selectedPage],
    queryFn: async () => {
      const response = await fetch(getApiUrl(`/dynamic-fields/${selectedPage}`))
      if (!response.ok) {
        throw new Error('فشل في جلب الحقول')
      }
      return await response.json() as DynamicField[]
    }
  })

  // إضافة حقل جديد
  const createMutation = useMutation({
    mutationFn: async (data: CreateDynamicFieldData) => {
      const response = await fetch(getApiUrl('/dynamic-fields'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
      })
      
      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'فشل في إنشاء الحقل')
      }
      
      return await response.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dynamic-fields'] })
      resetForm()
      setShowForm(false)
    }
  })

  // تحديث حقل
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: Partial<CreateDynamicFieldData> }) => {
      const response = await fetch(getApiUrl(`/dynamic-fields/${id}`), {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
      })
      
      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'فشل في تحديث الحقل')
      }
      
      return await response.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dynamic-fields'] })
      resetForm()
      setShowForm(false)
      setEditingField(null)
    }
  })

  // حذف حقل
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(getApiUrl(`/dynamic-fields/${id}`), {
        method: 'DELETE'
      })
      
      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'فشل في حذف الحقل')
      }
      
      return await response.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dynamic-fields'] })
    }
  })

  const resetForm = () => {
    setFormData({
      name: '',
      label: '',
      type: 'text',
      page_type: selectedPage,
      is_required: false,
      display_order: 0
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (editingField) {
      updateMutation.mutate({ id: editingField.id, data: formData })
    } else {
      createMutation.mutate(formData)
    }
  }

  const handleEdit = (field: DynamicField) => {
    setEditingField(field)
    setFormData({
      name: field.name,
      label: field.label,
      type: field.type,
      page_type: field.page_type,
      options: field.options,
      calculation_formula: field.calculation_formula,
      is_required: field.is_required,
      display_order: field.display_order,
      default_value: field.default_value
    })
    setShowForm(true)
  }

  const handleDelete = (field: DynamicField) => {
    if (confirm(`هل أنت متأكد من حذف الحقل "${field.label}"؟`)) {
      deleteMutation.mutate(field.id)
    }
  }

  const getPageInfo = (pageId: string) => {
    return pageTypes.find(p => p.id === pageId) || pageTypes[0]
  }

  // دالة لترجمة أنواع الحقول إلى العربية
  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'text': return 'نص'
      case 'number': return 'رقم'
      case 'date': return 'تاريخ'
      case 'select': return 'قائمة اختيار'
      case 'calculated': return 'محسوب'
      case 'url': return 'رابط'
      case 'phone': return 'هاتف'
      default: return type
    }
  }

  const addOption = () => {
    const newOptions = [...(formData.options || []), '']
    setFormData(prev => ({ ...prev, options: newOptions }))
  }

  const updateOption = (index: number, value: string) => {
    const newOptions = [...(formData.options || [])]
    newOptions[index] = value
    setFormData(prev => ({ ...prev, options: newOptions }))
  }

  const removeOption = (index: number) => {
    const newOptions = [...(formData.options || [])]
    newOptions.splice(index, 1)
    setFormData(prev => ({ ...prev, options: newOptions }))
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* الرأس */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">الحقول الديناميكية</h1>
          <p className="text-muted-foreground mt-2">
            إنشاء وإدارة الحقول المخصصة لكل صفحة في النظام
          </p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          إضافة حقل جديد
        </Button>
      </div>

      {/* اختيار نوع الصفحة */}
      <Card>
        <CardHeader>
          <CardTitle>اختر نوع الصفحة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {pageTypes.map((page) => {
              const IconComponent = page.icon
              return (
                <button
                  key={page.id}
                  onClick={() => {
                    setSelectedPage(page.id)
                    setFormData(prev => ({ ...prev, page_type: page.id }))
                  }}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    selectedPage === page.id
                      ? 'border-primary bg-primary/5'
                      : 'border-muted hover:border-primary/50'
                  }`}
                >
                  <div className="flex flex-col items-center gap-2">
                    <div className={`p-2 rounded-lg ${page.color}`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <span className="font-medium">{page.name}</span>
                    <Badge variant="outline" className="text-xs">
                      {fields.filter(f => f.page_type === page.id).length} حقل
                    </Badge>
                  </div>
                </button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* عرض الحقول للصفحة المحددة */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              {(() => {
                const pageInfo = getPageInfo(selectedPage)
                const IconComponent = pageInfo.icon
                return (
                  <>
                    <IconComponent className="h-5 w-5" />
                    حقول صفحة {pageInfo.name} ({fields.length})
                  </>
                )
              })()}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-muted-foreground">جاري التحميل...</p>
            </div>
          ) : fields.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <div className="text-6xl mb-4">📝</div>
              <h3 className="text-lg font-semibold mb-2">لا توجد حقول محددة</h3>
              <p className="mb-4">
                ابدأ بإضافة الحقول المخصصة لصفحة {getPageInfo(selectedPage).name}
              </p>
              <Button onClick={() => setShowForm(true)}>
                إضافة أول حقل
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {fields
                .sort((a, b) => a.display_order - b.display_order)
                .map((field) => (
                  <div
                    key={field.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50"
                  >
                    <div className="flex items-center gap-4">
                      <div className="text-lg font-mono text-muted-foreground">
                        #{field.display_order || 1}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">{field.label}</h3>
                          <Badge variant="outline">{getTypeLabel(field.type)}</Badge>
                          {field.is_required && (
                            <Badge variant="destructive">مطلوب</Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground mt-1">
                          اسم الحقل: <code className="bg-muted px-1 rounded">{field.name}</code>
                          {field.default_value && (
                            <span className="mr-4">
                              القيمة الافتراضية: <code className="bg-muted px-1 rounded">{field.default_value}</code>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex gap-1">
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={() => handleEdit(field)}
                        disabled={updateMutation.isPending}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={() => handleDelete(field)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* نموذج إضافة/تعديل الحقل */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingField ? 'تعديل الحقل' : 'إضافة حقل جديد'} لصفحة {getPageInfo(selectedPage).name}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {/* اسم الحقل */}
              <div className="space-y-2">
                <Label>اسم الحقل (بالإنجليزية)</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="site_name"
                  required
                />
                <p className="text-xs text-muted-foreground">
                  يستخدم في قاعدة البيانات (بدون مسافات أو رموز)
                </p>
              </div>

              {/* العنوان */}
              <div className="space-y-2">
                <Label>العنوان (بالعربية)</Label>
                <Input
                  value={formData.label}
                  onChange={(e) => setFormData(prev => ({ ...prev, label: e.target.value }))}
                  placeholder="اسم الموقع"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* نوع الحقل */}
              <div className="space-y-2">
                <Label>نوع الحقل</Label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData(prev => ({ ...prev, type: e.target.value as any }))}
                  className="w-full p-2 border rounded-md bg-background"
                >
                  <option value="text">نص</option>
                  <option value="number">رقم</option>
                  <option value="date">تاريخ</option>
                  <option value="select">قائمة اختيار</option>
                  <option value="url">رابط</option>
                  <option value="phone">هاتف</option>
                </select>
              </div>

              {/* ترتيب العرض */}
              <div className="space-y-2">
                <Label>ترتيب العرض</Label>
                <Input
                  type="number"
                  value={formData.display_order}
                  onChange={(e) => setFormData(prev => ({ ...prev, display_order: parseInt(e.target.value) || 0 }))}
                  placeholder="0"
                />
              </div>
            </div>

            {/* القيمة الافتراضية */}
            <div className="space-y-2">
              <Label>القيمة الافتراضية (اختيارية)</Label>
              <Input
                value={formData.default_value || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, default_value: e.target.value }))}
                placeholder="القيمة التي ستظهر مسبقاً"
              />
            </div>

            {/* خيارات القائمة (للنوع select) */}
            {formData.type === 'select' && (
              <div className="space-y-2">
                <Label>خيارات القائمة</Label>
                <div className="space-y-2">
                  {(formData.options || []).map((option, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        value={option}
                        onChange={(e) => updateOption(index, e.target.value)}
                        placeholder={`الخيار ${index + 1}`}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeOption(index)}
                      >
                        حذف
                      </Button>
                    </div>
                  ))}
                  <Button
                    type="button"
                    variant="outline"
                    onClick={addOption}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    إضافة خيار
                  </Button>
                </div>
              </div>
            )}

            {/* حقل مطلوب */}
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="required"
                checked={formData.is_required}
                onChange={(e) => setFormData(prev => ({ ...prev, is_required: e.target.checked }))}
              />
              <Label htmlFor="required">حقل مطلوب</Label>
            </div>

            {/* أزرار التحكم */}
            <div className="flex justify-end gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowForm(false)
                  setEditingField(null)
                  resetForm()
                }}
              >
                إلغاء
              </Button>
              <Button 
                type="submit" 
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {editingField ? 'تحديث' : 'إضافة'} الحقل
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
