// أنواع البيانات الأساسية
export interface Category {
  id: number
  name: string
  code?: string
  color: string
  icon?: string
  description?: string
  created_at: number
  updated_at: number
}

export interface BramawiField {
  id: number;
  name: string;
  type: 'text' | 'number' | 'date' | 'select' | 'calculated';
  label: string;
  options?: string[];
  calculation_formula?: string;
  dependent_fields?: string[];
  default_value?: string;
  is_required: boolean;
  display_order: number;
  is_active: boolean;
  created_at: number;
  updated_at: number;
}

export interface Vendor {
  id: number
  name: string
  contact?: string
  email?: string
  phone?: string
  address?: string
  tax_number?: string
  created_at: number
  updated_at: number
}

// نظام الرواتب الجديد
export interface Employee {
  id: number
  name: string
  position?: string
  phone?: string
  monthly_salary: number
  hire_date?: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface MonthlySalary {
  id: number
  employee_id: number
  employee_name: string
  position?: string
  month: number
  year: number
  salary_amount: number
  is_delivered: boolean
  delivery_date?: string
  debt_amount: number
  notes?: string
  created_at: string
  updated_at: string
}

export interface SalarySettings {
  salary_generation_day: { value: number; type: string; id: number }
  auto_generate_salaries: { value: boolean; type: string; id: number }
  default_salary_amount: { value: number; type: string; id: number }
}

export interface CustomField {
  id: number
  entity: 'expense' | 'category' | 'vendor'
  name: string
  key: string
  type: 'text' | 'number' | 'date' | 'select' | 'bool'
  options?: string[]
  required: boolean
  sort_order: number
  created_at: number
}

export interface Expense {
  id: number
  category_id: number
  vendor_id?: number
  amount: number
  currency: string
  tax_rate: number
  tax_amount: number
  total_amount: number
  date: number
  payment_method?: string
  reference?: string
  invoice_number?: string
  notes?: string
  extra?: string
  extra_data?: Record<string, any>
  status: 'confirmed' | 'pending' | 'cancelled'
  created_at: number
  updated_at: number
  
  // البيانات المرتبطة
  category_name?: string
  category_color?: string
  category_icon?: string
  vendor_name?: string
  custom_fields?: Record<string, {
    value: string
    name: string
    type: string
  }>
}

export interface Stats {
  total: {
    count: number
    total: number
    subtotal: number
    tax: number
  }
  byCategory: Array<{
    name: string
    color: string
    icon: string
    count: number
    total: number
  }>
  currency: string
}

// أنواع النماذج
export interface CreateExpenseData {
  categoryId: number
  vendorId?: number
  amount: number
  taxRate?: number
  date: number
  paymentMethod?: string
  reference?: string
  invoiceNumber?: string
  notes?: string
  extra?: Record<string, any>
  customFields?: Record<string, string>
}

// نوع بيانات النموذج للواجهة الأمامية (التاريخ كـ string)
export interface ExpenseFormData {
  categoryId: number
  vendorId?: number
  amount: number
  taxRate?: number
  date: string // للنموذج HTML
  paymentMethod?: string
  reference?: string
  invoiceNumber?: string
  notes?: string
  extra?: Record<string, any>
  customFields?: Record<string, string>
}

export interface UpdateExpenseData extends Partial<CreateExpenseData> {
  id: number
}

export interface CreateCategoryData {
  name: string
  code?: string
  color?: string
  icon?: string
  description?: string
}

export interface CreateVendorData {
  name: string
  contact?: string
  email?: string
  phone?: string
  address?: string
  tax_number?: string
}

// أنواع المرشحات
export interface ExpenseFilters {
  from?: number
  to?: number
  categoryId?: number
  vendorId?: number
  q?: string
  limit?: number
}

// استجابات API
export interface ApiResponse<T> {
  data?: T
  error?: string
  success?: boolean
}

export interface CreateExpenseResponse {
  id: number
  totalAmount: number
  taxAmount: number
  success: boolean
}

export interface CreateEntityResponse {
  id: number
  success: boolean
}

// أنواع البرماوي
export interface BramawiField {
  id: number
  name: string
  type: 'text' | 'number' | 'date' | 'select' | 'calculated'
  label: string
  options?: string[]
  calculation_formula?: string
  dependent_fields?: string[]
  default_value?: string
  is_required: boolean
  display_order: number
  is_active: boolean
  created_at: number
  updated_at: number
}

export interface BramawiRecord {
  id: number
  payment_status: 'paid' | 'unpaid'
  payment_date?: number
  notes?: string
  created_at: number
  updated_at: number
  values?: Record<string, {
    value: string
    type: string
    label: string
  }>
}

export interface CreateBramawiFieldData {
  name: string
  type: 'text' | 'number' | 'date' | 'select' | 'calculated'
  label: string
  options?: string[]
  calculation_formula?: string
  dependent_fields?: string[]
  default_value?: string
  is_required?: boolean
  display_order?: number
}

export interface CreateBramawiRecordData {
  values: Record<string, any>
  notes?: string
}

export interface BramawiFilters {
  status?: 'paid' | 'unpaid'
  from?: number
  to?: number
  limit?: number
}

// أنواع المشاريع
export interface Project {
  id: number
  name: string
  code?: string
  description?: string
  status: 'active' | 'completed' | 'on_hold' | 'cancelled'
  start_date?: string
  end_date?: string
  budget?: number
  created_at: string
  updated_at: string
}

export interface CreateProjectData {
  name: string
  code?: string
  description?: string
  status?: 'active' | 'completed' | 'on_hold' | 'cancelled'
  start_date?: string
  end_date?: string
  budget?: number
}
