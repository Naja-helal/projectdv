# PowerShell Deployment Script

param(
    [switch]$NoBackup,
    [switch]$QuickDeploy
)

Write-Host "Starting deployment..." -ForegroundColor Green

# Server variables
$SERVER_USER = "root"
$SERVER_HOST = "91.108.112.8"
$SERVER_PATH = "/var/www/soqiamakkah.com/apps/salary"
$DOMAIN = "https://salary.soqiamakkah.com"

# Check SSH availability
if (-not (Get-Command ssh -ErrorAction SilentlyContinue)) {
    Write-Error "SSH not available. Please install OpenSSH or Git Bash"
    exit 1
}

Write-Host "Preparing files for upload..." -ForegroundColor Yellow

# Clean development files
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue @(
    "node_modules",
    "server/node_modules", 
    "web/node_modules",
    "web/dist",
    "server/dist",
    "*.log"
)

# Create project archive using PowerShell
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$archiveName = "salary-project-$timestamp.zip"

Write-Host "Creating project archive..." -ForegroundColor Yellow

# List of files and folders to compress
$itemsToCompress = @(
    "server",
    "web", 
    "package.json",
    "package-production.json",
    ".env.production",
    "README.md",
    "DEPLOYMENT.md"
)

# Create the archive
Compress-Archive -Path $itemsToCompress -DestinationPath $archiveName -Force

Write-Host "Uploading project to server..." -ForegroundColor Yellow

# Upload the compressed file
scp $archiveName "${SERVER_USER}@${SERVER_HOST}:/tmp/"

if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to upload file to server"
    exit 1
}

Write-Host "Installing project on server..." -ForegroundColor Yellow

# Server installation script
$remoteScript = @"
#!/bin/bash
set -e

echo "Starting project installation on server..."

# Go to project folder
cd /var/www/soqiamakkah.com/apps/salary

# Create backup if not disabled
if [ "$1" != "--no-backup" ] && [ -d "server" ]; then
    echo "Creating backup..."
    BACKUP_DIR="backup_`$(date +%Y%m%d_%H%M%S)"
    mkdir -p `$BACKUP_DIR
    mv server web package.json .env.production `$BACKUP_DIR/ 2>/dev/null || true
fi

# Extract new project
echo "Extracting project..."
unzip -o /tmp/salary-project-*.zip

# Install Node.js if not installed
if ! command -v node &> /dev/null; then
    echo "Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    apt-get install -y nodejs
fi

# Install main project libraries
echo "Installing main project libraries..."
npm install

# Install server libraries
echo "Installing server libraries..."
cd server
npm install

# Build server
echo "Building server..."
npm run build

# Go back to main folder and install frontend libraries
cd ../web
echo "Installing frontend libraries..."
npm install

# Build frontend for production
echo "Building frontend..."
npm run build

# Go back to main folder
cd ..

# Set file permissions
chmod +x server/dist/index.js 2>/dev/null || chmod +x server/src/index.ts
chown -R www-data:www-data . 2>/dev/null || true

echo "Project installed successfully!"
echo "Website available at: https://salary.soqiamakkah.com"

# Remove temporary file
rm -f /tmp/salary-project-*.zip

echo "Deployment completed successfully!"
"@

# Write script to temporary file and execute it
$remoteScript | ssh "${SERVER_USER}@${SERVER_HOST}" 'cat > /tmp/deploy_script.sh && chmod +x /tmp/deploy_script.sh && /tmp/deploy_script.sh'

if ($LASTEXITCODE -eq 0) {
    Write-Host "Deployment completed successfully!" -ForegroundColor Green
    Write-Host "Website available at: $DOMAIN" -ForegroundColor Cyan
    
    # Remove local archive
    Remove-Item $archiveName -Force
} else {
    Write-Error "Deployment failed"
    exit 1
}

Write-Host "Note: Make sure to run the server on the server using PM2 or systemd" -ForegroundColor Yellow