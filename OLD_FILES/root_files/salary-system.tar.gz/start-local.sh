#!/bin/bash
# سكربت تشغيل التطبيق محلياً

echo "🚀 تشغيل التطبيق محلياً..."

# التأكد من وجود ملفات البيئة
if [ ! -f "web/.env" ]; then
    echo "VITE_API_BASE=/api" > web/.env
fi

if [ ! -f "server/.env" ]; then
    echo "PORT=5175" > server/.env
    echo "DB_PATH=./expenses.db" >> server/.env
fi

# تشغيل التطبيق
npm start