module.exports = {
  apps: [{
    name: 'salary-server',
    script: 'npx',
    args: 'tsx server/src/index.ts',
    cwd: '/var/www/soqiamakkah.com/apps/salary',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: '3002',
      DB_PATH: '/var/www/soqiamakkah.com/apps/salary/server/expenses.db'
    },
    error_file: '/var/www/soqiamakkah.com/apps/salary/logs/error.log',
    out_file: '/var/www/soqiamakkah.com/apps/salary/logs/out.log',
    log_file: '/var/www/soqiamakkah.com/apps/salary/logs/combined.log',
    time: true
  }]
};