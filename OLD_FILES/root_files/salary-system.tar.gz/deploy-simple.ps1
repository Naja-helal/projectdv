# Simple PowerShell Deployment Script

Write-Host "Starting deployment..." -ForegroundColor Green

# Server variables
$SERVER_USER = "root"
$SERVER_HOST = "91.108.112.8"
$SERVER_PATH = "/var/www/soqiamakkah.com/apps/salary"
$DOMAIN = "https://salary.soqiamakkah.com"

# Check SSH availability
if (-not (Get-Command ssh -ErrorAction SilentlyContinue)) {
    Write-Error "SSH not available. Please install OpenSSH or Git Bash"
    exit 1
}

Write-Host "Preparing files for upload..." -ForegroundColor Yellow

# Clean development files
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue @(
    "node_modules",
    "server/node_modules", 
    "web/node_modules",
    "web/dist",
    "server/dist",
    "*.log"
)

# Create project archive using PowerShell
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$archiveName = "salary-project-$timestamp.zip"

Write-Host "Creating project archive..." -ForegroundColor Yellow

# List of files and folders to compress
$itemsToCompress = @(
    "server",
    "web", 
    "package.json",
    "package-production.json",
    ".env.production",
    "README.md",
    "DEPLOYMENT.md"
)

# Create the archive
Compress-Archive -Path $itemsToCompress -DestinationPath $archiveName -Force

Write-Host "Uploading project to server..." -ForegroundColor Yellow

# Upload the compressed file
scp $archiveName "${SERVER_USER}@${SERVER_HOST}:/tmp/"

if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to upload file to server"
    exit 1
}

# Upload the deployment script
scp "server-deploy.sh" "${SERVER_USER}@${SERVER_HOST}:/tmp/"

if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to upload deployment script"
    exit 1
}

Write-Host "Installing project on server..." -ForegroundColor Yellow

# Execute the deployment script on server
ssh "${SERVER_USER}@${SERVER_HOST}" 'chmod +x /tmp/server-deploy.sh && /tmp/server-deploy.sh'

if ($LASTEXITCODE -eq 0) {
    Write-Host "Deployment completed successfully!" -ForegroundColor Green
    Write-Host "Website available at: $DOMAIN" -ForegroundColor Cyan
    
    # Remove local archive
    Remove-Item $archiveName -Force
} else {
    Write-Error "Deployment failed"
    exit 1
}

Write-Host "Note: Make sure to run the server on the server using PM2 or systemd" -ForegroundColor Yellow