const Database = require('better-sqlite3');
const db = new Database('./expenses.db');

try {
  console.log('بدء إنشاء نظام السُلف والمديونيات...');

  // جدول السُلف والمديونيات
  db.exec(`
    CREATE TABLE IF NOT EXISTS employee_advances (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER NOT NULL,
      type TEXT CHECK (type IN ('advance', 'loan', 'debt')) DEFAULT 'advance',
      amount DECIMAL(10,2) NOT NULL,
      remaining_amount DECIMAL(10,2) NOT NULL,
      installments_count INTEGER DEFAULT 1,
      remaining_installments INTEGER DEFAULT 1,
      installment_amount DECIMAL(10,2) GENERATED ALWAYS AS (remaining_amount / remaining_installments) STORED,
      request_date DATE DEFAULT CURRENT_DATE,
      approval_date DATE,
      status TEXT CHECK (status IN ('pending', 'approved', 'rejected', 'completed')) DEFAULT 'pending',
      reason TEXT,
      notes TEXT,
      approved_by TEXT,
      auto_deduct BOOLEAN DEFAULT TRUE,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    );
  `);

  // جدول سجل خصومات السُلف من الرواتب
  db.exec(`
    CREATE TABLE IF NOT EXISTS advance_deductions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      advance_id INTEGER NOT NULL,
      salary_record_id INTEGER NOT NULL,
      deducted_amount DECIMAL(10,2) NOT NULL,
      deduction_date DATE DEFAULT CURRENT_DATE,
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (advance_id) REFERENCES employee_advances(id) ON DELETE CASCADE,
      FOREIGN KEY (salary_record_id) REFERENCES salary_records(id) ON DELETE CASCADE
    );
  `);

  console.log('تم إنشاء جداول السُلف بنجاح');

  // إضافة بعض السُلف التجريبية
  const insertAdvance = db.prepare(`
    INSERT OR IGNORE INTO employee_advances 
    (employee_id, type, amount, remaining_amount, installments_count, remaining_installments, reason, status, approval_date, approved_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // سُلف تجريبية
  insertAdvance.run(1, 'advance', 5000.00, 3000.00, 5, 3, 'سلفة للزواج', 'approved', '2025-09-01', 'مدير الموارد البشرية');
  insertAdvance.run(2, 'advance', 2000.00, 2000.00, 2, 2, 'سلفة طارئة', 'approved', '2025-09-05', 'مدير الموارد البشرية');
  insertAdvance.run(3, 'loan', 10000.00, 8000.00, 10, 8, 'قرض شخصي', 'approved', '2025-08-15', 'المدير العام');
  insertAdvance.run(4, 'advance', 1500.00, 1500.00, 1, 1, 'سلفة نهاية الشهر', 'pending', null, null);

  console.log('تم إضافة السُلف التجريبية');

  // إضافة سجلات خصومات تجريبية
  const insertDeduction = db.prepare(`
    INSERT OR IGNORE INTO advance_deductions 
    (advance_id, salary_record_id, deducted_amount, notes)
    VALUES (?, ?, ?, ?)
  `);

  // خصم من راتب أحمد (السلفة رقم 1)
  insertDeduction.run(1, 1, 1000.00, 'خصم القسط الأول من السلفة');
  insertDeduction.run(1, 5, 1000.00, 'خصم القسط الثاني من السلفة');

  // خصم من راتب محمد (القرض رقم 3)
  insertDeduction.run(3, 3, 1000.00, 'خصم القسط الشهري من القرض');

  console.log('تم إضافة سجلات الخصومات التجريبية');

  // عرض النتائج
  const advances = db.prepare(`
    SELECT ea.*, e.name as employee_name, e.position
    FROM employee_advances ea
    JOIN employees e ON ea.employee_id = e.id
    ORDER BY ea.created_at DESC
  `).all();
  
  console.log('\nالسُلف والمديونيات المضافة:');
  console.table(advances);

  // عرض سجل الخصومات
  const deductions = db.prepare(`
    SELECT ad.*, ea.amount as total_advance, e.name as employee_name
    FROM advance_deductions ad
    JOIN employee_advances ea ON ad.advance_id = ea.id
    JOIN employees e ON ea.employee_id = e.id
    ORDER BY ad.created_at DESC
  `).all();
  
  console.log('\nسجل خصومات السُلف:');
  console.table(deductions);

  // إحصائيات السُلف
  const stats = db.prepare(`
    SELECT 
      COUNT(*) as total_advances,
      SUM(amount) as total_amount,
      SUM(remaining_amount) as remaining_amount,
      COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
      COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved_count,
      COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_count
    FROM employee_advances
  `).get();
  
  console.log('\nإحصائيات السُلف:');
  console.table([stats]);

} catch (error) {
  console.error('خطأ:', error.message);
} finally {
  db.close();
}
