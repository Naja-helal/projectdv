const Database = require('better-sqlite3');
const db = new Database('./database.db');

try {
  console.log('بدء إنشاء جداول نظام الرواتب...');

  // جدول الموظفين
  db.exec(`
    CREATE TABLE IF NOT EXISTS employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      position TEXT,
      phone TEXT,
      email TEXT,
      national_id TEXT UNIQUE,
      hire_date DATE,
      department TEXT,
      base_salary DECIMAL(10,2) DEFAULT 0,
      salary_type TEXT CHECK (salary_type IN ('fixed', 'variable', 'mixed')) DEFAULT 'fixed',
      is_active BOOLEAN DEFAULT TRUE,
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // جدول كشوفات الرواتب الشهرية
  db.exec(`
    CREATE TABLE IF NOT EXISTS salary_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER NOT NULL,
      month INTEGER NOT NULL CHECK (month >= 1 AND month <= 12),
      year INTEGER NOT NULL,
      base_amount DECIMAL(10,2) DEFAULT 0,
      allowances DECIMAL(10,2) DEFAULT 0,
      deductions DECIMAL(10,2) DEFAULT 0,
      overtime_amount DECIMAL(10,2) DEFAULT 0,
      bonus DECIMAL(10,2) DEFAULT 0,
      total_amount DECIMAL(10,2) GENERATED ALWAYS AS (base_amount + allowances + overtime_amount + bonus - deductions) STORED,
      status TEXT CHECK (status IN ('pending', 'approved', 'paid', 'rejected')) DEFAULT 'pending',
      payment_date DATE,
      payment_method TEXT,
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
      UNIQUE(employee_id, month, year)
    );
  `);

  // جدول مرفقات الرواتب (PDF وملفات أخرى)
  db.exec(`
    CREATE TABLE IF NOT EXISTS salary_attachments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      salary_record_id INTEGER NOT NULL,
      file_name TEXT NOT NULL,
      file_path TEXT NOT NULL,
      file_type TEXT NOT NULL,
      file_size INTEGER,
      uploaded_by TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (salary_record_id) REFERENCES salary_records(id) ON DELETE CASCADE
    );
  `);

  // جدول تفاصيل البدلات والخصومات
  db.exec(`
    CREATE TABLE IF NOT EXISTS salary_details (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      salary_record_id INTEGER NOT NULL,
      type TEXT CHECK (type IN ('allowance', 'deduction')) NOT NULL,
      description TEXT NOT NULL,
      amount DECIMAL(10,2) NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (salary_record_id) REFERENCES salary_records(id) ON DELETE CASCADE
    );
  `);

  console.log('تم إنشاء جداول نظام الرواتب بنجاح');

  // إضافة بعض الموظفين التجريبيين
  const insertEmployee = db.prepare(`
    INSERT OR IGNORE INTO employees 
    (name, position, phone, base_salary, salary_type, department, hire_date)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  insertEmployee.run('أحمد محمد العلي', 'مدير المشروع', '0501234567', 8000.00, 'fixed', 'الإدارة', '2024-01-15');
  insertEmployee.run('سارة أحمد الحسن', 'محاسبة', '0509876543', 6000.00, 'fixed', 'المحاسبة', '2024-02-01');
  insertEmployee.run('محمد عبدالله السعيد', 'مطور', '0505551234', 7500.00, 'mixed', 'التقنية', '2024-03-10');
  insertEmployee.run('فاطمة علي المحمد', 'مصممة', '0507778899', 5500.00, 'variable', 'التصميم', '2024-04-01');

  console.log('تم إضافة الموظفين التجريبيين');

  // إضافة بعض كشوفات الرواتب التجريبية
  const insertSalary = db.prepare(`
    INSERT OR IGNORE INTO salary_records 
    (employee_id, month, year, base_amount, allowances, deductions, bonus, status, payment_date)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // رواتب شهر أغسطس 2025
  insertSalary.run(1, 8, 2025, 8000.00, 500.00, 200.00, 1000.00, 'paid', '2025-08-30');
  insertSalary.run(2, 8, 2025, 6000.00, 300.00, 100.00, 0.00, 'paid', '2025-08-30');
  insertSalary.run(3, 8, 2025, 7500.00, 800.00, 150.00, 500.00, 'approved', null);
  insertSalary.run(4, 8, 2025, 5500.00, 200.00, 50.00, 300.00, 'pending', null);

  // رواتب شهر سبتمبر 2025 (الشهر الحالي)
  insertSalary.run(1, 9, 2025, 8000.00, 500.00, 200.00, 0.00, 'pending', null);
  insertSalary.run(2, 9, 2025, 6000.00, 300.00, 100.00, 200.00, 'pending', null);

  console.log('تم إضافة كشوفات الرواتب التجريبية');

  // عرض النتائج
  const employees = db.prepare('SELECT * FROM employees WHERE is_active = 1').all();
  console.log('\nالموظفين المضافين:');
  console.table(employees);

  const salaries = db.prepare(`
    SELECT sr.*, e.name as employee_name 
    FROM salary_records sr 
    JOIN employees e ON sr.employee_id = e.id 
    ORDER BY sr.year DESC, sr.month DESC, e.name
  `).all();
  console.log('\nكشوفات الرواتب:');
  console.table(salaries);

} catch (error) {
  console.error('خطأ:', error.message);
} finally {
  db.close();
}
