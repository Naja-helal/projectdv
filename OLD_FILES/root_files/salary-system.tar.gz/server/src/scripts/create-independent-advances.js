const Database = require('better-sqlite3');
const db = new Database('./expenses.db');

try {
  console.log('بدء إنشاء نظام السُلف والمديونيات المستقل...');

  // جدول السُلف والمديونيات (بدون ربط بالرواتب)
  db.exec(`
    CREATE TABLE IF NOT EXISTS employee_advances (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER NOT NULL,
      type TEXT CHECK (type IN ('advance', 'loan', 'debt')) DEFAULT 'advance',
      amount DECIMAL(10,2) NOT NULL,
      paid_amount DECIMAL(10,2) DEFAULT 0,
      remaining_amount DECIMAL(10,2) GENERATED ALWAYS AS (amount - paid_amount) STORED,
      request_date DATE DEFAULT CURRENT_DATE,
      due_date DATE,
      approval_date DATE,
      completion_date DATE,
      status TEXT CHECK (status IN ('pending', 'approved', 'rejected', 'completed', 'overdue')) DEFAULT 'pending',
      priority TEXT CHECK (priority IN ('low', 'normal', 'high', 'urgent')) DEFAULT 'normal',
      reason TEXT,
      notes TEXT,
      approved_by TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    );
  `);

  // جدول مدفوعات السُلف (لتتبع التسديدات اليدوية)
  db.exec(`
    CREATE TABLE IF NOT EXISTS advance_payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      advance_id INTEGER NOT NULL,
      payment_amount DECIMAL(10,2) NOT NULL,
      payment_date DATE DEFAULT CURRENT_DATE,
      payment_method TEXT DEFAULT 'نقدي',
      notes TEXT,
      recorded_by TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (advance_id) REFERENCES employee_advances(id) ON DELETE CASCADE
    );
  `);

  // جدول مرفقات السُلف (عقود، طلبات، إيصالات)
  db.exec(`
    CREATE TABLE IF NOT EXISTS advance_attachments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      advance_id INTEGER NOT NULL,
      file_name TEXT NOT NULL,
      file_path TEXT NOT NULL,
      file_type TEXT NOT NULL,
      file_size INTEGER,
      description TEXT,
      uploaded_by TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (advance_id) REFERENCES employee_advances(id) ON DELETE CASCADE
    );
  `);

  console.log('تم إنشاء جداول السُلف المستقلة بنجاح');

  // إضافة بعض السُلف التجريبية
  const insertAdvance = db.prepare(`
    INSERT OR IGNORE INTO employee_advances 
    (employee_id, type, amount, paid_amount, reason, status, approval_date, approved_by, priority, due_date)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // سُلف مختلفة الأنواع والحالات
  insertAdvance.run(1, 'advance', 5000.00, 2000.00, 'سلفة للزواج', 'approved', '2025-09-01', 'مدير الموارد البشرية', 'normal', '2025-12-31');
  insertAdvance.run(2, 'advance', 2000.00, 0.00, 'سلفة طارئة', 'approved', '2025-09-05', 'مدير الموارد البشرية', 'urgent', '2025-10-15');
  insertAdvance.run(3, 'loan', 10000.00, 3000.00, 'قرض شخصي', 'approved', '2025-08-15', 'المدير العام', 'normal', '2026-08-15');
  insertAdvance.run(4, 'advance', 1500.00, 0.00, 'سلفة نهاية الشهر', 'pending', null, null, 'high', '2025-09-30');
  insertAdvance.run(1, 'debt', 800.00, 0.00, 'دين شخصي', 'approved', '2025-09-10', 'مدير الموارد البشرية', 'low', '2025-11-30');
  insertAdvance.run(3, 'advance', 3000.00, 1000.00, 'سلفة طبية', 'approved', '2025-09-08', 'مدير الموارد البشرية', 'urgent', '2025-10-31');

  console.log('تم إضافة السُلف التجريبية');

  // إضافة بعض المدفوعات التجريبية
  const insertPayment = db.prepare(`
    INSERT OR IGNORE INTO advance_payments 
    (advance_id, payment_amount, payment_date, payment_method, notes, recorded_by)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  insertPayment.run(1, 1000.00, '2025-09-05', 'تحويل بنكي', 'تسديد جزئي أول', 'المحاسب');
  insertPayment.run(1, 1000.00, '2025-09-10', 'نقدي', 'تسديد جزئي ثاني', 'المحاسب');
  insertPayment.run(3, 1500.00, '2025-09-01', 'تحويل بنكي', 'تسديد شهري', 'المحاسب');
  insertPayment.run(3, 1500.00, '2025-09-08', 'تحويل بنكي', 'تسديد شهري', 'المحاسب');
  insertPayment.run(6, 1000.00, '2025-09-12', 'نقدي', 'تسديد جزئي', 'المحاسب');

  console.log('تم إضافة المدفوعات التجريبية');

  // تحديث المبالغ المدفوعة
  db.exec(`
    UPDATE employee_advances SET paid_amount = (
      SELECT COALESCE(SUM(payment_amount), 0) 
      FROM advance_payments 
      WHERE advance_id = employee_advances.id
    )
  `);

  // تحديث الحالات المكتملة
  db.exec(`
    UPDATE employee_advances 
    SET status = 'completed', completion_date = CURRENT_DATE 
    WHERE paid_amount >= amount AND status != 'completed'
  `);

  console.log('تم تحديث المبالغ والحالات');

  // عرض النتائج
  const advances = db.prepare(`
    SELECT ea.*, e.name as employee_name, e.position,
           CASE ea.type 
             WHEN 'advance' THEN 'سلفة'
             WHEN 'loan' THEN 'قرض'
             WHEN 'debt' THEN 'دين'
           END as type_arabic,
           CASE ea.status
             WHEN 'pending' THEN 'قيد الانتظار'
             WHEN 'approved' THEN 'معتمد'
             WHEN 'rejected' THEN 'مرفوض'
             WHEN 'completed' THEN 'مكتمل'
             WHEN 'overdue' THEN 'متأخر'
           END as status_arabic
    FROM employee_advances ea
    JOIN employees e ON ea.employee_id = e.id
    ORDER BY ea.created_at DESC
  `).all();
  
  console.log('\nالسُلف والمديونيات:');
  console.table(advances.map(a => ({
    id: a.id,
    employee_name: a.employee_name,
    type_arabic: a.type_arabic,
    amount: a.amount,
    paid_amount: a.paid_amount,
    remaining_amount: a.remaining_amount,
    status_arabic: a.status_arabic,
    reason: a.reason,
    due_date: a.due_date
  })));

  // عرض المدفوعات
  const payments = db.prepare(`
    SELECT ap.*, ea.amount as total_advance, e.name as employee_name,
           CASE ea.type 
             WHEN 'advance' THEN 'سلفة'
             WHEN 'loan' THEN 'قرض' 
             WHEN 'debt' THEN 'دين'
           END as type_arabic
    FROM advance_payments ap
    JOIN employee_advances ea ON ap.advance_id = ea.id
    JOIN employees e ON ea.employee_id = e.id
    ORDER BY ap.created_at DESC
  `).all();
  
  console.log('\nسجل المدفوعات:');
  console.table(payments.map(p => ({
    id: p.id,
    employee_name: p.employee_name,
    type_arabic: p.type_arabic,
    payment_amount: p.payment_amount,
    payment_date: p.payment_date,
    payment_method: p.payment_method,
    notes: p.notes
  })));

  // إحصائيات مفصلة
  const stats = db.prepare(`
    SELECT 
      COUNT(*) as total_advances,
      SUM(amount) as total_amount,
      SUM(paid_amount) as total_paid,
      SUM(remaining_amount) as total_remaining,
      COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
      COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved_count,
      COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_count,
      COUNT(CASE WHEN type = 'advance' THEN 1 END) as advances_count,
      COUNT(CASE WHEN type = 'loan' THEN 1 END) as loans_count,
      COUNT(CASE WHEN type = 'debt' THEN 1 END) as debts_count
    FROM employee_advances
  `).get();
  
  console.log('\nإحصائيات شاملة:');
  console.table([{
    'إجمالي السجلات': stats.total_advances,
    'إجمالي المبالغ': stats.total_amount + ' ريال',
    'المدفوع': stats.total_paid + ' ريال',
    'المتبقي': stats.total_remaining + ' ريال',
    'قيد الانتظار': stats.pending_count,
    'معتمد': stats.approved_count,
    'مكتمل': stats.completed_count,
    'سُلف': stats.advances_count,
    'قروض': stats.loans_count,
    'ديون': stats.debts_count
  }]);

} catch (error) {
  console.error('خطأ:', error.message);
} finally {
  db.close();
}
