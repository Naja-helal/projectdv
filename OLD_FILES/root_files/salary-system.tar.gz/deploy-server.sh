#!/bin/bash
# سكربت نشر التطبيق على السيرفر

echo "🌐 نشر التطبيق على السيرفر..."

# المسار على السيرفر
SERVER_PATH="/var/www/soqiamakkah.com/apps/salary"

# إنشاء ملفات البيئة للإنتاج
echo "VITE_API_BASE=https://salary.soqiamakkah.com/api" > web/.env.production
echo "PORT=3001" > server/.env.production
echo "DB_PATH=/var/www/soqiamakkah.com/apps/salary/server/expenses.db" >> server/.env.production

# بناء التطبيق
npm run build

echo "✅ تم بناء التطبيق بنجاح!"
echo "📋 لرفع التطبيق على السيرفر، استخدم:"
echo "   rsync -avz --exclude node_modules . user@server:$SERVER_PATH"
echo "   ssh user@server 'cd $SERVER_PATH && npm run install:all && npm run start:prod'"