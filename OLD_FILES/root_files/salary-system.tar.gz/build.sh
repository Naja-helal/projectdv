#!/bin/bash

# Build script for production deployment
echo "🔄 Building Expense Tracker for production..."

# Install dependencies
echo "📦 Installing dependencies..."
npm run install:all

# Build backend
echo "🏗️ Building backend..."
cd server
npm run build
cd ..

# Build frontend  
echo "🎨 Building frontend..."
cd web
npm run build
cd ..

# Initialize database if needed
echo "🗄️ Setting up database..."
npm run db:init

echo "✅ Build completed successfully!"
echo "🚀 You can now run: npm start"