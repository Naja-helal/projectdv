# أنشئ/استبدل السكربت على السيرفر بصيغة لينكس
cat > /var/www/soqiamakkah.com/apps/salary/deploy_all.sh <<'BASH'
#!/bin/bash
set -e

# ===== إعدادات قابلة للتغيير =====
DOMAIN="${DOMAIN:-salary.soqiamakkah.com}"
APP_ROOT="${APP_ROOT:-/var/www/soqiamakkah.com/apps/salary}"
DEPLOY_DIR="${DEPLOY_DIR:-$APP_ROOT/deployment}"
PM2_NAME="${PM2_NAME:-salary-api}"
PORT="${PORT:-5175}"
DB_PATH="${DB_PATH:-$DEPLOY_DIR/expenses.db}"
# ==================================

echo "DOMAIN=$DOMAIN"
echo "APP_ROOT=$APP_ROOT"
echo "DEPLOY_DIR=$DEPLOY_DIR"
echo "PORT=$PORT"
echo "PM2=$PM2_NAME"
echo

# أدوات لازمة
command -v rsync >/dev/null || (apt-get update -y && apt-get install -y rsync)
command -v pm2   >/dev/null || npm i -g pm2

mkdir -p "$DEPLOY_DIR/web/dist" "$DEPLOY_DIR/server/dist"

# 1) بناء الواجهة (Vite ينتج dist/)
if [ -d "$APP_ROOT/web" ]; then
  cd "$APP_ROOT/web"
  (npm ci || npm install)
  npm run build
  rsync -a --delete dist/ "$DEPLOY_DIR/web/dist/"
fi

# 2) بناء السيرفر (لو Typescript يشغّل build؛ وإلا يتخطى)
if [ -d "$APP_ROOT/server" ]; then
  cd "$APP_ROOT/server"
  (npm ci || npm install)
  npm run build 2>/dev/null || true
  rsync -a --delete dist/ "$DEPLOY_DIR/server/dist/"
fi

# 3) package.json للإنتاج
if   [ -f "$APP_ROOT/package-production.json" ]; then
  cp "$APP_ROOT/package-production.json" "$DEPLOY_DIR/package.json"
elif [ -f "$APP_ROOT/package.json" ]; then
  cp "$APP_ROOT/package.json" "$DEPLOY_DIR/package.json"
fi

# 4) ملف البيئة
if   [ -f "$APP_ROOT/.env.production" ]; then
  cp "$APP_ROOT/.env.production" "$DEPLOY_DIR/.env"
elif [ -f "$DEPLOY_DIR/.env.production" ]; then
  cp "$DEPLOY_DIR/.env.production" "$DEPLOY_DIR/.env"
fi

# 5) قاعدة البيانات (إن وُجدت)
if [ -f "$APP_ROOT/expenses.db" ] && [ ! -f "$DEPLOY_DIR/expenses.db" ]; then
  cp "$APP_ROOT/expenses.db" "$DEPLOY_DIR/expenses.db"
fi
[ -f "$DEPLOY_DIR/expenses.db" ] && chmod 664 "$DEPLOY_DIR/expenses.db" || true

# 6) تثبيت تبعيات الإنتاج داخل deployment
if [ -f "$DEPLOY_DIR/package.json" ]; then
  cd "$DEPLOY_DIR"
  (npm ci --omit=dev || npm install --omit=dev)
fi

# 7) تحديد ملف الدخول وتشغيل PM2
ENTRY=""
for f in index.js server.js main.js app.js; do
  if [ -f "$DEPLOY_DIR/server/dist/$f" ]; then ENTRY="$DEPLOY_DIR/server/dist/$f"; break; fi
done
if [ -z "$ENTRY" ]; then
  echo "❌ لا يوجد ملف دخول تحت $DEPLOY_DIR/server/dist/"
  ls -la "$DEPLOY_DIR/server/dist/" || true
  exit 1
fi
echo "ENTRY=$ENTRY"

export NODE_ENV=production PORT DB_PATH
pm2 describe "$PM2_NAME" >/dev/null 2>&1 \
  && pm2 restart "$PM2_NAME" --update-env --time \
  || pm2 start "$ENTRY" --name "$PM2_NAME" --time

pm2 save
echo "✅ انتهى. فحص: pm2 logs $PM2_NAME --lines 200"
BASH

# صلاحية تشغيل
chmod +x /var/www/soqiamakkah.com/apps/salary/deploy_all.sh
