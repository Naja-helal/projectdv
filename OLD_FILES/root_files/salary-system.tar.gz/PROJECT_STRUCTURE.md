# هيكل وتنظيم مشروع نظام إدارة المصروفات

## 📁 الهيكل العام للمشروع

### 🟢 الملفات والصفحات المستخدمة حالياً (Active)

#### **💼 نظام الموظفين والرواتب الجديد**
- `web/src/pages/EmployeesPage.tsx` - صفحة إدارة الموظفين الجديدة
- `web/src/pages/SalariesPage.tsx` - صفحة إدارة الرواتب الجديدة
- `web/src/components/forms/EmployeeForm.tsx` - نموذج إضافة/تعديل الموظف
- `web/src/components/forms/EditSalaryDialog.tsx` - حوار تعديل الراتب
- `web/src/components/forms/SalaryDeliveryDialog.tsx` - حوار تسليم الراتب

#### **💰 نظام المصروفات**
- `web/src/pages/Expenses.tsx` - صفحة المصروفات الرئيسية
- `web/src/components/forms/ExpenseForm.tsx` - نموذج إضافة المصروفات

#### **📊 لوحة التحكم والتقارير**
- `web/src/pages/Dashboard.tsx` - لوحة التحكم الرئيسية
- `web/src/pages/Reports.tsx` - صفحة التقارير

#### **⚙️ الإعدادات**
- `web/src/pages/Settings.tsx` - صفحة الإعدادات الجديدة (مع تبويبات)

#### **🏷️ الفئات الجديدة**
- `web/src/pages/CategoriesPage.tsx` - صفحة إدارة الفئات الجديدة

#### **📦 المشاريع الجديدة**
- `web/src/pages/ProjectsPage.tsx` - صفحة إدارة المشاريع الجديدة

#### **🏪 الموردين الجديد**
- `web/src/pages/VendorsPage.tsx` - صفحة إدارة الموردين الجديدة

#### **📋 الصفحات الأخرى المستخدمة**
- `web/src/pages/Login.tsx` - صفحة تسجيل الدخول
- `web/src/pages/Bramawi.tsx` - نظام البرماوي
- `web/src/pages/Mosques.tsx` - إدارة المساجد
- `web/src/pages/Distributions.tsx` - إدارة التوزيع
- `web/src/pages/DynamicFields.tsx` - الحقول الديناميكية

#### **🔧 المكونات الأساسية**
- `web/src/components/layout/Layout.tsx` - تخطيط الصفحة الرئيسي
- `web/src/components/ProtectedRoute.tsx` - حماية المسارات
- `web/src/contexts/AuthContext.tsx` - سياق المصادقة
- `web/src/lib/api.ts` - واجهة برمجة التطبيقات
- `web/src/lib/utils.ts` - الوظائف المساعدة

---

### 🔴 الملفات المهجورة/القديمة (Deprecated)

#### **💸 نظام الرواتب القديم (محذوف)**
- ~~`web/src/pages/Salaries.tsx`~~ - **تم حذفه** - النظام القديم المعقد للرواتب

#### **📄 الصفحات القديمة (غير مستخدمة)**
- `web/src/pages/Categories.tsx` - نسخة قديمة من إدارة الفئات
- `web/src/pages/CategoriesNew.tsx` - نسخة وسطية (استبدلت بـ CategoriesPage.tsx)
- `web/src/pages/Projects.tsx` - نسخة قديمة من إدارة المشاريع  
- `web/src/pages/ProjectsNew.tsx` - نسخة وسطية (استبدلت بـ ProjectsPage.tsx)
- `web/src/pages/Vendors.tsx` - نسخة قديمة من إدارة الموردين
- `web/src/pages/VendorsNew.tsx` - نسخة وسطية (استبدلت بـ VendorsPage.tsx)
- `web/src/pages/ExpensesNew.tsx` - نسخة تجريبية من المصروفات
- `web/src/pages/SettingsNew.tsx` - نسخة قديمة من الإعدادات

---

## 🗄️ قاعدة البيانات

### **📊 الجداول المستخدمة حالياً**
- `employees` - بيانات الموظفين الجديدة
- `monthly_salaries` - الرواتب الشهرية الجديدة
- `settings_new` - إعدادات النظام الجديدة
- `expenses` - المصروفات
- `categories` - الفئات
- `projects` - المشاريع
- `vendors` - الموردين

### **🗑️ الجداول القديمة (قد تحتاج حذف)**
- جداول نظام الرواتب القديم المعقد
- الحقول الديناميكية القديمة

---

## 🔄 واجهات برمجة التطبيقات (APIs)

### **✅ المستخدمة حالياً**
- `/api/employees` - إدارة الموظفين
- `/api/salaries` - إدارة الرواتب الشهرية
- `/api/settings` - إدارة الإعدادات
- `/api/expenses` - إدارة المصروفات
- `/api/categories` - إدارة الفئات
- `/api/projects` - إدارة المشاريع
- `/api/vendors` - إدارة الموردين

### **❌ القديمة/المهجورة**
- جميع APIs النظام القديم للرواتب (salary_records, advances, leaves)

---

## 📋 قائمة المهام المستقبلية

### **🎯 تنظيف المشروع**
- [ ] حذف الملفات القديمة غير المستخدمة
- [ ] إزالة APIs القديمة من الخادم
- [ ] تنظيف قاعدة البيانات من الجداول غير المستخدمة
- [ ] تحديث أي مراجع للملفات القديمة

### **⚡ تحسينات مستقبلية**
- [ ] إضافة اختبارات للمكونات الجديدة
- [ ] تحسين التصميم المتجاوب
- [ ] إضافة ميزات البحث والفلترة المتقدمة
- [ ] تحسين الأداء وسرعة التحميل

---

## 📝 ملاحظات مهمة

1. **النظام الجديد للرواتب** يعتمد على مبدأ الراتب الشهري البسيط بدلاً من النظام المعقد القديم
2. **جميع الصفحات الجديدة** تستخدم React Query لإدارة الحالة
3. **النظام مصمم** ليكون بسيط وسهل الاستخدام
4. **قاعدة البيانات** تم تبسيطها لتقليل التعقيد

---

*آخر تحديث: 14 سبتمبر 2025*