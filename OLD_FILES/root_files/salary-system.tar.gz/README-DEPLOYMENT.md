# نظام إدارة المرتبات والمصروفات 💰

نظام شامل لإدارة المرتبات والمصروفات مع واجهة عربية سهلة الاستخدام.

## 🚀 التشغيل السريع

### التشغيل المحلي (للتطوير)
```bash
# تثبيت الحزم
npm run install:all

# إعداد قاعدة البيانات (أول مرة فقط)
npm run setup

# تشغيل التطبيق
npm start
```

**أو استخدم الملف المساعد:**
- على Windows: `start-local.bat`
- على Linux/Mac: `start-local.sh`

### الوصول للتطبيق
- **واجهة الويب:** http://localhost:3000/
- **API الخادم:** http://localhost:5175/

### بيانات تسجيل الدخول
- **اسم المستخدم:** admin
- **كلمة المرور:** A@asd123

## 🌐 النشر على السيرفر

### 1. إعداد ملفات البيئة للإنتاج
```bash
# سيتم إنشاؤها تلقائياً، أو قم بتعديلها يدوياً:
# web/.env.production
VITE_API_BASE=https://salary.soqiamakkah.com/api

# server/.env.production  
PORT=3001
DB_PATH=/var/www/soqiamakkah.com/apps/salary/server/expenses.db
```

### 2. بناء التطبيق
```bash
npm run build
```

### 3. النشر على السيرفر
```bash
# نسخ الملفات للسيرفر
rsync -avz --exclude node_modules . user@server:/var/www/soqiamakkah.com/apps/salary/

# على السيرفر
ssh user@server 'cd /var/www/soqiamakkah.com/apps/salary && npm run install:all && npm run start:prod'
```

**أو استخدم:** `./deploy-server.sh`

## 📂 هيكل المشروع

```
├── server/           # خادم API (Node.js + Express)
├── web/             # واجهة المستخدم (React + Vite)
├── start-local.*    # ملفات التشغيل المحلي
├── deploy-server.sh # نشر على السيرفر
└── package.json     # الإعدادات الرئيسية
```

## 🔧 الأوامر المتاحة

### التطوير
- `npm start` - تشغيل الخادم والواجهة معاً
- `npm run dev` - نفس `start`
- `npm run dev:server` - تشغيل الخادم فقط
- `npm run dev:web` - تشغيل الواجهة فقط

### البناء والنشر
- `npm run build` - بناء التطبيق للإنتاج
- `npm run start:prod` - تشغيل النسخة المبنية

### قاعدة البيانات
- `npm run db:init` - إنشاء الجداول
- `npm run db:seed` - إضافة بيانات تجريبية
- `npm run setup` - إعداد كامل (تثبيت + إنشاء + بيانات)

## 🔄 التبديل بين البيئات

التطبيق يدعم التشغيل في بيئتين:

### محلياً (Local Development)
- يستخدم ملفات `.env`
- الخادم على `localhost:5175`
- الواجهة على `localhost:3000`

### على السيرفر (Production)
- يستخدم ملفات `.env.production`
- يعمل على `https://salary.soqiamakkah.com`
- API على مسار `/api`

## 🛠️ متطلبات النظام

- Node.js 18+ 
- npm 9+
- SQLite3

## 📝 المميزات

- ✅ إدارة المرتبات والمصروفات
- ✅ نظام مصادقة آمن
- ✅ واجهة عربية متجاوبة
- ✅ قاعدة بيانات SQLite محلية
- ✅ دعم البيئات المتعددة
- ✅ سهولة النشر

## 🔗 الروابط المهمة

- **الموقع المباشر:** https://salary.soqiamakkah.com/
- **مسار السيرفر:** `/var/www/soqiamakkah.com/apps/salary`

---

💡 **نصيحة:** استخدم `npm start` للتطوير المحلي و `npm run start:prod` للإنتاج