# خريطة مسارات الاستيراد والملفات

## 📁 ملف App.tsx - المسارات الرئيسية

```typescript
// ✅ المسارات المستخدمة حالياً
import Dashboard from './pages/Dashboard'
import Login from './pages/Login'
import Reports from './pages/Reports'
import Expenses from './pages/Expenses'
import Categories from './pages/Categories'           // ⚠️ قديم
import CategoriesPage from './pages/CategoriesPage'   // ✅ جديد
import Projects from './pages/Projects'             // ⚠️ قديم  
import ProjectsPage from './pages/ProjectsPage'     // ✅ جديد
import Vendors from './pages/Vendors'               // ⚠️ قديم
import VendorsPage from './pages/VendorsPage'       // ✅ جديد
import Bramawi from './pages/Bramawi'
import Settings from './pages/Settings'             // ✅ جديد
import DynamicFields from './pages/DynamicFields'
import Mosques from './pages/Mosques'
import Distributions from './pages/Distributions'
import EmployeesPage from './pages/EmployeesPage'   // ✅ جديد
import SalariesPage from './pages/SalariesPage'     // ✅ جديد

// ❌ تم إزالتها
// import Salaries from './pages/Salaries'          // حُذف - النظام القديم
```

## 🔄 مخطط الترقية للملفات

### الفئات (Categories)
- `Categories.tsx` ➜ `CategoriesPage.tsx` ✅
- الحالة: **تم الترقية**

### المشاريع (Projects)  
- `Projects.tsx` ➜ `ProjectsPage.tsx` ✅
- الحالة: **تم الترقية**

### الموردين (Vendors)
- `Vendors.tsx` ➜ `VendorsPage.tsx` ✅  
- الحالة: **تم الترقية**

### الرواتب (Salaries)
- `Salaries.tsx` ➜ `SalariesPage.tsx` ✅
- الحالة: **تم الترقية والاستبدال**

### الإعدادات (Settings)
- `SettingsNew.tsx` ➜ `Settings.tsx` ✅
- الحالة: **تم الترقية**

## 📋 قائمة الملفات للحذف المستقبلي

### ملفات الصفحات القديمة
```
web/src/pages/Categories.tsx        // ❌ قديم
web/src/pages/CategoriesNew.tsx     // ❌ وسطي  
web/src/pages/Projects.tsx          // ❌ قديم
web/src/pages/ProjectsNew.tsx       // ❌ وسطي
web/src/pages/Vendors.tsx           // ❌ قديم
web/src/pages/VendorsNew.tsx        // ❌ وسطي
web/src/pages/ExpensesNew.tsx       // ❌ تجريبي
web/src/pages/SettingsNew.tsx       // ❌ قديم
```

### نماذج قديمة غير مستخدمة
```
web/src/components/forms/AddCategoryForm.tsx    // تحقق من الاستخدام
web/src/components/forms/EditCategoryForm.tsx   // تحقق من الاستخدام
web/src/components/forms/DeleteCategoryDialog.tsx
// ... والعديد من النماذج القديمة
```

## 🎯 خطة التنظيف المستقبلية

### المرحلة 1: تحليل الاستخدام
```bash
# البحث عن استيرادات الملفات القديمة
grep -r "Categories.tsx" web/src/
grep -r "Projects.tsx" web/src/  
grep -r "Vendors.tsx" web/src/
```

### المرحلة 2: الحذف الآمن
1. التأكد من عدم استخدام الملف في أي مكان
2. حذف الملف
3. اختبار النظام للتأكد من عدم وجود أخطاء

### المرحلة 3: تنظيف قاعدة البيانات
1. تحديد الجداول غير المستخدمة
2. أخذ نسخة احتياطية
3. حذف الجداول القديمة

## 🔧 أدوات مساعدة للتنظيف

### سكريبت البحث عن الملفات غير المستخدمة
```javascript
// يمكن إنشاء سكريبت Node.js للبحث عن:
// 1. الملفات غير المستوردة
// 2. المتغيرات غير المستخدمة  
// 3. الوظائف المهجورة
```

---

*هذا الملف يساعد في فهم هيكل المشروع والتخطيط للتنظيف المستقبلي*