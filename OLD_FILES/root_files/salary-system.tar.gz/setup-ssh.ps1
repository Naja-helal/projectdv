# SSH Configuration for automatic password handling
# ملف إعدادات SSH للاتصال التلقائي

# Create SSH directory if it doesn't exist
$sshDir = "$env:USERPROFILE\.ssh"
if (-not (Test-Path $sshDir)) {
    New-Item -ItemType Directory -Path $sshDir -Force
}

# SSH Config content
$sshConfig = @"
Host salary-server
    HostName 91.108.112.8
    User root
    Port 22
    ServerAliveInterval 60
    ServerAliveCountMax 3
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
"@

# Write SSH config
$sshConfig | Out-File -FilePath "$sshDir\config" -Encoding ASCII -Force

Write-Host "SSH config created successfully!" -ForegroundColor Green
Write-Host "You can now connect using: ssh salary-server" -ForegroundColor Cyan
Write-Host "Password: Where500@#500" -ForegroundColor Yellow