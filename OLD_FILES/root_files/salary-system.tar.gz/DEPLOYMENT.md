# Deployment Guide - نظام إدارة المصروفات

## 🚀 للنشر على Hostinger

### الخطوة 1: إعداد المشروع محلياً
```bash
# تثبيت التبعيات وبناء المشروع
npm run setup
npm run build

# أو استخدم السكريبت الجاهز
./build.sh  # لينكس/ماك
# أو
build.bat   # ويندوز
```

### الخطوة 2: تحضير ملفات النشر
الملفات المطلوبة للرفع على الخادم:
```
📁 deployment/
├── 📄 package.json (من package-production.json)
├── 📁 server/
│   └── 📁 dist/ (الباك إند المبني)
├── 📁 web/
│   └── 📁 dist/ (الفرونت إند المبني)
├── 📄 expenses.db (قاعدة البيانات)
└── 📄 .env.production
```

### الخطوة 3: إعداد Hostinger
1. **رفع الملفات**: ارفع محتويات مجلد deployment إلى public_html
2. **تثبيت التبعيات**: في Terminal الخاص بـ Hostinger:
   ```bash
   cd public_html
   npm install
   ```
3. **تشغيل التطبيق**:
   ```bash
   NODE_ENV=production npm start
   ```

### الخطوة 4: إعداد PM2 (للاستقرار)
```bash
# تثبيت PM2
npm install -g pm2

# تشغيل التطبيق
pm2 start server/dist/index.js --name "expense-tracker"

# حفظ التكوين
pm2 save
pm2 startup
```

## 🔧 متغيرات البيئة
```env
NODE_ENV=production
PORT=5175
DB_PATH=./expenses.db
```

## 📊 مراقبة التطبيق
```bash
# مراقبة حالة التطبيق
pm2 status

# مراقبة السجلات
pm2 logs expense-tracker

# إعادة تشغيل
pm2 restart expense-tracker
```

## 🌐 الوصول للتطبيق
بعد النشر، يمكن الوصول للتطبيق عبر:
- `https://yourdomain.com` - الواجهة الأمامية
- `https://yourdomain.com/health` - فحص صحة الخادم

## 🆘 استكشاف الأخطاء
- تأكد من وجود Node.js 18+ على الخادم
- تحقق من صلاحيات الكتابة لملف قاعدة البيانات
- راجع سجلات الأخطاء في pm2 logs