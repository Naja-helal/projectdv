# 🚀 دليل النشر التلقائي - نظام إدارة الرواتب

## معلومات السيرفر
```
العنوان: 91.108.112.8
المستخدم: root  
كلمة المرور: Where500@#500
مسار المشروع: /var/www/soqiamakkah.com/apps/salary/
رابط الموقع: https://salary.soqiamakkah.com/
```

## 🎯 النشر السريع (خطوة واحدة)

```powershell
# تشغيل سكريبت النشر التلقائي
.\deploy.ps1
```

## 📋 الخطوات اليدوية (للمتقدمين)

### 1. إعداد SSH التلقائي
```powershell
.\setup-ssh.ps1
```

### 2. رفع المشروع
```bash
# ضغط المشروع
tar -czf salary-project.tar.gz --exclude='node_modules' --exclude='.git' .

# رفع للسيرفر  
scp salary-project.tar.gz root@91.108.112.8:/tmp/
```

### 3. تنصيب على السيرفر
```bash
ssh root@91.108.112.8
cd /var/www/soqiamakkah.com/apps/salary
tar -xzf /tmp/salary-project.tar.gz
npm install && cd server && npm install && npm run build && cd ../web && npm install && npm run build && cd ..
```

### 4. تشغيل النظام
```bash
# باستخدام PM2
npm install -g pm2
mkdir -p logs  
pm2 start ecosystem.config.js --env production
pm2 save && pm2 startup
```

## ✅ التحقق من النشر
- زيارة: https://salary.soqiamakkah.com/
- دخول بـ: admin / A@asd123

## 🔧 استكشاف الأخطاء
```bash
# فحص الحالة
pm2 status
pm2 logs salary-server

# إعادة تشغيل
pm2 restart salary-server
```