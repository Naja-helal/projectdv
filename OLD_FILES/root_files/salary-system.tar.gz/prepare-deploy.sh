#!/bin/bash

# Deployment preparation script
echo "📦 Preparing deployment package..."

# Create deployment directory
mkdir -p deployment
cd deployment

# Copy production package.json
cp ../package-production.json package.json

# Copy built server
mkdir -p server
cp -r ../server/dist server/

# Copy built web app
mkdir -p web  
cp -r ../web/dist web/

# Copy database (if exists)
if [ -f "../server/expenses.db" ]; then
    cp ../server/expenses.db expenses.db
    echo "✅ Database copied"
else
    echo "⚠️ Database not found - will be created on first run"
fi

# Copy environment file
cp ../.env.production .env

# Create .htaccess for Apache (if needed)
cat > .htaccess << 'EOF'
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^api/ - [L]
RewriteRule . /index.html [L]
EOF

echo "✅ Deployment package ready in 'deployment' folder"
echo "📁 Upload the contents of 'deployment' folder to your web server"