#!/bin/bash
set -e

echo "Starting project installation on server..."

# Go to project folder
cd /var/www/soqiamakkah.com/apps/salary

# Create backup if not disabled
if [ "$1" != "--no-backup" ] && [ -d "server" ]; then
    echo "Creating backup..."
    BACKUP_DIR="backup_$(date +%Y%m%d_%H%M%S)"
    mkdir -p $BACKUP_DIR
    mv server web package.json .env.production $BACKUP_DIR/ 2>/dev/null || true
fi

# Install unzip if not available
if ! command -v unzip &> /dev/null; then
    echo "Installing unzip..."
    apt-get update
    apt-get install -y unzip
fi

# Extract new project
echo "Extracting project..."
LATEST_ARCHIVE=$(ls -t /tmp/salary-project-*.zip 2>/dev/null | head -n1)
if [ -n "$LATEST_ARCHIVE" ]; then
    unzip -o "$LATEST_ARCHIVE"
else
    echo "Error: No archive file found"
    exit 1
fi

# Install Node.js if not installed
if ! command -v node &> /dev/null; then
    echo "Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    apt-get install -y nodejs
fi

# Install main project libraries
echo "Installing main project libraries..."
npm install

# Install server libraries
echo "Installing server libraries..."
cd server
npm install

# Build server
echo "Building server..."
npm run build

# Go back to main folder and install frontend libraries
cd ../web
echo "Installing frontend libraries..."
npm install

# Build frontend for production
echo "Building frontend..."
npm run build

# Go back to main folder
cd ..

# Set file permissions
chmod +x server/dist/index.js 2>/dev/null || chmod +x server/src/index.ts
chown -R www-data:www-data . 2>/dev/null || true

echo "Project installed successfully!"
echo "Website available at: https://salary.soqiamakkah.com"

# Remove temporary file
rm -f /tmp/salary-project-*.zip

echo "Deployment completed successfully!"