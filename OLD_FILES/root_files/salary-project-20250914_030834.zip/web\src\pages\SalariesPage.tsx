import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

import { 
  Calendar, 
  DollarSign, 
  Users, 
  CheckCircle2, 
  Clock,
  Plus,
  Banknote,
  User,
  AlertCircle,
  Edit
} from 'lucide-react'
import { salariesApi } from '@/lib/api'
import type { MonthlySalary } from '@/types'
import { formatCurrency, getMonthName } from '@/lib/utils'
import SalaryDeliveryDialog from '../components/forms/SalaryDeliveryDialog'
import EditSalaryDialog from '../components/forms/EditSalaryDialog'

export default function SalariesPage() {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1)
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())
  const [deliveryDialogOpen, setDeliveryDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [selectedSalary, setSelectedSalary] = useState<MonthlySalary | null>(null)
  
  const queryClient = useQueryClient()

  // جلب الرواتب
  const { data: salaries = [], isLoading } = useQuery({
    queryKey: ['salaries', selectedMonth, selectedYear],
    queryFn: () => salariesApi.getAll({ month: selectedMonth, year: selectedYear }),
  })

  // توليد رواتب الشهر
  const generateMutation = useMutation({
    mutationFn: salariesApi.generate,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['salaries'] })
    },
  })

  const handleGenerateMonth = async () => {
    if (window.confirm(`هل تريد توليد رواتب شهر ${getMonthName(selectedMonth)} ${selectedYear}؟`)) {
      try {
        await generateMutation.mutateAsync({ 
          month: selectedMonth, 
          year: selectedYear 
        })
      } catch (error) {
        console.error('خطأ في توليد الرواتب:', error)
      }
    }
  }

  const handleDeliveryClick = (salary: MonthlySalary) => {
    setSelectedSalary(salary)
    setDeliveryDialogOpen(true)
  }

  const handleDeliveryDialogClose = () => {
    setDeliveryDialogOpen(false)
    setSelectedSalary(null)
  }

  const handleEditClick = (salary: MonthlySalary) => {
    setSelectedSalary(salary)
    setEditDialogOpen(true)
  }

  const handleEditDialogClose = () => {
    setEditDialogOpen(false)
    setSelectedSalary(null)
  }

  // إحصائيات الشهر
  const stats = {
    total: salaries.length,
    delivered: salaries.filter(s => s.is_delivered).length,
    pending: salaries.filter(s => !s.is_delivered).length,
    totalAmount: salaries.reduce((sum, s) => sum + s.salary_amount, 0),
    deliveredAmount: salaries.filter(s => s.is_delivered).reduce((sum, s) => sum + s.salary_amount, 0),
    totalDebt: salaries.reduce((sum, s) => sum + s.debt_amount, 0),
  }

  const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - 2 + i)
  const months = Array.from({ length: 12 }, (_, i) => i + 1)

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid gap-4 md:grid-cols-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-24 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <DollarSign className="h-8 w-8 text-green-600" />
          <div>
            <h1 className="text-2xl font-bold text-gray-900">الرواتب الشهرية</h1>
            <p className="text-sm text-gray-500">
              {getMonthName(selectedMonth)} {selectedYear}
            </p>
          </div>
        </div>
        
        <Button 
          onClick={handleGenerateMonth} 
          className="gap-2"
          disabled={generateMutation.isPending}
        >
          <Plus className="h-4 w-4" />
          {generateMutation.isPending ? 'جاري التوليد...' : 'توليد رواتب الشهر'}
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-4 items-center">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium">فلترة بالتاريخ:</span>
            </div>
            
            <select 
              value={selectedMonth} 
              onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
              className="px-3 py-2 border border-gray-300 rounded-md bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {months.map((month) => (
                <option key={month} value={month}>
                  {getMonthName(month)}
                </option>
              ))}
            </select>

            <select 
              value={selectedYear} 
              onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              className="px-3 py-2 border border-gray-300 rounded-md bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {years.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-blue-600" />
              <span className="text-sm text-gray-600">إجمالي الموظfين</span>
            </div>
            <div className="text-2xl font-bold mt-1">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <span className="text-sm text-gray-600">تم التسليم</span>
            </div>
            <div className="text-2xl font-bold mt-1 text-green-600">{stats.delivered}</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-orange-600" />
              <span className="text-sm text-gray-600">في الانتظار</span>
            </div>
            <div className="text-2xl font-bold mt-1 text-orange-600">{stats.pending}</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-green-600" />
              <span className="text-sm text-gray-600">إجمالي المبلغ</span>
            </div>
            <div className="text-lg font-bold mt-1">{formatCurrency(stats.totalAmount)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Additional Stats */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Banknote className="h-4 w-4 text-green-600" />
              <span className="text-sm text-gray-600">المبلغ المسلم</span>
            </div>
            <div className="text-lg font-bold mt-1 text-green-600">
              {formatCurrency(stats.deliveredAmount)}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {stats.total > 0 ? Math.round((stats.delivered / stats.total) * 100) : 0}% من الموظفين
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <span className="text-sm text-gray-600">إجمالي الديون</span>
            </div>
            <div className="text-lg font-bold mt-1 text-red-600">
              {formatCurrency(stats.totalDebt)}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              من {salaries.filter(s => s.debt_amount > 0).length} موظف
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Salaries List */}
      {salaries.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <DollarSign className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              لا توجد رواتب لهذا الشهر
            </h3>
            <p className="text-gray-500 mb-4">
              ابدأ بتوليد رواتب شهر {getMonthName(selectedMonth)} {selectedYear}
            </p>
            <Button onClick={handleGenerateMonth} className="gap-2">
              <Plus className="h-4 w-4" />
              توليد الرواتب
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {salaries.map((salary) => (
            <Card key={salary.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="h-5 w-5 text-blue-600" />
                    </div>
                    
                    <div>
                      <h3 className="font-medium">{salary.employee_name}</h3>
                      {salary.position && (
                        <p className="text-sm text-gray-500">{salary.position}</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="font-medium">{formatCurrency(salary.salary_amount)}</div>
                      {salary.debt_amount > 0 && (
                        <div className="text-sm text-red-600">
                          دين: {formatCurrency(salary.debt_amount)}
                        </div>
                      )}
                    </div>

                    <Badge 
                      variant={salary.is_delivered ? "default" : "secondary"}
                      className={salary.is_delivered ? "bg-green-100 text-green-800" : "bg-orange-100 text-orange-800"}
                    >
                      {salary.is_delivered ? (
                        <><CheckCircle2 className="h-3 w-3 mr-1" /> تم التسليم</>
                      ) : (
                        <><Clock className="h-3 w-3 mr-1" /> في الانتظار</>
                      )}
                    </Badge>

                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEditClick(salary)}
                        className="gap-1"
                      >
                        <Edit className="h-3 w-3" />
                        تعديل
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeliveryClick(salary)}
                      >
                        {salary.is_delivered ? 'تفاصيل' : 'تسليم'}
                      </Button>
                    </div>
                  </div>
                </div>

                {salary.delivery_date && (
                  <div className="mt-3 pt-3 border-t text-sm text-gray-500">
                    تاريخ التسليم: {new Date(salary.delivery_date).toLocaleDateString('ar-SA')}
                    {salary.notes && (
                      <div className="mt-1">
                        ملاحظات: {salary.notes}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Delivery Dialog */}
      <SalaryDeliveryDialog
        open={deliveryDialogOpen}
        onClose={handleDeliveryDialogClose}
        salary={selectedSalary}
      />

      <EditSalaryDialog
        salary={selectedSalary}
        open={editDialogOpen}
        onOpenChange={handleEditDialogClose}
      />
    </div>
  )
}