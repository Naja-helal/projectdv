import { useState, useEffect } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { bramawiApi } from '@/lib/api'
import type { BramawiField, BramawiRecord } from '@/types'
import { Calculator } from 'lucide-react'

interface BramawiFormProps {
  fields: BramawiField[]
  open: boolean
  onClose: () => void
  editRecord?: BramawiRecord | null
}

export default function BramawiForm({ fields, open, onClose, editRecord }: BramawiFormProps) {
  const [formData, setFormData] = useState<Record<string, any>>({})
  const [calculatedValues, setCalculatedValues] = useState<Record<string, number>>({})
  const [notes, setNotes] = useState('')

  const queryClient = useQueryClient()
  const isEditing = Boolean(editRecord)

  // إضافة سجل جديد
  const createMutation = useMutation({
    mutationFn: bramawiApi.createRecord,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bramawi-records'] })
      resetForm()
      onClose()
    }
  })

  // تحديث سجل موجود
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: { values: Record<string, any>; notes: string } }) =>
      bramawiApi.updateRecord(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bramawi-records'] })
      resetForm()
      onClose()
    }
  })

  // تعيين القيم الافتراضية أو قيم التعديل عند فتح النموذج
  useEffect(() => {
    if (open && fields.length > 0) {
      const newFormData: Record<string, any> = {}
      
      if (editRecord?.values) {
        // في حالة التعديل، استخدم القيم الموجودة
        Object.keys(editRecord.values).forEach(fieldName => {
          const fieldValue = editRecord.values?.[fieldName];
          if (fieldValue && fieldValue.value !== undefined) {
            newFormData[fieldName] = fieldValue.value;
          }
        });
        setNotes(editRecord.notes || '');
      } else {
        // في حالة الإضافة، استخدم القيم الافتراضية
        fields.forEach(field => {
          if (field.default_value) {
            newFormData[field.name] = field.default_value
          }
        })
        setNotes('');
      }
      
      setFormData(newFormData)
    }
  }, [open, fields.length, editRecord])

  // حساب القيم المحسوبة
  useEffect(() => {
    const newCalculatedValues: Record<string, number> = {}

    fields.forEach(field => {
      if (field.type === 'calculated' && field.calculation_formula && field.dependent_fields) {
        try {
          let formula = field.calculation_formula
          let canCalculate = true



          // استبدال أسماء الحقول بالقيم
          field.dependent_fields?.forEach(depField => {
            const value = parseFloat(formData[depField]) || 0
            if (isNaN(value) && formData[depField] !== undefined) {
              canCalculate = false
            }
            formula = formula.replace(new RegExp(depField, 'g'), value.toString())
          })

          if (canCalculate) {
            // تقييم المعادلة الرياضية البسيطة
            const result = evaluateFormula(formula)
            if (!isNaN(result)) {
              newCalculatedValues[field.name] = result
            }
          }
        } catch (error) {
          console.error('خطأ في حساب الصيغة:', error)
        }
      }
    })

    setCalculatedValues(newCalculatedValues)
  }, [formData, fields])

  // تقييم المعادلات الرياضية البسيطة
  const evaluateFormula = (formula: string): number => {
    try {
      // تنظيف الصيغة من المحارف غير الآمنة
      const cleanFormula = formula.replace(/[^0-9+\-*/.() ]/g, '')
      
      // استخدام Function للتقييم الآمن
      return Function('"use strict"; return (' + cleanFormula + ')')()
    } catch {
      return NaN
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // جمع جميع القيم (المدخلة + المحسوبة)
    const allValues = {
      ...formData,
      ...Object.fromEntries(
        Object.entries(calculatedValues).map(([key, value]) => [key, value.toString()])
      )
    }

    if (isEditing && editRecord) {
      updateMutation.mutate({
        id: editRecord.id,
        data: {
          values: allValues,
          notes
        }
      })
    } else {
      createMutation.mutate({
        values: allValues,
        notes
      })
    }
  }

  const resetForm = () => {
    setFormData({})
    setCalculatedValues({})
    setNotes('')
  }

  const handleFieldChange = (fieldName: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [fieldName]: value
    }))
  }

  const renderField = (field: BramawiField) => {
    if (field.type === 'calculated') {
      return (
        <div key={field.id} className="space-y-2">
          <Label className="flex items-center gap-2">
            <Calculator className="h-4 w-4 text-blue-600" />
            {field.label}
          </Label>
          <div className="p-3 bg-blue-50 rounded-md border">
            <p className="text-lg font-bold text-blue-800">
              {calculatedValues[field.name]?.toFixed(2) || '0.00'}
            </p>
            {field.calculation_formula && (
              <p className="text-xs text-muted-foreground mt-1">
                {field.calculation_formula}
              </p>
            )}
          </div>
        </div>
      )
    }

    switch (field.type) {
      case 'number':
        return (
          <div key={field.id} className="space-y-2">
            <Label>
              {field.label}
              {field.is_required && <span className="text-red-500 mr-1">*</span>}
            </Label>
            <Input
              type="number"
              step="any"
              value={formData[field.name] || ''}
              onChange={(e) => handleFieldChange(field.name, e.target.value)}
              required={field.is_required}
              placeholder={`أدخل ${field.label}`}
            />
          </div>
        )

      case 'text':
        return (
          <div key={field.id} className="space-y-2">
            <Label>
              {field.label}
              {field.is_required && <span className="text-red-500 mr-1">*</span>}
            </Label>
            <Input
              type="text"
              value={formData[field.name] || ''}
              onChange={(e) => handleFieldChange(field.name, e.target.value)}
              required={field.is_required}
              placeholder={`أدخل ${field.label}`}
            />
          </div>
        )

      case 'date':
        return (
          <div key={field.id} className="space-y-2">
            <Label>
              {field.label}
              {field.is_required && <span className="text-red-500 mr-1">*</span>}
            </Label>
            <Input
              type="date"
              value={formData[field.name] || ''}
              onChange={(e) => handleFieldChange(field.name, e.target.value)}
              required={field.is_required}
            />
          </div>
        )

      case 'select':
        return (
          <div key={field.id} className="space-y-2">
            <Label>
              {field.label}
              {field.is_required && <span className="text-red-500 mr-1">*</span>}
            </Label>
            <select
              value={formData[field.name] || ''}
              onChange={(e) => handleFieldChange(field.name, e.target.value)}
              required={field.is_required}
              className="w-full p-2 border rounded-md bg-background"
            >
              <option value="">اختر {field.label}</option>
              {field.options?.map((option, index) => (
                <option key={index} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" aria-describedby="dialog-description">
        <DialogHeader>
          <DialogTitle>{isEditing ? 'تعديل البيانات' : 'إضافة بيانات جديدة'}</DialogTitle>
          <div id="dialog-description" className="sr-only">
            {isEditing ? 'نموذج لتعديل بيانات البرماوي' : 'نموذج لإضافة بيانات جديدة للبرماوي'}
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {fields.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-muted-foreground">
                  لا توجد حقول محددة. يرجى إضافة الحقول من صفحة الإعدادات أولاً.
                </p>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* الحقول الديناميكية */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {fields
                  .sort((a, b) => a.display_order - b.display_order)
                  .map(renderField)}
              </div>

              {/* الملاحظات */}
              <div className="space-y-2">
                <Label>ملاحظات إضافية</Label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="أدخل أي ملاحظات إضافية..."
                  rows={3}
                />
              </div>

              {/* أزرار التحكم */}
              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={onClose}>
                  إلغاء
                </Button>
                <Button 
                  type="submit" 
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {(createMutation.isPending || updateMutation.isPending) 
                    ? 'جاري الحفظ...' 
                    : isEditing 
                      ? 'حفظ التعديلات' 
                      : 'حفظ البيانات'
                  }
                </Button>
              </div>
            </>
          )}
        </form>
      </DialogContent>
    </Dialog>
  )
}
