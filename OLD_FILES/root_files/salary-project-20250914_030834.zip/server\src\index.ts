import express from "express";
import Database from "better-sqlite3";
import cors from "cors";
import compression from "compression";
import path from "path";
import dotenv from "dotenv";

// تحميل متغيرات البيئة
if (process.env.NODE_ENV === 'production') {
  dotenv.config({ path: '.env.production' });
} else {
  dotenv.config();
}

// إنشاء التطبيق
const app = express();
const PORT = process.env.PORT || 5175;

// إعداد قاعدة البيانات
const dbPath = process.env.DB_PATH || path.join(__dirname, "../expenses.db");
const db = new Database(dbPath);

// بيانات الأدمن الثابتة
const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "A@asd123";

// middleware للتحقق من التوثيق
const authenticateAdmin = (req: any, res: any, next: any) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  if (!token) {
    return res.status(401).json({ error: "مطلوب تسجيل الدخول" });
  }

  try {
    // فك تشفير الرمز المميز البسيط
    const decoded = Buffer.from(token, 'base64').toString();
    const [username, timestamp] = decoded.split(':');
    
    if (username !== ADMIN_USERNAME) {
      return res.status(401).json({ error: "رمز التوثيق غير صالح" });
    }

    // التحقق من صلاحية الرمز (24 ساعة)
    const tokenTime = parseInt(timestamp);
    const currentTime = Date.now();
    const tokenAge = currentTime - tokenTime;
    const maxAge = 24 * 60 * 60 * 1000; // 24 ساعة بالميللي ثانية

    if (tokenAge > maxAge) {
      return res.status(401).json({ error: "انتهت صلاحية جلسة تسجيل الدخول، يرجى تسجيل الدخول مرة أخرى" });
    }

    next();
  } catch (error) {
    res.status(401).json({ error: "رمز التوثيق غير صالح" });
  }
};

// إعداد المتوسطات (Middleware)
app.use(cors());
app.use(compression());
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// خدمة الملفات الثابتة للإنتاج
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../../web/dist')));
}

// التحقق من صلاحية الرمز المميز
app.get("/api/auth/verify", authenticateAdmin, (req, res) => {
  res.json({
    ok: true,
    message: "الرمز المميز صالح"
  });
});

// تجديد الرمز المميز
app.post("/api/auth/refresh", authenticateAdmin, (req, res) => {
  try {
    const newToken = Buffer.from(`${ADMIN_USERNAME}:${Date.now()}`).toString('base64');
    res.json({
      ok: true,
      token: newToken,
      message: "تم تجديد الرمز المميز بنجاح"
    });
  } catch (error) {
    res.status(500).json({ error: "فشل في تجديد الرمز المميز" });
  }
});

// تسجيل دخول الأدمن
app.post("/api/auth/login", (req, res) => {
  try {
    const { username, password } = req.body;

    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      // إنشاء رمز مميز بسيط (في بيئة الإنتاج استخدم JWT)
      const token = Buffer.from(`${username}:${Date.now()}`).toString('base64');
      
      res.json({
        ok: true,
        token,
        message: "تم تسجيل الدخول بنجاح"
      });
    } else {
      res.status(401).json({
        error: "اسم المستخدم أو كلمة المرور غير صحيحة"
      });
    }
  } catch (error) {
    console.error("خطأ في تسجيل الدخول:", error);
    res.status(500).json({ error: "خطأ في الخادم" });
  }
});

// مسار الصحة
app.get("/health", (req, res) => {
  res.json({ 
    ok: true, 
    timestamp: Date.now(),
    database: "connected"
  });
});

// =========================
// مسارات الفئات (Categories)
// =========================

app.get("/api/categories", authenticateAdmin, (req, res) => {
  try {
    const rows = db.prepare(`
      SELECT id, name, code, color, icon, description, created_at, updated_at
      FROM categories 
      ORDER BY name
    `).all();
    res.json(rows);
  } catch (error) {
    console.error("خطأ في جلب الفئات:", error);
    res.status(500).json({ error: "خطأ في جلب الفئات" });
  }
});

app.post("/api/categories", (req, res) => {
  try {
    const { name, code, color, icon, description } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: "اسم الفئة مطلوب" });
    }

    const stmt = db.prepare(`
      INSERT INTO categories (name, code, color, icon, description) 
      VALUES (?, ?, ?, ?, ?)
    `);
    
    const info = stmt.run(
      name,
      code || null,
      color || "#3b82f6",
      icon || null,
      description || null
    );
    
    res.json({ id: info.lastInsertRowid, success: true });
  } catch (error: any) {
    console.error("خطأ في إضافة الفئة:", error);
    if (error.code === "SQLITE_CONSTRAINT_UNIQUE") {
      res.status(400).json({ error: "رمز الفئة مستخدم مسبقاً" });
    } else {
      res.status(500).json({ error: "خطأ في إضافة الفئة" });
    }
  }
});

app.patch("/api/categories/:id", (req, res) => {
  try {
    const id = +req.params.id;
    const { name, code, color, icon, description } = req.body;
    
    const existing = db.prepare("SELECT * FROM categories WHERE id = ?").get(id);
    if (!existing) {
      return res.status(404).json({ error: "الفئة غير موجودة" });
    }

    const stmt = db.prepare(`
      UPDATE categories SET 
        name = COALESCE(?, name),
        code = COALESCE(?, code),
        color = COALESCE(?, color),
        icon = COALESCE(?, icon),
        description = COALESCE(?, description),
        updated_at = strftime('%s','now')
      WHERE id = ?
    `);
    
    stmt.run(name, code, color, icon, description, id);
    res.json({ ok: true, success: true });
  } catch (error: any) {
    console.error("خطأ في تحديث الفئة:", error);
    if (error.code === "SQLITE_CONSTRAINT_UNIQUE") {
      res.status(400).json({ error: "رمز الفئة مستخدم مسبقاً" });
    } else {
      res.status(500).json({ error: "خطأ في تحديث الفئة" });
    }
  }
});

app.delete("/api/categories/:id", (req, res) => {
  try {
    const id = +req.params.id;
    
    // تحقق من وجود مصروفات مرتبطة
    const expensesCount = db.prepare("SELECT COUNT(*) as count FROM expenses WHERE category_id = ?").get(id) as { count: number };
    if (expensesCount.count > 0) {
      return res.status(400).json({ error: `لا يمكن حذف الفئة لوجود ${expensesCount.count} مصروف مرتبط بها` });
    }
    
    const result = db.prepare("DELETE FROM categories WHERE id = ?").run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "الفئة غير موجودة" });
    }
    
    res.json({ ok: true, success: true });
  } catch (error) {
    console.error("خطأ في حذف الفئة:", error);
    res.status(500).json({ error: "خطأ في حذف الفئة" });
  }
});

// =========================
// مسارات المورّدين (Vendors)
// =========================

app.get("/api/vendors", (req, res) => {
  try {
    const rows = db.prepare(`
      SELECT id, name, contact, email, phone, address, tax_number, created_at, updated_at
      FROM vendors 
      ORDER BY name
    `).all();
    res.json(rows);
  } catch (error) {
    console.error("خطأ في جلب المورّدين:", error);
    res.status(500).json({ error: "خطأ في جلب المورّدين" });
  }
});

app.post("/api/vendors", (req, res) => {
  try {
    const { name, contact, email, phone, address, tax_number } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: "اسم المورّد مطلوب" });
    }

    const stmt = db.prepare(`
      INSERT INTO vendors (name, contact, email, phone, address, tax_number) 
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    
    const info = stmt.run(
      name,
      contact || null,
      email || null,
      phone || null,
      address || null,
      tax_number || null
    );
    
    res.json({ id: info.lastInsertRowid, success: true });
  } catch (error) {
    console.error("خطأ في إضافة المورّد:", error);
    res.status(500).json({ error: "خطأ في إضافة المورّد" });
  }
});

app.patch("/api/vendors/:id", (req, res) => {
  try {
    const id = +req.params.id;
    const { name, contact, email, phone, address, tax_number } = req.body;
    
    const existing = db.prepare("SELECT * FROM vendors WHERE id = ?").get(id);
    if (!existing) {
      return res.status(404).json({ error: "المورّد غير موجود" });
    }

    const stmt = db.prepare(`
      UPDATE vendors SET 
        name = COALESCE(?, name),
        contact = COALESCE(?, contact),
        email = COALESCE(?, email),
        phone = COALESCE(?, phone),
        address = COALESCE(?, address),
        tax_number = COALESCE(?, tax_number),
        updated_at = strftime('%s','now')
      WHERE id = ?
    `);
    
    stmt.run(name, contact, email, phone, address, tax_number, id);
    res.json({ ok: true, success: true });
  } catch (error) {
    console.error("خطأ في تحديث المورّد:", error);
    res.status(500).json({ error: "خطأ في تحديث المورّد" });
  }
});

app.delete("/api/vendors/:id", (req, res) => {
  try {
    const id = +req.params.id;
    
    // تحقق من وجود مصروفات مرتبطة
    const expensesCount = db.prepare("SELECT COUNT(*) as count FROM expenses WHERE vendor_id = ?").get(id) as any;
    if (expensesCount.count > 0) {
      return res.status(400).json({ error: `لا يمكن حذف المورّد لوجود ${expensesCount.count} مصروف مرتبط به` });
    }
    
    const result = db.prepare("DELETE FROM vendors WHERE id = ?").run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "المورّد غير موجود" });
    }
    
    res.json({ ok: true, success: true });
  } catch (error) {
    console.error("خطأ في حذف المورّد:", error);
    res.status(500).json({ error: "خطأ في حذف المورّد" });
  }
});

// =========================
// مسارات المصروفات (Expenses)
// =========================

app.get("/api/expenses", (req, res) => {
  try {
    const { from, to, categoryId, projectId, vendorId, q, limit = 100 } = req.query;
    
    const where: string[] = [];
    const params: any[] = [];

    if (from) { 
      where.push("e.date >= ?"); 
      params.push(+from); 
    }
    if (to) { 
      where.push("e.date <= ?"); 
      params.push(+to); 
    }
    if (categoryId) { 
      where.push("e.category_id = ?"); 
      params.push(+categoryId); 
    }
    if (vendorId) { 
      where.push("e.vendor_id = ?"); 
      params.push(+vendorId); 
    }
    if (q) { 
      where.push("(e.reference LIKE ? OR e.notes LIKE ? OR e.invoice_number LIKE ?)"); 
      params.push(`%${q}%`, `%${q}%`, `%${q}%`); 
    }

    const sql = `
      SELECT 
        e.*,
        c.name AS category_name,
        c.color AS category_color,
        c.icon AS category_icon,
        v.name AS vendor_name
      FROM expenses e
      LEFT JOIN categories c ON c.id = e.category_id
      LEFT JOIN vendors v ON v.id = e.vendor_id
      ${where.length ? "WHERE " + where.join(" AND ") : ""}
      ORDER BY e.date DESC, e.id DESC
      LIMIT ?
    `;
    
    const rows = db.prepare(sql).all(...params, +limit);
    
    // إضافة الحقول المخصصة
    const expenseIds = rows.map((row: any) => row.id);
    if (expenseIds.length > 0) {
      const customValues = db.prepare(`
        SELECT cv.entity_id, cv.field_key, cv.value, cf.name as field_name, cf.type
        FROM custom_values cv
        JOIN custom_fields cf ON cf.key = cv.field_key AND cf.entity = cv.entity
        WHERE cv.entity = 'expense' AND cv.entity_id IN (${expenseIds.map(() => '?').join(',')})
      `).all(...expenseIds);
      
      // ربط الحقول المخصصة بالمصروفات
      const customByExpense: any = {};
      customValues.forEach((cv: any) => {
        if (!customByExpense[cv.entity_id]) {
          customByExpense[cv.entity_id] = {};
        }
        customByExpense[cv.entity_id][cv.field_key] = {
          value: cv.value,
          name: cv.field_name,
          type: cv.type
        };
      });
      
      rows.forEach((row: any) => {
        row.custom_fields = customByExpense[row.id] || {};
        if (row.extra) {
          try {
            row.extra_data = JSON.parse(row.extra);
          } catch {
            row.extra_data = {};
          }
        }
      });
    }
    
    res.json(rows);
  } catch (error) {
    console.error("خطأ في جلب المصروفات:", error);
    res.status(500).json({ error: "خطأ في جلب المصروفات" });
  }
});

app.post("/api/expenses", (req, res) => {
  try {
    const {
      categoryId, vendorId,
      amount, taxRate = 0, date,
      paymentMethod, reference, invoiceNumber, notes, 
      extra, customFields
    } = req.body;

    // التحقق من البيانات المطلوبة
    if (!categoryId || !amount || !date) {
      return res.status(400).json({ error: "الفئة والمبلغ والتاريخ مطلوبة" });
    }

    // حساب الضريبة والإجمالي
    const taxAmount = +(amount * (taxRate / 100)).toFixed(2);
    const totalAmount = +(amount + taxAmount).toFixed(2);

    const stmt = db.prepare(`
      INSERT INTO expenses
        (category_id, vendor_id, amount, currency, tax_rate, tax_amount, salary_amount,
         date, payment_method, reference, invoice_number, notes, extra)
      VALUES (?, ?, ?, 'SAR', ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    const info = stmt.run(
      categoryId, 
      vendorId || null, 
      amount, 
      taxRate, 
      taxAmount, 
      totalAmount,
      date, 
      paymentMethod || null, 
      reference || null,
      invoiceNumber || null,
      notes || null,
      extra ? JSON.stringify(extra) : null
    );

    const expenseId = info.lastInsertRowid;

    // حفظ الحقول المخصصة
    if (customFields && typeof customFields === 'object') {
      const customStmt = db.prepare(`
        INSERT OR REPLACE INTO custom_values (entity, entity_id, field_key, value)
        VALUES ('expense', ?, ?, ?)
      `);
      
      for (const [key, value] of Object.entries(customFields)) {
        if (value !== null && value !== undefined && value !== '') {
          customStmt.run(expenseId, key, String(value));
        }
      }
    }

    res.json({ 
      id: expenseId, 
      totalAmount, 
      taxAmount,
      success: true 
    });
  } catch (error) {
    console.error("خطأ في إضافة المصروف:", error);
    res.status(500).json({ error: "خطأ في إضافة المصروف" });
  }
});

app.patch("/api/expenses/:id", (req, res) => {
  try {
    const id = +req.params.id;
    
    // التحقق من وجود المصروف
    const existing = db.prepare("SELECT * FROM expenses WHERE id = ?").get(id);
    if (!existing) {
      return res.status(404).json({ error: "المصروف غير موجود" });
    }

    const data = { ...existing, ...req.body };
    
    // التأكد من وجود التاريخ وتحويله إلى timestamp إذا لزم الأمر
    if (!data.date) {
      return res.status(400).json({ error: "التاريخ مطلوب" });
    }
    
    // تحويل التاريخ إلى timestamp إذا كان string
    let dateValue = data.date;
    if (typeof dateValue === 'string') {
      dateValue = new Date(dateValue).getTime();
    }
    
    // إعادة حساب الضريبة والإجمالي
    const taxAmount = +(data.amount * ((data.taxRate || 0) / 100)).toFixed(2);
    const totalAmount = +(data.amount + taxAmount).toFixed(2);

    const stmt = db.prepare(`
      UPDATE expenses SET
        category_id=?, vendor_id=?,
        amount=?, currency='SAR', tax_rate=?, tax_amount=?, salary_amount=?,
        date=?, payment_method=?, reference=?, invoice_number=?, notes=?, extra=?,
        updated_at=strftime('%s','now')
      WHERE id=?
    `);
    
    stmt.run(
      data.categoryId, 
      data.vendorId || null,
      data.amount, 
      data.taxRate || 0, 
      taxAmount, 
      totalAmount,
      dateValue, 
      data.paymentMethod || null, 
      data.reference || null,
      data.invoiceNumber || null,
      data.notes || null,
      data.extra ? JSON.stringify(data.extra) : null,
      id
    );

    // تحديث الحقول المخصصة
    if (req.body.customFields && typeof req.body.customFields === 'object') {
      // حذف القيم القديمة
      db.prepare("DELETE FROM custom_values WHERE entity = 'expense' AND entity_id = ?").run(id);
      
      // إضافة القيم الجديدة
      const customStmt = db.prepare(`
        INSERT INTO custom_values (entity, entity_id, field_key, value)
        VALUES ('expense', ?, ?, ?)
      `);
      
      for (const [key, value] of Object.entries(req.body.customFields)) {
        if (value !== null && value !== undefined && value !== '') {
          customStmt.run(id, key, String(value));
        }
      }
    }

    res.json({ 
      ok: true, 
      totalAmount, 
      taxAmount,
      success: true 
    });
  } catch (error) {
    console.error("خطأ في تحديث المصروف:", error);
    res.status(500).json({ error: "خطأ في تحديث المصروف" });
  }
});

app.delete("/api/expenses/:id", (req, res) => {
  try {
    const id = +req.params.id;
    
    // حذف الحقول المخصصة المرتبطة
    db.prepare("DELETE FROM custom_values WHERE entity = 'expense' AND entity_id = ?").run(id);
    
    // حذف المصروف
    const result = db.prepare("DELETE FROM expenses WHERE id = ?").run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "المصروف غير موجود" });
    }
    
    res.json({ ok: true, success: true });
  } catch (error) {
    console.error("خطأ في حذف المصروف:", error);
    res.status(500).json({ error: "خطأ في حذف المصروف" });
  }
});

// =========================
// مسارات الحقول المخصصة
// =========================

app.get("/api/custom-fields", (req, res) => {
  try {
    const { entity } = req.query;
    
    let sql = "SELECT * FROM custom_fields";
    const params: any[] = [];
    
    if (entity) {
      sql += " WHERE entity = ?";
      params.push(entity);
    }
    
    sql += " ORDER BY sort_order, name";
    
    const rows = db.prepare(sql).all(...params);
    
    // تحويل options من JSON إلى object
    rows.forEach((row: any) => {
      if (row.options) {
        try {
          row.options = JSON.parse(row.options);
        } catch {
          row.options = null;
        }
      }
    });
    
    res.json(rows);
  } catch (error) {
    console.error("خطأ في جلب الحقول المخصصة:", error);
    res.status(500).json({ error: "خطأ في جلب الحقول المخصصة" });
  }
});

app.post("/api/custom-fields", (req, res) => {
  try {
    const { entity, name, key, type, options, required, sortOrder } = req.body;
    
    if (!entity || !name || !key || !type) {
      return res.status(400).json({ error: "جميع الحقول الأساسية مطلوبة" });
    }

    const stmt = db.prepare(`
      INSERT INTO custom_fields (entity, name, key, type, options, required, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    
    const info = stmt.run(
      entity,
      name,
      key,
      type,
      options ? JSON.stringify(options) : null,
      required ? 1 : 0,
      sortOrder || 0
    );
    
    res.json({ id: info.lastInsertRowid, success: true });
  } catch (error: any) {
    console.error("خطأ في إضافة الحقل المخصص:", error);
    if (error.code === "SQLITE_CONSTRAINT_UNIQUE") {
      res.status(400).json({ error: "مفتاح الحقل مستخدم مسبقاً" });
    } else {
      res.status(500).json({ error: "خطأ في إضافة الحقل المخصص" });
    }
  }
});

// =========================
// مسارات التقارير والإحصائيات الشاملة
// =========================

app.get("/api/reports/overview", authenticateAdmin, (req, res) => {
  try {
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1;
    
    // إحصائيات عامة
    const totalExpenses = db.prepare("SELECT COUNT(*) as count, SUM(salary_amount) as total FROM expenses").get();
    const totalCategories = db.prepare("SELECT COUNT(*) as count FROM categories").get();
    const totalVendors = db.prepare("SELECT COUNT(*) as count FROM vendors").get();
    const totalEmployees = db.prepare("SELECT COUNT(*) as count FROM employees WHERE is_active = 1").get();
    
    // المصروفات هذا الشهر
    const thisMonthStart = new Date(currentYear, currentMonth - 1, 1).getTime();
    const thisMonthEnd = new Date(currentYear, currentMonth, 0, 23, 59, 59).getTime();
    const thisMonthExpenses = db.prepare(`
      SELECT COUNT(*) as count, COALESCE(SUM(salary_amount), 0) as total 
      FROM expenses 
      WHERE date >= ? AND date <= ?
    `).get(thisMonthStart, thisMonthEnd);
    
    // الرواتب هذا الشهر
    const thisMonthSalaries = db.prepare(`
      SELECT COUNT(*) as count, COALESCE(SUM(salary_amount), 0) as total 
      FROM monthly_salaries 
      WHERE month = ? AND year = ?
    `).get(currentMonth, currentYear);
    
    // السُلف المعلقة
    const pendingAdvances = db.prepare(`
      SELECT COUNT(*) as count, COALESCE(SUM(remaining_amount), 0) as total 
      FROM employee_advances 
      WHERE status = 'approved'
    `).get();
    
    res.json({
      overview: {
        total_expenses: totalExpenses,
        total_categories: totalCategories,
        total_vendors: totalVendors,
        total_employees: totalEmployees,
        this_month_expenses: thisMonthExpenses,
        this_month_salaries: thisMonthSalaries,
        pending_advances: pendingAdvances
      }
    });
  } catch (error) {
    console.error("خطأ في جلب النظرة العامة:", error);
    res.status(500).json({ error: "خطأ في جلب النظرة العامة" });
  }
});

app.get("/api/reports/expenses", authenticateAdmin, (req, res) => {
  try {
    // المصروفات حسب الفئة
    const byCategory = db.prepare(`
      SELECT 
        c.name,
        c.color,
        c.icon,
        COUNT(e.id) as count,
        SUM(e.amount) as total
      FROM categories c
      LEFT JOIN expenses e ON c.id = e.category_id
      GROUP BY c.id, c.name, c.color, c.icon
      ORDER BY total DESC
    `).all();
    
    // المصروفات الشهرية (آخر 12 شهر)
    const monthlyExpenses = db.prepare(`
      SELECT 
        strftime('%Y-%m', datetime(date/1000, 'unixepoch')) as month,
        COUNT(*) as count,
        SUM(salary_amount) as total
      FROM expenses
      WHERE date >= strftime('%s', 'now', '-12 months') * 1000
      GROUP BY strftime('%Y-%m', datetime(date/1000, 'unixepoch'))
      ORDER BY month
    `).all();
    
    // أكبر المصروفات
    const topExpenses = db.prepare(`
      SELECT 
        e.amount,
        e.notes,
        c.name as category_name,
        v.name as vendor_name,
        datetime(e.date/1000, 'unixepoch') as date
      FROM expenses e
      LEFT JOIN categories c ON e.category_id = c.id
      LEFT JOIN vendors v ON e.vendor_id = v.id
      ORDER BY e.amount DESC
      LIMIT 10
    `).all();
    
    res.json({
      by_category: byCategory,
      monthly_trend: monthlyExpenses,
      top_expenses: topExpenses
    });
  } catch (error) {
    console.error("خطأ في جلب تقارير المصروفات:", error);
    res.status(500).json({ error: "خطأ في جلب تقارير المصروفات" });
  }
});

app.get("/api/reports/salaries", authenticateAdmin, (req, res) => {
  try {
    // إجمالي الرواتب حسب الشهر
    const monthlySalaries = db.prepare(`
      SELECT 
        month,
        year,
        COUNT(*) as employee_count,
        SUM(salary_amount) as salary_amount,
        AVG(salary_amount) as avg_salary
      FROM monthly_salaries
      WHERE year >= strftime('%Y', 'now', '-1 year')
      GROUP BY year, month
      ORDER BY year DESC, month DESC
      LIMIT 12
    `).all();
    
    // الرواتب حسب القسم
    const byDepartment = db.prepare(`
      SELECT 
        e.position,
        COUNT(DISTINCT e.id) as employee_count,
        AVG(e.monthly_salary) as avg_base_salary,
        SUM(sr.salary_amount) as total_paid
      FROM employees e
      LEFT JOIN monthly_salaries sr ON e.id = sr.employee_id
      WHERE e.is_active = 1
      GROUP BY e.position
      ORDER BY total_paid DESC
    `).all();
    
    // حالة الرواتب
    const salaryStatus = db.prepare(`
      SELECT 
        status,
        COUNT(*) as count,
        SUM(salary_amount) as total
      FROM monthly_salaries
      WHERE year = strftime('%Y', 'now') AND month = strftime('%m', 'now')
      GROUP BY status
    `).all();
    
    res.json({
      monthly_salaries: monthlySalaries,
      by_department: byDepartment,
      salary_status: salaryStatus
    });
  } catch (error) {
    console.error("خطأ في جلب تقارير الرواتب:", error);
    res.status(500).json({ error: "خطأ في جلب تقارير الرواتب" });
  }
});

app.get("/api/reports/advances", authenticateAdmin, (req, res) => {
  try {
    // إحصائيات السُلف
    const advancesStats = db.prepare(`
      SELECT 
        type,
        status,
        COUNT(*) as count,
        SUM(amount) as salary_amount,
        SUM(remaining_amount) as remaining_amount
      FROM employee_advances
      GROUP BY type, status
      ORDER BY type, status
    `).all();
    
    // السُلف حسب الموظف
    const byEmployee = db.prepare(`
      SELECT 
        e.name as employee_name,
        e.position,
        COUNT(ea.id) as advance_count,
        SUM(ea.amount) as salary_amount,
        SUM(ea.remaining_amount) as remaining_amount
      FROM employees e
      LEFT JOIN employee_advances ea ON e.id = ea.employee_id
      WHERE e.is_active = 1
      GROUP BY e.id, e.name, e.position
      HAVING advance_count > 0
      ORDER BY remaining_amount DESC
    `).all();
    
    res.json({
      advances_stats: advancesStats,
      by_employee: byEmployee
    });
  } catch (error) {
    console.error("خطأ في جلب تقارير السُلف:", error);
    res.status(500).json({ error: "خطأ في جلب تقارير السُلف" });
  }
});

// =========================
// مسارات الإحصائيات (الأصلية)
// =========================

app.get("/api/stats", authenticateAdmin, (req, res) => {
  try {
    const { from, to, projectId, categoryId } = req.query;
    
    const where: string[] = [];
    const params: any[] = [];
    
    if (from) { where.push("date >= ?"); params.push(+from); }
    if (to) { where.push("date <= ?"); params.push(+to); }
    if (categoryId) { where.push("category_id = ?"); params.push(+categoryId); }
    
    const whereClause = where.length ? "WHERE " + where.join(" AND ") : "";
    
    // الإجمالي
    const total = db.prepare(`
      SELECT 
        COUNT(*) as count,
        COALESCE(SUM(salary_amount), 0) as total,
        COALESCE(SUM(amount), 0) as subtotal,
        COALESCE(SUM(tax_amount), 0) as tax
      FROM expenses ${whereClause}
    `).get(...params);
    
    // حسب الفئة
    const byCategory = db.prepare(`
      SELECT 
        c.name, c.color, c.icon,
        COUNT(*) as count,
        COALESCE(SUM(e.amount), 0) as total
      FROM expenses e
      JOIN categories c ON c.id = e.category_id
      ${whereClause}
      GROUP BY e.category_id, c.name, c.color, c.icon
      ORDER BY total DESC
      LIMIT 10
    `).all(...params);
    
    res.json({
      total,
      byCategory,
      currency: "SAR"
    });
  } catch (error) {
    console.error("خطأ في جلب الإحصائيات:", error);
    res.status(500).json({ error: "خطأ في جلب الإحصائيات" });
  }
});

// =========================
// مسارات البرماوي (Bramawi)
// =========================

// جلب حقول البرماوي الديناميكية
app.get("/api/bramawi/fields", (req, res) => {
  try {
    const rows = db.prepare(`
      SELECT * FROM bramawi_fields 
      WHERE is_active = 1 
      ORDER BY display_order, id
    `).all();
    
    // تحويل options و dependent_fields من JSON
    rows.forEach((row: any) => {
      if (row.options) {
        try {
          row.options = JSON.parse(row.options);
        } catch {
          row.options = null;
        }
      }
      if (row.dependent_fields) {
        try {
          row.dependent_fields = JSON.parse(row.dependent_fields);
        } catch {
          row.dependent_fields = null;
        }
      }
    });
    
    res.json(rows);
  } catch (error) {
    console.error("خطأ في جلب حقول البرماوي:", error);
    res.status(500).json({ error: "خطأ في جلب حقول البرماوي" });
  }
});

// إضافة حقل جديد للبرماوي
app.post("/api/bramawi/fields", (req, res) => {
  try {
    const { name, type, label, options, calculation_formula, dependent_fields, default_value, is_required, display_order } = req.body;
    
    if (!name || !type || !label) {
      return res.status(400).json({ error: "الاسم والنوع والعنوان مطلوبة" });
    }

    const stmt = db.prepare(`
      INSERT INTO bramawi_fields (name, type, label, options, calculation_formula, dependent_fields, default_value, is_required, display_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    const info = stmt.run(
      name,
      type,
      label,
      options ? JSON.stringify(options) : null,
      calculation_formula || null,
      dependent_fields ? JSON.stringify(dependent_fields) : null,
      default_value || null,
      is_required ? 1 : 0,
      display_order || 0
    );
    
    res.json({ id: info.lastInsertRowid, success: true });
  } catch (error: any) {
    console.error("خطأ في إضافة حقل البرماوي:", error);
    res.status(500).json({ error: "خطأ في إضافة حقل البرماوي" });
  }
});

// تحديث حقل البرماوي
app.patch("/api/bramawi/fields/:id", (req, res) => {
  try {
    const id = +req.params.id;
    const { name, type, label, options, calculation_formula, dependent_fields, default_value, is_required, display_order } = req.body;
    
    const stmt = db.prepare(`
      UPDATE bramawi_fields SET
        name = COALESCE(?, name),
        type = COALESCE(?, type),
        label = COALESCE(?, label),
        options = COALESCE(?, options),
        calculation_formula = COALESCE(?, calculation_formula),
        dependent_fields = COALESCE(?, dependent_fields),
        default_value = COALESCE(?, default_value),
        is_required = COALESCE(?, is_required),
        display_order = COALESCE(?, display_order),
        updated_at = strftime('%s','now')
      WHERE id = ?
    `);
    
    stmt.run(
      name,
      type,
      label,
      options ? JSON.stringify(options) : null,
      calculation_formula,
      dependent_fields ? JSON.stringify(dependent_fields) : null,
      default_value,
      is_required !== undefined ? (is_required ? 1 : 0) : null,
      display_order,
      id
    );
    
    res.json({ success: true });
  } catch (error) {
    console.error("خطأ في تحديث حقل البرماوي:", error);
    res.status(500).json({ error: "خطأ في تحديث حقل البرماوي" });
  }
});

// حذف حقل البرماوي
app.delete("/api/bramawi/fields/:id", (req, res) => {
  try {
    const id = +req.params.id;
    
    // تحقق من وجود بيانات مرتبطة
    const valuesCount = db.prepare("SELECT COUNT(*) as count FROM bramawi_values WHERE field_id = ?").get(id) as any;
    if (valuesCount.count > 0) {
      return res.status(400).json({ error: `لا يمكن حذف الحقل لوجود ${valuesCount.count} قيمة مرتبطة به` });
    }
    
    const result = db.prepare("DELETE FROM bramawi_fields WHERE id = ?").run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "الحقل غير موجود" });
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error("خطأ في حذف حقل البرماوي:", error);
    res.status(500).json({ error: "خطأ في حذف حقل البرماوي" });
  }
});

// جلب سجلات البرماوي
app.get("/api/bramawi/records", (req, res) => {
  try {
    const { status, from, to, limit = 100 } = req.query;
    
    const where: string[] = [];
    const params: any[] = [];
    
    if (status) {
      where.push("payment_status = ?");
      params.push(status);
    }
    if (from) {
      where.push("created_at >= ?");
      params.push(+from);
    }
    if (to) {
      where.push("created_at <= ?");
      params.push(+to);
    }
    
    const sql = `
      SELECT * FROM bramawi_records
      ${where.length ? "WHERE " + where.join(" AND ") : ""}
      ORDER BY created_at DESC
      LIMIT ?
    `;
    
    const records = db.prepare(sql).all(...params, +limit);
    
    // جلب القيم المرتبطة
    if (records.length > 0) {
      const recordIds = records.map((r: any) => r.id);
      const values = db.prepare(`
        SELECT bv.*, bf.name as field_name, bf.type, bf.label
        FROM bramawi_values bv
        JOIN bramawi_fields bf ON bf.id = bv.field_id
        WHERE bv.record_id IN (${recordIds.map(() => '?').join(',')})
      `).all(...recordIds);
      
      // ربط القيم بالسجلات
      const valuesByRecord: any = {};
      values.forEach((v: any) => {
        if (!valuesByRecord[v.record_id]) {
          valuesByRecord[v.record_id] = {};
        }
        valuesByRecord[v.record_id][v.field_name] = {
          value: v.value,
          type: v.type,
          label: v.label
        };
      });
      
      records.forEach((record: any) => {
        record.values = valuesByRecord[record.id] || {};
      });
    }
    
    res.json(records);
  } catch (error) {
    console.error("خطأ في جلب سجلات البرماوي:", error);
    res.status(500).json({ error: "خطأ في جلب سجلات البرماوي" });
  }
});

// إضافة سجل برماوي جديد
app.post("/api/bramawi/records", (req, res) => {
  try {
    const { values, notes } = req.body;
    
    if (!values || typeof values !== 'object') {
      return res.status(400).json({ error: "قيم الحقول مطلوبة" });
    }
    
    // إضافة السجل الأساسي
    const recordStmt = db.prepare(`
      INSERT INTO bramawi_records (notes) VALUES (?)
    `);
    
    const recordInfo = recordStmt.run(notes || null);
    const recordId = recordInfo.lastInsertRowid;
    console.log(`Created record with ID: ${recordId}`);
    
    // إضافة القيم
    const valueStmt = db.prepare(`
      INSERT INTO bramawi_values (record_id, field_id, value)
      VALUES (?, ?, ?)
    `);
    
    // جلب الحقول للتحقق من الـ IDs
    const fields = db.prepare("SELECT id, name FROM bramawi_fields").all() as any[];
    const fieldMap = new Map(fields.map(f => [f.name, f.id]));
    console.log(`Available fields:`, fields);
    console.log(`Received values:`, values);
    
    for (const [fieldName, value] of Object.entries(values)) {
      const fieldId = fieldMap.get(fieldName);
      if (fieldId && value !== null && value !== undefined && value !== '') {
        console.log(`Inserting: recordId=${recordId}, fieldId=${fieldId}, fieldName=${fieldName}, value=${value}`);
        valueStmt.run(recordId, fieldId, String(value));
      }
    }


    
    res.json({ id: recordId, success: true });
  } catch (error) {
    console.error("خطأ في إضافة سجل البرماوي:", error);
    res.status(500).json({ error: "خطأ في إضافة سجل البرماوي" });
  }
});

// تحديث حالة الدفع للسجلات المحددة
app.patch("/api/bramawi/records/payment-status", (req, res) => {
  try {
    const { recordIds, status, paymentDate } = req.body;
    
    if (!recordIds || !Array.isArray(recordIds) || !status) {
      return res.status(400).json({ error: "معرفات السجلات وحالة الدفع مطلوبة" });
    }
    
    const stmt = db.prepare(`
      UPDATE bramawi_records SET
        payment_status = ?,
        payment_date = ?,
        updated_at = strftime('%s','now')
      WHERE id = ?
    `);
    
    recordIds.forEach((id: number) => {
      stmt.run(status, paymentDate || null, id);
    });
    
    res.json({ success: true, updated: recordIds.length });
  } catch (error) {
    console.error("خطأ في تحديث حالة الدفع:", error);
    res.status(500).json({ error: "خطأ في تحديث حالة الدفع" });
  }
});

// تحديث سجل البرماوي
app.patch("/api/bramawi/records/:id", (req, res) => {
  try {
    const id = +req.params.id;
    const { values, notes } = req.body;
    
    // التحقق من وجود السجل
    const existing = db.prepare("SELECT * FROM bramawi_records WHERE id = ?").get(id);
    if (!existing) {
      return res.status(404).json({ error: "السجل غير موجود" });
    }
    
    // تحديث الملاحظات
    if (notes !== undefined) {
      const recordStmt = db.prepare(`
        UPDATE bramawi_records SET
          notes = ?,
          updated_at = strftime('%s','now')
        WHERE id = ?
      `);
      recordStmt.run(notes || null, id);
    }
    
    // تحديث القيم إذا تم تمريرها
    if (values && typeof values === 'object') {
      // حذف القيم القديمة
      db.prepare("DELETE FROM bramawi_values WHERE record_id = ?").run(id);
      
      // إضافة القيم الجديدة
      const valueStmt = db.prepare(`
        INSERT INTO bramawi_values (record_id, field_id, value)
        VALUES (?, ?, ?)
      `);
      
      // جلب الحقول للتحقق من الـ IDs
      const fields = db.prepare("SELECT id, name FROM bramawi_fields").all() as any[];
      const fieldMap = new Map(fields.map(f => [f.name, f.id]));
      
      for (const [fieldName, value] of Object.entries(values)) {
        const fieldId = fieldMap.get(fieldName);
        if (fieldId && value !== null && value !== undefined && value !== '') {
          valueStmt.run(id, fieldId, String(value));
        }
      }
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error("خطأ في تحديث سجل البرماوي:", error);
    res.status(500).json({ error: "خطأ في تحديث سجل البرماوي" });
  }
});

// حذف سجل البرماوي
app.delete("/api/bramawi/records/:id", (req, res) => {
  try {
    const id = +req.params.id;
    
    // حذف القيم المرتبطة أولاً (CASCADE)
    db.prepare("DELETE FROM bramawi_values WHERE record_id = ?").run(id);
    
    // حذف السجل
    const result = db.prepare("DELETE FROM bramawi_records WHERE id = ?").run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "السجل غير موجود" });
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error("خطأ في حذف سجل البرماوي:", error);
    res.status(500).json({ error: "خطأ في حذف سجل البرماوي" });
  }
});

// ================================
// مسارات الحقول الديناميكية (Dynamic Fields)
// ================================

// جلب جميع الحقول الديناميكية لصفحة معينة
app.get("/dynamic-fields/:pageType", (req, res) => {
  try {
    const { pageType } = req.params;
    
    const fields = db.prepare(`
      SELECT id, name, label, type, page_type, options, calculation_formula, 
             is_required, display_order, default_value, created_at
      FROM dynamic_fields 
      WHERE page_type = ?
      ORDER BY display_order, name
    `).all(pageType);
    
    // تحويل options من JSON
    const processedFields = fields.map((field: any) => ({
      ...field,
      options: field.options ? JSON.parse(field.options) : null,
      is_required: Boolean(field.is_required)
    }));
    
    res.json(processedFields);
  } catch (error) {
    console.error("خطأ في جلب الحقول الديناميكية:", error);
    res.status(500).json({ error: "خطأ في جلب الحقول الديناميكية" });
  }
});

// إضافة حقل ديناميكي جديد
app.post("/dynamic-fields", (req, res) => {
  try {
    const { 
      name, label, type, page_type, options, calculation_formula,
      is_required, display_order, default_value 
    } = req.body;
    
    // التحقق من صحة البيانات
    if (!name || !label || !type || !page_type) {
      return res.status(400).json({ 
        error: "اسم الحقل، العنوان، النوع، ونوع الصفحة مطلوبة" 
      });
    }
    
    // التحقق من عدم وجود حقل بنفس الاسم لنفس الصفحة
    const existing = db.prepare(`
      SELECT id FROM dynamic_fields 
      WHERE name = ? AND page_type = ?
    `).get(name, page_type);
    
    if (existing) {
      return res.status(400).json({ 
        error: "يوجد حقل بنفس الاسم في هذه الصفحة مسبقاً" 
      });
    }
    
    const stmt = db.prepare(`
      INSERT INTO dynamic_fields (
        name, label, type, page_type, options, calculation_formula,
        is_required, display_order, default_value
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    const result = stmt.run(
      name, label, type, page_type,
      options ? JSON.stringify(options) : null,
      calculation_formula || null,
      is_required ? 1 : 0,
      display_order || 0,
      default_value || null
    );
    
    res.json({ 
      success: true, 
      id: result.lastInsertRowid,
      message: "تم إنشاء الحقل بنجاح"
    });
  } catch (error) {
    console.error("خطأ في إنشاء الحقل الديناميكي:", error);
    res.status(500).json({ error: "خطأ في إنشاء الحقل الديناميكي" });
  }
});

// تحديث حقل ديناميكي
app.patch("/dynamic-fields/:id", (req, res) => {
  try {
    const id = +req.params.id;
    const { 
      name, label, type, options, calculation_formula,
      is_required, display_order, default_value 
    } = req.body;
    
    const existing = db.prepare("SELECT * FROM dynamic_fields WHERE id = ?").get(id);
    if (!existing) {
      return res.status(404).json({ error: "الحقل غير موجود" });
    }
    
    const stmt = db.prepare(`
      UPDATE dynamic_fields SET 
        name = COALESCE(?, name),
        label = COALESCE(?, label),
        type = COALESCE(?, type),
        options = COALESCE(?, options),
        calculation_formula = COALESCE(?, calculation_formula),
        is_required = COALESCE(?, is_required),
        display_order = COALESCE(?, display_order),
        default_value = COALESCE(?, default_value)
      WHERE id = ?
    `);
    
    stmt.run(
      name, label, type,
      options ? JSON.stringify(options) : null,
      calculation_formula,
      is_required !== undefined ? (is_required ? 1 : 0) : null,
      display_order,
      default_value,
      id
    );
    
    res.json({ success: true, message: "تم تحديث الحقل بنجاح" });
  } catch (error) {
    console.error("خطأ في تحديث الحقل الديناميكي:", error);
    res.status(500).json({ error: "خطأ في تحديث الحقل الديناميكي" });
  }
});

// حذف حقل ديناميكي
app.delete("/dynamic-fields/:id", (req, res) => {
  try {
    const id = +req.params.id;
    
    // تحقق من وجود سجلات مرتبطة
    const recordsCount = db.prepare(`
      SELECT COUNT(*) as count 
      FROM dynamic_records dr, dynamic_fields df
      WHERE df.id = ? AND df.page_type = dr.page_type
      AND json_extract(dr.record_data, '$.' || df.name) IS NOT NULL
    `).get(id) as { count: number };
    
    if (recordsCount.count > 0) {
      return res.status(400).json({ 
        error: `لا يمكن حذف الحقل لوجود ${recordsCount.count} سجل مرتبط به` 
      });
    }
    
    const result = db.prepare("DELETE FROM dynamic_fields WHERE id = ?").run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "الحقل غير موجود" });
    }
    
    res.json({ success: true, message: "تم حذف الحقل بنجاح" });
  } catch (error) {
    console.error("خطأ في حذف الحقل الديناميكي:", error);
    res.status(500).json({ error: "خطأ في حذف الحقل الديناميكي" });
  }
});

// ================================
// مسارات السجلات الديناميكية (Dynamic Records)
// ================================

// جلب جميع السجلات الديناميكية لصفحة معينة
app.get("/dynamic-records/:pageType", (req, res) => {
  try {
    const { pageType } = req.params;
    
    const records = db.prepare(`
      SELECT id, page_type, record_data, created_at, updated_at
      FROM dynamic_records 
      WHERE page_type = ?
      ORDER BY created_at DESC
    `).all(pageType);
    
    // تحويل record_data من JSON
    const processedRecords = records.map((record: any) => ({
      ...record,
      record_data: record.record_data ? JSON.parse(record.record_data) : {}
    }));
    
    res.json(processedRecords);
  } catch (error) {
    console.error("خطأ في جلب السجلات الديناميكية:", error);
    res.status(500).json({ error: "خطأ في جلب السجلات الديناميكية" });
  }
});

// جلب البيانات الديناميكية لسجل محدد
app.get("/dynamic-records/:pageType/:recordId", (req, res) => {
  try {
    const { pageType, recordId } = req.params;
    
    const record = db.prepare(`
      SELECT record_data
      FROM dynamic_records 
      WHERE page_type = ? AND record_id = ?
    `).get(pageType, recordId) as { record_data: string } | undefined;
    
    if (!record) {
      return res.json({});
    }
    
    const data = record.record_data ? JSON.parse(record.record_data) : {};
    res.json(data);
  } catch (error) {
    console.error("خطأ في جلب البيانات الديناميكية:", error);
    res.status(500).json({ error: "خطأ في جلب البيانات الديناميكية" });
  }
});

// إضافة سجل ديناميكي جديد
app.post("/dynamic-records", (req, res) => {
  try {
    const { page_type, record_data } = req.body;
    
    if (!page_type || !record_data) {
      return res.status(400).json({ 
        error: "نوع الصفحة وبيانات السجل مطلوبة" 
      });
    }
    
    const stmt = db.prepare(`
      INSERT INTO dynamic_records (page_type, record_data)
      VALUES (?, ?)
    `);
    
    const result = stmt.run(page_type, JSON.stringify(record_data));
    
    res.json({ 
      success: true, 
      id: result.lastInsertRowid,
      message: "تم إنشاء السجل بنجاح"
    });
  } catch (error) {
    console.error("خطأ في إنشاء السجل الديناميكي:", error);
    res.status(500).json({ error: "خطأ في إنشاء السجل الديناميكي" });
  }
});

// تحديث سجل ديناميكي
app.patch("/dynamic-records/:id", (req, res) => {
  try {
    const id = +req.params.id;
    const { record_data } = req.body;
    
    const existing = db.prepare("SELECT * FROM dynamic_records WHERE id = ?").get(id);
    if (!existing) {
      return res.status(404).json({ error: "السجل غير موجود" });
    }
    
    const stmt = db.prepare(`
      UPDATE dynamic_records SET 
        record_data = ?,
        updated_at = strftime('%s','now')
      WHERE id = ?
    `);
    
    stmt.run(JSON.stringify(record_data), id);
    
    res.json({ success: true, message: "تم تحديث السجل بنجاح" });
  } catch (error) {
    console.error("خطأ في تحديث السجل الديناميكي:", error);
    res.status(500).json({ error: "خطأ في تحديث السجل الديناميكي" });
  }
});

// حذف سجل ديناميكي
app.delete("/dynamic-records/:id", (req, res) => {
  try {
    const id = +req.params.id;
    
    const result = db.prepare("DELETE FROM dynamic_records WHERE id = ?").run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "السجل غير موجود" });
    }
    
    res.json({ success: true, message: "تم حذف السجل بنجاح" });
  } catch (error) {
    console.error("خطأ في حذف السجل الديناميكي:", error);
    res.status(500).json({ error: "خطأ في حذف السجل الديناميكي" });
  }
});

// ================================
// مسارات المساجد (Mosques)
// ================================

// جلب جميع المساجد
app.get("/mosques", (req, res) => {
  try {
    const rows = db.prepare(`
      SELECT id, name, location, imam_phone, guard_phone, created_at, updated_at
      FROM mosques 
      ORDER BY name
    `).all();
    res.json(rows);
  } catch (error) {
    console.error("خطأ في جلب المساجد:", error);
    res.status(500).json({ error: "خطأ في جلب المساجد" });
  }
});

// إضافة مسجد جديد
app.post("/mosques", (req, res) => {
  try {
    const { name, location, imam_phone, guard_phone, dynamic_fields } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: "اسم المسجد مطلوب" });
    }
    
    const stmt = db.prepare(`
      INSERT INTO mosques (name, location, imam_phone, guard_phone)
      VALUES (?, ?, ?, ?)
    `);
    
    const result = stmt.run(name, location || null, imam_phone || null, guard_phone || null);
    const mosqueId = result.lastInsertRowid;
    
    // حفظ الحقول الديناميكية إذا كانت موجودة
    if (dynamic_fields && Object.keys(dynamic_fields).length > 0) {
      try {
        const insertDynamicStmt = db.prepare(`
          INSERT OR REPLACE INTO dynamic_records (page_type, record_id, record_data)
          VALUES (?, ?, ?)
        `);
        
        insertDynamicStmt.run('mosques', mosqueId, JSON.stringify(dynamic_fields));
      } catch (dynamicError) {
        console.error("خطأ في حفظ الحقول الديناميكية:", dynamicError);
        // لا نفشل العملية بسبب خطأ في الحقول الديناميكية
      }
    }
    
    res.json({ 
      success: true, 
      id: mosqueId,
      message: "تم إضافة المسجد بنجاح"
    });
  } catch (error: any) {
    console.error("خطأ في إضافة المسجد:", error);
    if (error.code === "SQLITE_CONSTRAINT_UNIQUE") {
      res.status(400).json({ error: "اسم المسجد مستخدم مسبقاً" });
    } else {
      res.status(500).json({ error: "خطأ في إضافة المسجد" });
    }
  }
});

// تحديث مسجد
app.patch("/mosques/:id", (req, res) => {
  try {
    const id = +req.params.id;
    const { name, location, imam_phone, guard_phone, dynamic_fields } = req.body;
    
    const existing = db.prepare("SELECT * FROM mosques WHERE id = ?").get(id);
    if (!existing) {
      return res.status(404).json({ error: "المسجد غير موجود" });
    }
    
    const stmt = db.prepare(`
      UPDATE mosques SET 
        name = COALESCE(?, name),
        location = COALESCE(?, location),
        imam_phone = COALESCE(?, imam_phone),
        guard_phone = COALESCE(?, guard_phone)
      WHERE id = ?
    `);
    
    stmt.run(name, location, imam_phone, guard_phone, id);
    
    // تحديث الحقول الديناميكية
    if (dynamic_fields !== undefined) {
      try {
        if (Object.keys(dynamic_fields).length > 0) {
          // إضافة أو تحديث الحقول الديناميكية
          const insertDynamicStmt = db.prepare(`
            INSERT OR REPLACE INTO dynamic_records (page_type, record_id, record_data)
            VALUES (?, ?, ?)
          `);
          
          insertDynamicStmt.run('mosques', id, JSON.stringify(dynamic_fields));
        } else {
          // حذف الحقول الديناميكية إذا كانت فارغة
          const deleteDynamicStmt = db.prepare(`
            DELETE FROM dynamic_records 
            WHERE page_type = ? AND record_id = ?
          `);
          
          deleteDynamicStmt.run('mosques', id);
        }
      } catch (dynamicError) {
        console.error("خطأ في تحديث الحقول الديناميكية:", dynamicError);
        // لا نفشل العملية بسبب خطأ في الحقول الديناميكية
      }
    }
    
    res.json({ success: true, message: "تم تحديث المسجد بنجاح" });
  } catch (error: any) {
    console.error("خطأ في تحديث المسجد:", error);
    if (error.code === "SQLITE_CONSTRAINT_UNIQUE") {
      res.status(400).json({ error: "اسم المسجد مستخدم مسبقاً" });
    } else {
      res.status(500).json({ error: "خطأ في تحديث المسجد" });
    }
  }
});

// حذف مسجد
app.delete("/mosques/:id", (req, res) => {
  try {
    const id = +req.params.id;
    
    // تحقق من وجود توزيعات مرتبطة
    const distributionsCount = db.prepare("SELECT COUNT(*) as count FROM distributions WHERE mosque_id = ?").get(id) as { count: number };
    if (distributionsCount.count > 0) {
      return res.status(400).json({ 
        error: `لا يمكن حذف المسجد لوجود ${distributionsCount.count} عملية توزيع مرتبطة به` 
      });
    }
    
    const result = db.prepare("DELETE FROM mosques WHERE id = ?").run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "المسجد غير موجود" });
    }
    
    res.json({ success: true, message: "تم حذف المسجد بنجاح" });
  } catch (error) {
    console.error("خطأ في حذف المسجد:", error);
    res.status(500).json({ error: "خطأ في حذف المسجد" });
  }
});

// جلب إحصائيات مسجد معين
app.get("/mosques/:id/stats", (req, res) => {
  try {
    const id = +req.params.id;
    
    // التحقق من وجود المسجد
    const mosque = db.prepare("SELECT * FROM mosques WHERE id = ?").get(id);
    if (!mosque) {
      return res.status(404).json({ error: "المسجد غير موجود" });
    }
    
    // إحصائيات التوزيع
    const totalDistributions = db.prepare(`
      SELECT COUNT(*) as count 
      FROM distributions 
      WHERE mosque_id = ?
    `).get(id) as { count: number };
    
    const totalBundles = db.prepare(`
      SELECT COALESCE(SUM(bundles_count), 0) as total 
      FROM distributions 
      WHERE mosque_id = ?
    `).get(id) as { total: number };
    
    const typeStats = db.prepare(`
      SELECT 
        type,
        COUNT(*) as operations_count,
        COALESCE(SUM(bundles_count), 0) as bundles_count
      FROM distributions 
      WHERE mosque_id = ?
      GROUP BY type
    `).all(id);
    
    // آخر العمليات
    const recentDistributions = db.prepare(`
      SELECT id, type, bundles_count, notes, created_at
      FROM distributions 
      WHERE mosque_id = ?
      ORDER BY created_at DESC
      LIMIT 10
    `).all(id);
    
    res.json({
      mosque,
      stats: {
        total_distributions: totalDistributions.count,
        total_bundles: totalBundles.total,
        by_type: typeStats,
        recent_distributions: recentDistributions
      }
    });
  } catch (error) {
    console.error("خطأ في جلب إحصائيات المسجد:", error);
    res.status(500).json({ error: "خطأ في جلب إحصائيات المسجد" });
  }
});

// ================================
// مسارات التوزيع (Distributions)
// ================================

// جلب جميع عمليات التوزيع
app.get("/distributions", (req, res) => {
  try {
    const { mosque_id, type } = req.query;
    
    let query = `
      SELECT 
        d.id, d.mosque_id, d.type, d.bundles_count, d.notes, d.created_at, d.updated_at,
        m.name as mosque_name, m.location as mosque_location
      FROM distributions d
      LEFT JOIN mosques m ON d.mosque_id = m.id
    `;
    
    const params: any[] = [];
    const conditions: string[] = [];
    
    if (mosque_id) {
      conditions.push("d.mosque_id = ?");
      params.push(+mosque_id);
    }
    
    if (type && (type === 'تصوير' || type === 'تصريف')) {
      conditions.push("d.type = ?");
      params.push(type);
    }
    
    if (conditions.length > 0) {
      query += " WHERE " + conditions.join(" AND ");
    }
    
    query += " ORDER BY d.created_at DESC";
    
    const rows = db.prepare(query).all(...params);
    res.json(rows);
  } catch (error) {
    console.error("خطأ في جلب عمليات التوزيع:", error);
    res.status(500).json({ error: "خطأ في جلب عمليات التوزيع" });
  }
});

// إضافة عملية توزيع جديدة
app.post("/distributions", (req, res) => {
  try {
    const { mosque_id, type, bundles_count, notes } = req.body;
    
    if (!mosque_id || !type || !bundles_count) {
      return res.status(400).json({ 
        error: "المسجد، نوع التوزيع، وعدد الربطات مطلوبة" 
      });
    }
    
    if (!['تصوير', 'تصريف'].includes(type)) {
      return res.status(400).json({ error: "نوع التوزيع يجب أن يكون تصوير أو تصريف" });
    }
    
    // التحقق من وجود المسجد
    const mosque = db.prepare("SELECT * FROM mosques WHERE id = ?").get(mosque_id);
    if (!mosque) {
      return res.status(404).json({ error: "المسجد المحدد غير موجود" });
    }
    
    const stmt = db.prepare(`
      INSERT INTO distributions (mosque_id, type, bundles_count, notes)
      VALUES (?, ?, ?, ?)
    `);
    
    const result = stmt.run(mosque_id, type, +bundles_count, notes || null);
    
    res.json({ 
      success: true, 
      id: result.lastInsertRowid,
      message: "تم إضافة عملية التوزيع بنجاح"
    });
  } catch (error) {
    console.error("خطأ في إضافة عملية التوزيع:", error);
    res.status(500).json({ error: "خطأ في إضافة عملية التوزيع" });
  }
});

// تحديث عملية توزيع
app.patch("/distributions/:id", (req, res) => {
  try {
    const id = +req.params.id;
    const { mosque_id, type, bundles_count, notes } = req.body;
    
    const existing = db.prepare("SELECT * FROM distributions WHERE id = ?").get(id);
    if (!existing) {
      return res.status(404).json({ error: "عملية التوزيع غير موجودة" });
    }
    
    // التحقق من المسجد إذا تم تمريره
    if (mosque_id) {
      const mosque = db.prepare("SELECT * FROM mosques WHERE id = ?").get(mosque_id);
      if (!mosque) {
        return res.status(404).json({ error: "المسجد المحدد غير موجود" });
      }
    }
    
    // التحقق من نوع التوزيع إذا تم تمريره
    if (type && !['تصوير', 'تصريف'].includes(type)) {
      return res.status(400).json({ error: "نوع التوزيع يجب أن يكون تصوير أو تصريف" });
    }
    
    const stmt = db.prepare(`
      UPDATE distributions SET 
        mosque_id = COALESCE(?, mosque_id),
        type = COALESCE(?, type),
        bundles_count = COALESCE(?, bundles_count),
        notes = COALESCE(?, notes),
        updated_at = strftime('%s','now')
      WHERE id = ?
    `);
    
    stmt.run(
      mosque_id, 
      type, 
      bundles_count ? +bundles_count : null, 
      notes, 
      id
    );
    
    res.json({ success: true, message: "تم تحديث عملية التوزيع بنجاح" });
  } catch (error) {
    console.error("خطأ في تحديث عملية التوزيع:", error);
    res.status(500).json({ error: "خطأ في تحديث عملية التوزيع" });
  }
});

// حذف عملية توزيع
app.delete("/distributions/:id", (req, res) => {
  try {
    const id = +req.params.id;
    
    const result = db.prepare("DELETE FROM distributions WHERE id = ?").run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "عملية التوزيع غير موجودة" });
    }
    
    res.json({ success: true, message: "تم حذف عملية التوزيع بنجاح" });
  } catch (error) {
    console.error("خطأ في حذف عملية التوزيع:", error);
    res.status(500).json({ error: "خطأ في حذف عملية التوزيع" });
  }
});

// ================================
// الإحصائيات العامة (General Stats)
// ================================

// إحصائيات عامة للمساجد والتوزيع
app.get("/mosques-stats", (req, res) => {
  try {
    // إحصائيات المساجد
    const totalMosques = db.prepare("SELECT COUNT(*) as count FROM mosques").get() as { count: number };
    
    // إحصائيات التوزيع العامة
    const totalDistributions = db.prepare("SELECT COUNT(*) as count FROM distributions").get() as { count: number };
    const totalBundles = db.prepare("SELECT COALESCE(SUM(bundles_count), 0) as total FROM distributions").get() as { total: number };
    
    // إحصائيات حسب النوع
    const typeStats = db.prepare(`
      SELECT 
        type,
        COUNT(*) as operations_count,
        COALESCE(SUM(bundles_count), 0) as bundles_count
      FROM distributions 
      GROUP BY type
    `).all();
    
    // أكثر المساجد نشاطاً
    const topMosques = db.prepare(`
      SELECT 
        m.id, m.name, m.location,
        COUNT(d.id) as operations_count,
        COALESCE(SUM(d.bundles_count), 0) as total_bundles
      FROM mosques m
      LEFT JOIN distributions d ON m.id = d.mosque_id
      GROUP BY m.id, m.name, m.location
      ORDER BY total_bundles DESC, operations_count DESC
      LIMIT 10
    `).all();
    
    // التوزيع الشهري
    const monthlyStats = db.prepare(`
      SELECT 
        strftime('%Y-%m', datetime(created_at, 'unixepoch')) as month,
        type,
        COUNT(*) as operations_count,
        COALESCE(SUM(bundles_count), 0) as bundles_count
      FROM distributions
      WHERE created_at >= strftime('%s', 'now', '-12 months')
      GROUP BY month, type
      ORDER BY month DESC
    `).all();
    
    res.json({
      totals: {
        mosques: totalMosques.count,
        distributions: totalDistributions.count,
        bundles: totalBundles.total
      },
      by_type: typeStats,
      top_mosques: topMosques,
      monthly_trends: monthlyStats
    });
  } catch (error) {
    console.error("خطأ في جلب الإحصائيات العامة:", error);
    res.status(500).json({ error: "خطأ في جلب الإحصائيات العامة" });
  }
});

// =========================
// مسارات الموظفين (Employees)
// =========================

app.get("/employees", (req, res) => {
  try {
    const { active = "true" } = req.query;
    const rows = db.prepare(`
      SELECT * FROM employees 
      WHERE is_active = ?
      ORDER BY name
    `).all(active === "true" ? 1 : 0);
    res.json(rows);
  } catch (error) {
    console.error("خطأ في جلب الموظفين:", error);
    res.status(500).json({ error: "خطأ في جلب الموظفين" });
  }
});

app.post("/employees", (req, res) => {
  try {
    const { 
      name, position, phone, email, national_id, hire_date, 
      department, base_salary, salary_type, notes 
    } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: "اسم الموظف مطلوب" });
    }

    const stmt = db.prepare(`
      INSERT INTO employees 
      (name, position, phone, email, national_id, hire_date, department, base_salary, salary_type, notes) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    const info = stmt.run(
      name, position || null, phone || null, email || null,
      national_id || null, hire_date || null, department || null,
      base_salary || 0, salary_type || 'fixed', notes || null
    );
    
    res.json({ id: info.lastInsertRowid, success: true });
  } catch (error: any) {
    console.error("خطأ في إضافة الموظف:", error);
    if (error.code === "SQLITE_CONSTRAINT_UNIQUE") {
      res.status(400).json({ error: "رقم الهوية مستخدم مسبقاً" });
    } else {
      res.status(500).json({ error: "خطأ في إضافة الموظف" });
    }
  }
});

app.patch("/employees/:id", (req, res) => {
  try {
    const id = +req.params.id;
    const { 
      name, position, phone, email, national_id, hire_date, 
      department, base_salary, salary_type, is_active, notes 
    } = req.body;
    
    const stmt = db.prepare(`
      UPDATE employees SET 
        name = COALESCE(?, name),
        position = COALESCE(?, position),
        phone = COALESCE(?, phone),
        email = COALESCE(?, email),
        national_id = COALESCE(?, national_id),
        hire_date = COALESCE(?, hire_date),
        department = COALESCE(?, department),
        base_salary = COALESCE(?, base_salary),
        salary_type = COALESCE(?, salary_type),
        is_active = COALESCE(?, is_active),
        notes = COALESCE(?, notes),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    
    const result = stmt.run(
      name, position, phone, email, national_id, hire_date,
      department, base_salary, salary_type, is_active, notes, id
    );
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "الموظف غير موجود" });
    }
    
    res.json({ success: true });
  } catch (error: any) {
    console.error("خطأ في تحديث الموظف:", error);
    if (error.code === "SQLITE_CONSTRAINT_UNIQUE") {
      res.status(400).json({ error: "رقم الهوية مستخدم مسبقاً" });
    } else {
      res.status(500).json({ error: "خطأ في تحديث الموظف" });
    }
  }
});

// =========================
// مسارات كشوفات الرواتب (Salary Records)
// =========================

app.get("/salary-records", (req, res) => {
  try {
    const { month, year, employee_id, status } = req.query;
    
    let sql = `
      SELECT sr.*, e.name as employee_name, e.position, e.position as department
      FROM monthly_salaries sr
      JOIN employees e ON sr.employee_id = e.id
    `;
    
    const where: string[] = [];
    const params: any[] = [];
    
    if (month) { where.push("sr.month = ?"); params.push(+month); }
    if (year) { where.push("sr.year = ?"); params.push(+year); }
    if (employee_id) { where.push("sr.employee_id = ?"); params.push(+employee_id); }
    if (status) { where.push("sr.status = ?"); params.push(status); }
    
    if (where.length > 0) {
      sql += " WHERE " + where.join(" AND ");
    }
    
    sql += " ORDER BY sr.year DESC, sr.month DESC, e.name";
    
    const rows = db.prepare(sql).all(...params);
    res.json(rows);
  } catch (error) {
    console.error("خطأ في جلب كشوفات الرواتب:", error);
    res.status(500).json({ error: "خطأ في جلب كشوفات الرواتب" });
  }
});

app.post("/salary-records", (req, res) => {
  try {
    const { 
      employee_id, month, year, base_amount, allowances, 
      deductions, overtime_amount, bonus, notes 
    } = req.body;
    
    if (!employee_id || !month || !year) {
      return res.status(400).json({ error: "معرف الموظف والشهر والسنة مطلوبة" });
    }

    const stmt = db.prepare(`
      INSERT INTO monthly_salaries 
      (employee_id, month, year, base_amount, allowances, deductions, overtime_amount, bonus, notes) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    const info = stmt.run(
      employee_id, month, year, base_amount || 0, allowances || 0,
      deductions || 0, overtime_amount || 0, bonus || 0, notes || null
    );
    
    res.json({ id: info.lastInsertRowid, success: true });
  } catch (error: any) {
    console.error("خطأ في إضافة كشف الراتب:", error);
    if (error.code === "SQLITE_CONSTRAINT_UNIQUE") {
      res.status(400).json({ error: "كشف الراتب لهذا الموظف في هذا الشهر موجود مسبقاً" });
    } else {
      res.status(500).json({ error: "خطأ في إضافة كشف الراتب" });
    }
  }
});

app.patch("/salary-records/:id", (req, res) => {
  try {
    const id = +req.params.id;
    const { 
      base_amount, allowances, deductions, overtime_amount, 
      bonus, status, payment_date, payment_method, notes 
    } = req.body;
    
    const stmt = db.prepare(`
      UPDATE monthly_salaries SET 
        base_amount = COALESCE(?, base_amount),
        allowances = COALESCE(?, allowances),
        deductions = COALESCE(?, deductions),
        overtime_amount = COALESCE(?, overtime_amount),
        bonus = COALESCE(?, bonus),
        status = COALESCE(?, status),
        payment_date = COALESCE(?, payment_date),
        payment_method = COALESCE(?, payment_method),
        notes = COALESCE(?, notes),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    
    const result = stmt.run(
      base_amount, allowances, deductions, overtime_amount,
      bonus, status, payment_date, payment_method, notes, id
    );
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "كشف الراتب غير موجود" });
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error("خطأ في تحديث كشف الراتب:", error);
    res.status(500).json({ error: "خطأ في تحديث كشف الراتب" });
  }
});

app.delete("/salary-records/:id", (req, res) => {
  try {
    const id = +req.params.id;
    
    const result = db.prepare("DELETE FROM monthly_salaries WHERE id = ?").run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "كشف الراتب غير موجود" });
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error("خطأ في حذف كشف الراتب:", error);
    res.status(500).json({ error: "خطأ في حذف كشف الراتب" });
  }
});

// إحصائيات الرواتب
app.get("/salary-stats", (req, res) => {
  try {
    const { year = new Date().getFullYear() } = req.query;
    
    // إجمالي الرواتب لكل شهر
    const monthlyTotals = db.prepare(`
      SELECT 
        month,
        COUNT(*) as records_count,
        SUM(salary_amount) as salary_amount,
        COUNT(CASE WHEN status = 'paid' THEN 1 END) as paid_count,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count
      FROM monthly_salaries 
      WHERE year = ? 
      GROUP BY month 
      ORDER BY month
    `).all(+year);
    
    // أعلى الرواتب
    const topSalaries = db.prepare(`
      SELECT sr.salary_amount, e.name, sr.month, sr.year
      FROM monthly_salaries sr
      JOIN employees e ON sr.employee_id = e.id
      WHERE sr.year = ?
      ORDER BY sr.salary_amount DESC
      LIMIT 10
    `).all(+year);
    
    // إحصائيات حسب الحالة
    const statusStats = db.prepare(`
      SELECT 
        status,
        COUNT(*) as count,
        SUM(salary_amount) as salary_amount
      FROM monthly_salaries 
      WHERE year = ?
      GROUP BY status
    `).all(+year);
    
    res.json({
      monthly_totals: monthlyTotals,
      top_salaries: topSalaries,
      status_stats: statusStats
    });
  } catch (error) {
    console.error("خطأ في جلب إحصائيات الرواتب:", error);
    res.status(500).json({ error: "خطأ في جلب إحصائيات الرواتب" });
  }
});

// =========================
// مسارات السُلف والمديونيات (Employee Advances)
// =========================

app.get("/employee-advances", (req, res) => {
  try {
    const { employee_id, type, status } = req.query;
    
    let sql = `
      SELECT ea.*, e.name as employee_name, e.position, e.position as department
      FROM employee_advances ea
      JOIN employees e ON ea.employee_id = e.id
    `;
    
    const where: string[] = [];
    const params: any[] = [];
    
    if (employee_id) { where.push("ea.employee_id = ?"); params.push(+employee_id); }
    if (type) { where.push("ea.type = ?"); params.push(type); }
    if (status) { where.push("ea.status = ?"); params.push(status); }
    
    if (where.length > 0) {
      sql += " WHERE " + where.join(" AND ");
    }
    
    sql += " ORDER BY ea.created_at DESC";
    
    const rows = db.prepare(sql).all(...params);
    res.json(rows);
  } catch (error) {
    console.error("خطأ في جلب السُلف:", error);
    res.status(500).json({ error: "خطأ في جلب السُلف" });
  }
});

app.post("/employee-advances", (req, res) => {
  try {
    const { 
      employee_id, type, amount, reason, due_date, priority, notes 
    } = req.body;
    
    if (!employee_id || !amount || !type) {
      return res.status(400).json({ error: "معرف الموظف والمبلغ والنوع مطلوبة" });
    }

    const stmt = db.prepare(`
      INSERT INTO employee_advances 
      (employee_id, type, amount, reason, due_date, priority, notes) 
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    
    const info = stmt.run(
      employee_id, type, amount, reason || null, due_date || null,
      priority || 'normal', notes || null
    );
    
    res.json({ id: info.lastInsertRowid, success: true });
  } catch (error) {
    console.error("خطأ في إضافة السلفة:", error);
    res.status(500).json({ error: "خطأ في إضافة السلفة" });
  }
});

app.patch("/employee-advances/:id", (req, res) => {
  try {
    const id = +req.params.id;
    const { 
      amount, reason, due_date, priority, status, approval_date, 
      approved_by, completion_date, notes 
    } = req.body;
    
    const stmt = db.prepare(`
      UPDATE employee_advances SET 
        amount = COALESCE(?, amount),
        reason = COALESCE(?, reason),
        due_date = COALESCE(?, due_date),
        priority = COALESCE(?, priority),
        status = COALESCE(?, status),
        approval_date = COALESCE(?, approval_date),
        approved_by = COALESCE(?, approved_by),
        completion_date = COALESCE(?, completion_date),
        notes = COALESCE(?, notes),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    
    const result = stmt.run(
      amount, reason, due_date, priority, status, 
      approval_date, approved_by, completion_date, notes, id
    );
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "السلفة غير موجودة" });
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error("خطأ في تحديث السلفة:", error);
    res.status(500).json({ error: "خطأ في تحديث السلفة" });
  }
});

app.delete("/employee-advances/:id", (req, res) => {
  try {
    const id = +req.params.id;
    
    const result = db.prepare("DELETE FROM employee_advances WHERE id = ?").run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: "السلفة غير موجودة" });
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error("خطأ في حذف السلفة:", error);
    res.status(500).json({ error: "خطأ في حذف السلفة" });
  }
});

// =========================
// مسارات مدفوعات السُلف (Advance Payments)
// =========================

app.get("/advance-payments/:advance_id", (req, res) => {
  try {
    const advance_id = +req.params.advance_id;
    
    const payments = db.prepare(`
      SELECT * FROM advance_payments 
      WHERE advance_id = ? 
      ORDER BY payment_date DESC
    `).all(advance_id);
    
    res.json(payments);
  } catch (error) {
    console.error("خطأ في جلب مدفوعات السلفة:", error);
    res.status(500).json({ error: "خطأ في جلب مدفوعات السلفة" });
  }
});

app.post("/advance-payments", (req, res) => {
  try {
    const { 
      advance_id, payment_amount, payment_date, payment_method, notes, recorded_by 
    } = req.body;
    
    if (!advance_id || !payment_amount) {
      return res.status(400).json({ error: "معرف السلفة والمبلغ مطلوبان" });
    }

    // التحقق من وجود السلفة
    const advance = db.prepare("SELECT * FROM employee_advances WHERE id = ?").get(advance_id);
    if (!advance) {
      return res.status(404).json({ error: "السلفة غير موجودة" });
    }

    // إضافة المدفوعة
    const stmt = db.prepare(`
      INSERT INTO advance_payments 
      (advance_id, payment_amount, payment_date, payment_method, notes, recorded_by) 
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    
    const info = stmt.run(
      advance_id, payment_amount, payment_date || null,
      payment_method || 'نقدي', notes || null, recorded_by || null
    );

    // تحديث المبلغ المدفوع
    const updateStmt = db.prepare(`
      UPDATE employee_advances 
      SET paid_amount = (
        SELECT SUM(payment_amount) 
        FROM advance_payments 
        WHERE advance_id = ?
      ),
      status = CASE 
        WHEN (SELECT SUM(payment_amount) FROM advance_payments WHERE advance_id = ?) >= amount 
        THEN 'completed'
        ELSE status
      END,
      completion_date = CASE 
        WHEN (SELECT SUM(payment_amount) FROM advance_payments WHERE advance_id = ?) >= amount 
        THEN CURRENT_DATE
        ELSE completion_date
      END
      WHERE id = ?
    `);
    
    updateStmt.run(advance_id, advance_id, advance_id, advance_id);
    
    res.json({ id: info.lastInsertRowid, success: true });
  } catch (error) {
    console.error("خطأ في إضافة المدفوعة:", error);
    res.status(500).json({ error: "خطأ في إضافة المدفوعة" });
  }
});

// إحصائيات السُلف
app.get("/advances-stats", (req, res) => {
  try {
    // إحصائيات عامة
    const generalStats = db.prepare(`
      SELECT 
        COUNT(*) as total_advances,
        SUM(amount) as salary_amount,
        SUM(paid_amount) as total_paid,
        SUM(remaining_amount) as total_remaining,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
        COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved_count,
        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_count,
        COUNT(CASE WHEN type = 'advance' THEN 1 END) as advances_count,
        COUNT(CASE WHEN type = 'loan' THEN 1 END) as loans_count,
        COUNT(CASE WHEN type = 'debt' THEN 1 END) as debts_count
      FROM employee_advances
    `).get();

    // إحصائيات بالموظف
    const byEmployee = db.prepare(`
      SELECT 
        e.name as employee_name,
        COUNT(ea.id) as total_advances,
        SUM(ea.amount) as salary_amount,
        SUM(ea.paid_amount) as total_paid,
        SUM(ea.remaining_amount) as total_remaining
      FROM employee_advances ea
      JOIN employees e ON ea.employee_id = e.id
      GROUP BY e.id, e.name
      ORDER BY total_remaining DESC
    `).all();

    // أحدث المعاملات
    const recentTransactions = db.prepare(`
      SELECT 
        ea.type, ea.amount, ea.status, ea.created_at,
        e.name as employee_name
      FROM employee_advances ea
      JOIN employees e ON ea.employee_id = e.id
      ORDER BY ea.created_at DESC
      LIMIT 10
    `).all();
    
    res.json({
      general: generalStats,
      by_employee: byEmployee,
      recent_transactions: recentTransactions
    });
  } catch (error) {
    console.error("خطأ في جلب إحصائيات السُلف:", error);
    res.status(500).json({ error: "خطأ في جلب إحصائيات السُلف" });
  }
});

// ================================
// نظام الرواتب الجديد - APIs
// ================================

// 📋 إدارة الموظفين الجديد
app.get("/api/employees", authenticateAdmin, (req, res) => {
  try {
    const employees = db.prepare(`
      SELECT * FROM employees 
      WHERE is_active = 1 
      ORDER BY name
    `).all();
    
    res.json(employees);
  } catch (error) {
    console.error("خطأ في جلب الموظفين:", error);
    res.status(500).json({ error: "خطأ في جلب الموظفين" });
  }
});

app.post("/api/employees", authenticateAdmin, (req, res) => {
  try {
    const { name, position, phone, monthly_salary, hire_date } = req.body;
    
    if (!name || !monthly_salary) {
      return res.status(400).json({ error: "الاسم والراتب الشهري مطلوبان" });
    }

    const result = db.prepare(`
      INSERT INTO employees (name, position, phone, monthly_salary, hire_date)
      VALUES (?, ?, ?, ?, ?)
    `).run(name, position || null, phone || null, monthly_salary, hire_date || null);

    // إضافة راتب الشهر الحالي تلقائياً
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1;
    const currentYear = currentDate.getFullYear();

    db.prepare(`
      INSERT OR IGNORE INTO monthly_salaries 
      (employee_id, month, year, salary_amount)
      VALUES (?, ?, ?, ?)
    `).run(result.lastInsertRowid, currentMonth, currentYear, monthly_salary);

    res.json({ 
      id: result.lastInsertRowid, 
      message: "تم إضافة الموظف بنجاح",
      auto_salary_generated: true
    });
  } catch (error) {
    console.error("خطأ في إضافة الموظف:", error);
    res.status(500).json({ error: "خطأ في إضافة الموظف" });
  }
});

app.put("/api/employees/:id", authenticateAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { name, position, phone, monthly_salary, hire_date } = req.body;

    if (!name || !monthly_salary) {
      return res.status(400).json({ error: "الاسم والراتب الشهري مطلوبان" });
    }

    // الحصول على الراتب القديم للمقارنة
    const oldEmployee = db.prepare(`
      SELECT monthly_salary FROM employees WHERE id = ? AND is_active = 1
    `).get(id) as { monthly_salary: number } | undefined;

    if (!oldEmployee) {
      return res.status(404).json({ error: "الموظف غير موجود" });
    }

    const result = db.prepare(`
      UPDATE employees 
      SET name = ?, position = ?, phone = ?, monthly_salary = ?, hire_date = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND is_active = 1
    `).run(name, position || null, phone || null, monthly_salary, hire_date || null, id);

    if (result.changes === 0) {
      return res.status(404).json({ error: "الموظف غير موجود" });
    }

    // إذا تغير الراتب، نحدث جميع الرواتب من الشهر الحالي
    if (oldEmployee.monthly_salary !== monthly_salary) {
      const currentDate = new Date();
      const currentMonth = currentDate.getMonth() + 1;
      const currentYear = currentDate.getFullYear();

      console.log(`تغيير راتب الموظف ${id} من ${oldEmployee.monthly_salary} إلى ${monthly_salary}`);
      console.log(`التاريخ الحالي: ${currentYear}/${currentMonth}`);

      // البحث عن الرواتب الموجودة للموظف
      const existingSalaries = db.prepare(`
        SELECT id, month, year, salary_amount, is_delivered 
        FROM monthly_salaries 
        WHERE employee_id = ?
        ORDER BY year, month
      `).all(id);

      console.log(`الرواتب الموجودة للموظف ${id}:`, existingSalaries);

      // تحديث جميع رواتب الشهر الحالي والأشهر المستقبلية (مسلمة وغير مسلمة)
      const updateResult = db.prepare(`
        UPDATE monthly_salaries 
        SET salary_amount = ?, updated_at = CURRENT_TIMESTAMP
        WHERE employee_id = ? 
        AND (
          (year = ? AND month >= ?) 
          OR year > ?
        )
      `).run(monthly_salary, id, currentYear, currentMonth, currentYear);

      console.log(`تم تحديث ${updateResult.changes} راتب للموظف ${id} بالراتب الجديد ${monthly_salary} (شامل المسلمة وغير المسلمة)`);
      
      // عرض الرواتب بعد التحديث
      const updatedSalaries = db.prepare(`
        SELECT id, month, year, salary_amount, is_delivered 
        FROM monthly_salaries 
        WHERE employee_id = ?
        ORDER BY year, month
      `).all(id);

      console.log(`الرواتب بعد التحديث:`, updatedSalaries);
    }

    res.json({ 
      message: "تم تحديث بيانات الموظف بنجاح",
      salary_updated: oldEmployee.monthly_salary !== monthly_salary,
      updated_salaries: oldEmployee.monthly_salary !== monthly_salary ? "تم تحديث جميع رواتب الشهر الحالي والمستقبلية" : null
    });
  } catch (error) {
    console.error("خطأ في تحديث الموظف:", error);
    res.status(500).json({ error: "خطأ في تحديث الموظف" });
  }
});

app.delete("/api/employees/:id", authenticateAdmin, (req, res) => {
  try {
    const { id } = req.params;

    // إلغاء تفعيل الموظف بدلاً من حذفه
    const result = db.prepare(`
      UPDATE employees 
      SET is_active = 0, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(id);

    if (result.changes === 0) {
      return res.status(404).json({ error: "الموظف غير موجود" });
    }

    res.json({ message: "تم إلغاء تفعيل الموظف بنجاح" });
  } catch (error) {
    console.error("خطأ في حذف الموظف:", error);
    res.status(500).json({ error: "خطأ في حذف الموظف" });
  }
});

// 💰 إدارة الرواتب الشهرية
app.get("/api/salaries", authenticateAdmin, (req, res) => {
  try {
    const { month, year } = req.query;
    
    let query = `
      SELECT 
        ms.id,
        ms.employee_id,
        e.name as employee_name,
        e.position,
        ms.month,
        ms.year,
        ms.salary_amount,
        ms.is_delivered,
        ms.delivery_date,
        ms.debt_amount,
        ms.notes,
        ms.created_at,
        ms.updated_at
      FROM monthly_salaries ms
      JOIN employees e ON ms.employee_id = e.id
      WHERE e.is_active = 1
    `;

    const params: any[] = [];
    
    if (month) {
      query += ` AND ms.month = ?`;
      params.push(month);
    }
    
    if (year) {
      query += ` AND ms.year = ?`;
      params.push(year);
    }

    query += ` ORDER BY ms.year DESC, ms.month DESC, e.name`;

    const salaries = db.prepare(query).all(...params);
    res.json(salaries);
  } catch (error) {
    console.error("خطأ في جلب الرواتب:", error);
    res.status(500).json({ error: "خطأ في جلب الرواتب" });
  }
});

app.post("/api/salaries/generate", authenticateAdmin, (req, res) => {
  try {
    const { month, year } = req.body;

    if (!month || !year) {
      return res.status(400).json({ error: "الشهر والسنة مطلوبان" });
    }

    // الحصول على جميع الموظفين النشطين
    const employees = db.prepare(`
      SELECT id, monthly_salary FROM employees WHERE is_active = 1
    `).all();

    let generated = 0;
    let existing = 0;

    const insertSalary = db.prepare(`
      INSERT OR IGNORE INTO monthly_salaries 
      (employee_id, month, year, salary_amount)
      VALUES (?, ?, ?, ?)
    `);

    employees.forEach((employee: any) => {
      const result = insertSalary.run(employee.id, month, year, employee.monthly_salary);
      if (result.changes > 0) {
        generated++;
      } else {
        existing++;
      }
    });

    res.json({ 
      message: `تم توليد ${generated} راتب جديد`,
      generated,
      existing,
      total_employees: employees.length
    });
  } catch (error) {
    console.error("خطأ في توليد الرواتب:", error);
    res.status(500).json({ error: "خطأ في توليد الرواتب" });
  }
});

app.put("/api/salaries/:id/delivery", authenticateAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { is_delivered, delivery_date, debt_amount, notes } = req.body;

    console.log("تحديث راتب - البيانات:", { 
      id, 
      id_type: typeof id,
      is_delivered, 
      is_delivered_type: typeof is_delivered,
      delivery_date, 
      debt_amount,
      debt_amount_type: typeof debt_amount, 
      notes,
      raw_body: req.body
    });

    // التحقق من وجود الراتب أولاً
    const existingSalary = db.prepare(`
      SELECT * FROM monthly_salaries WHERE id = ?
    `).get(id);

    if (!existingSalary) {
      console.log("الراتب غير موجود - ID:", id);
      return res.status(404).json({ error: "الراتب غير موجود" });
    }

    console.log("الراتب الموجود:", existingSalary);

    // تحويل القيم إلى الأنواع المطلوبة (is_delivered يجب أن يكون رقم 0 أو 1)
    const deliveredValue = is_delivered ? 1 : 0;
    const deliveryDateValue = delivery_date || null;
    const debtAmountValue = debt_amount !== undefined && debt_amount !== null ? Number(debt_amount) : null;
    const notesValue = notes !== undefined && notes !== null ? String(notes) : null;

    console.log("القيم المعالجة:", {
      deliveredValue,
      deliveryDateValue,
      debtAmountValue,
      notesValue
    });

    const result = db.prepare(`
      UPDATE monthly_salaries 
      SET 
        is_delivered = ?, 
        delivery_date = ?, 
        debt_amount = COALESCE(?, debt_amount),
        notes = COALESCE(?, notes),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      deliveredValue, 
      deliveryDateValue, 
      debtAmountValue,
      notesValue,
      id
    );

    console.log("نتيجة التحديث:", result);

    if (result.changes === 0) {
      return res.status(404).json({ error: "فشل في تحديث الراتب" });
    }

    res.json({ message: "تم تحديث حالة الراتب بنجاح" });
  } catch (error) {
    console.error("خطأ في تحديث حالة الراتب:", error);
    console.error("Stack trace:", (error as Error)?.stack);
    res.status(500).json({ error: "خطأ في تحديث حالة الراتب" });
  }
});

// تعديل راتب شهري مباشرة
app.put("/api/salaries/:id", authenticateAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { salary_amount, is_delivered, delivery_date, debt_amount, notes } = req.body;

    if (!salary_amount || salary_amount <= 0) {
      return res.status(400).json({ error: "مبلغ الراتب مطلوب ويجب أن يكون أكبر من صفر" });
    }

    // التحقق من وجود الراتب
    const existingSalary = db.prepare(`
      SELECT * FROM monthly_salaries WHERE id = ?
    `).get(id);

    if (!existingSalary) {
      return res.status(404).json({ error: "الراتب غير موجود" });
    }

    const result = db.prepare(`
      UPDATE monthly_salaries 
      SET 
        salary_amount = ?,
        is_delivered = COALESCE(?, is_delivered),
        delivery_date = COALESCE(?, delivery_date),
        debt_amount = COALESCE(?, debt_amount),
        notes = COALESCE(?, notes),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      salary_amount,
      is_delivered !== undefined ? is_delivered : null,
      delivery_date !== undefined ? delivery_date : null,
      debt_amount !== undefined ? debt_amount : null,
      notes !== undefined ? notes : null,
      id
    );

    if (result.changes === 0) {
      return res.status(404).json({ error: "فشل في تحديث الراتب" });
    }

    res.json({ message: "تم تحديث الراتب بنجاح" });
  } catch (error) {
    console.error("خطأ في تحديث الراتب:", error);
    res.status(500).json({ error: "خطأ في تحديث الراتب" });
  }
});

// حذف راتب شهري
app.delete("/api/salaries/:id", authenticateAdmin, (req, res) => {
  try {
    const { id } = req.params;

    // التحقق من وجود الراتب
    const existingSalary = db.prepare(`
      SELECT * FROM monthly_salaries WHERE id = ?
    `).get(id);

    if (!existingSalary) {
      return res.status(404).json({ error: "الراتب غير موجود" });
    }

    const result = db.prepare(`
      DELETE FROM monthly_salaries WHERE id = ?
    `).run(id);

    if (result.changes === 0) {
      return res.status(404).json({ error: "فشل في حذف الراتب" });
    }

    res.json({ message: "تم حذف الراتب بنجاح" });
  } catch (error) {
    console.error("خطأ في حذف الراتب:", error);
    res.status(500).json({ error: "خطأ في حذف الراتب" });
  }
});

// إعادة مزامنة رواتب موظف مع راتبه الحالي
app.post("/api/salaries/sync-employee/:employeeId", authenticateAdmin, (req, res) => {
  try {
    const { employeeId } = req.params;
    const { fromMonth, fromYear } = req.body;

    // الحصول على بيانات الموظف
    const employee = db.prepare(`
      SELECT monthly_salary FROM employees WHERE id = ? AND is_active = 1
    `).get(employeeId) as { monthly_salary: number } | undefined;

    if (!employee) {
      return res.status(404).json({ error: "الموظف غير موجود" });
    }

    let whereClause = "employee_id = ?";
    let params: any[] = [employeeId];

    if (fromMonth && fromYear) {
      whereClause += " AND ((year = ? AND month >= ?) OR year > ?)";
      params.push(fromYear, fromMonth, fromYear);
    } else {
      // إذا لم يحدد شهر، فقط الرواتب غير المسلمة
      whereClause += " AND is_delivered = 0";
    }

    // تحديث جميع الرواتب المحددة
    const result = db.prepare(`
      UPDATE monthly_salaries 
      SET salary_amount = ?, updated_at = CURRENT_TIMESTAMP
      WHERE ${whereClause}
    `).run(employee.monthly_salary, ...params);

    res.json({ 
      message: `تم تحديث ${result.changes} راتب للموظف`,
      updated_count: result.changes,
      new_salary: employee.monthly_salary
    });
  } catch (error) {
    console.error("خطأ في مزامنة الرواتب:", error);
    res.status(500).json({ error: "خطأ في مزامنة الرواتب" });
  }
});

// ⚙️ إدارة الإعدادات
app.get("/api/settings", authenticateAdmin, (req, res) => {
  try {
    const settings = db.prepare('SELECT * FROM settings_new ORDER BY key').all();
    
    // تحويل إلى object للسهولة
    const settingsObj: any = {};
    settings.forEach((setting: any) => {
      let value = setting.value;
      
      // تحويل القيم حسب النوع
      if (setting.type === 'number') {
        value = parseFloat(value);
      } else if (setting.type === 'boolean') {
        value = value === 'true';
      }
      
      settingsObj[setting.key] = {
        value,
        type: setting.type,
        id: setting.id
      };
    });
    
    res.json(settingsObj);
  } catch (error) {
    console.error("خطأ في جلب الإعدادات:", error);
    res.status(500).json({ error: "خطأ في جلب الإعدادات" });
  }
});

app.put("/api/settings/:key", authenticateAdmin, (req, res) => {
  try {
    const { key } = req.params;
    const { value, type } = req.body;

    const result = db.prepare(`
      UPDATE settings_new 
      SET value = ?, type = COALESCE(?, type), updated_at = CURRENT_TIMESTAMP
      WHERE key = ?
    `).run(String(value), type, key);

    if (result.changes === 0) {
      // إذا لم توجد، أنشئها
      db.prepare(`
        INSERT INTO settings_new (key, value, type) VALUES (?, ?, ?)
      `).run(key, String(value), type || 'string');
    }

    res.json({ message: "تم تحديث الإعداد بنجاح" });
  } catch (error) {
    console.error("خطأ في تحديث الإعداد:", error);
    res.status(500).json({ error: "خطأ في تحديث الإعداد" });
  }
});

// معالج الأخطاء العامة
app.use((err: any, req: any, res: any, next: any) => {
  console.error("خطأ غير متوقع:", err);
  res.status(500).json({ error: "خطأ داخلي في الخادم" });
});

// معالج المسارات غير الموجودة - للإنتاج نخدم React App
app.use("*", (req, res) => {
  if (process.env.NODE_ENV === 'production') {
    res.sendFile(path.join(__dirname, '../../web/dist/index.html'));
  } else {
    res.status(404).json({ error: "المسار غير موجود" });
  }
});

// بدء الخادم
app.listen(PORT, () => {
  const serverUrl = process.env.NODE_ENV === 'production' 
    ? 'https://salary.soqiamakkah.com' 
    : `http://localhost:${PORT}`;
  console.log(`🚀 الخادم يعمل على ${serverUrl}`);
  console.log(`📁 قاعدة البيانات: ${dbPath}`);
});

// إغلاق قاعدة البيانات عند إنهاء التطبيق
process.on('SIGINT', () => {
  console.log('\n🔌 إغلاق قاعدة البيانات...');
  db.close();
  process.exit(0);
});
