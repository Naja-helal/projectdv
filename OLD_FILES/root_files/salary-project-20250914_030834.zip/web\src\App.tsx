import { Routes, Route } from 'react-router-dom'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import Layout from './components/layout/Layout'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Reports from './pages/Reports'
import Expenses from './pages/ExpensesNew'
import Categories from './pages/CategoriesNew'
import Vendors from './pages/VendorsNew'
import Bramawi from './pages/Bramawi'
import Settings from './pages/Settings'
import DynamicFields from './pages/DynamicFields'
import Mosques from './pages/Mosques'
import Distributions from './pages/Distributions'
import EmployeesPage from './pages/EmployeesPage'
import SalariesPage from './pages/SalariesPage'

function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/*" element={
        <ProtectedRoute>
          <Layout>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/expenses" element={<Expenses />} />
              <Route path="/categories" element={<Categories />} />
              <Route path="/vendors" element={<Vendors />} />
              <Route path="/bramawi" element={<Bramawi />} />
              <Route path="/mosques" element={<Mosques />} />
              <Route path="/distributions" element={<Distributions />} />
              <Route path="/salaries" element={<SalariesPage />} />
              <Route path="/employees" element={<EmployeesPage />} />
              <Route path="/dynamic-fields" element={<DynamicFields />} />
              <Route path="/settings" element={<Settings />} />
            </Routes>
          </Layout>
        </ProtectedRoute>
      } />
    </Routes>
  )
}

export default App
