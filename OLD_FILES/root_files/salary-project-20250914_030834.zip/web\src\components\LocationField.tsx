import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ExternalLink, Link } from "lucide-react";

interface UrlFieldProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
}

// دالة للتحقق من صحة الرابط
function isValidUrl(url: string) {
  if (!url) return false;
  try {
    new URL(url);
    return true;
  } catch {
    // إذا لم يحتوي على http/https، أضفه
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      try {
        new URL('https://' + url);
        return true;
      } catch {
        return false;
      }
    }
    return false;
  }
}

// دالة لفتح الرابط
function openUrl(url: string) {
  if (!url) return;
  
  let finalUrl = url;
  // إضافة https إذا لم يكن موجود
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    finalUrl = 'https://' + url;
  }
  
  window.open(finalUrl, '_blank');
}

export function UrlField({ 
  value, 
  onChange, 
  placeholder = "أدخل الرابط (مثال: example.com)", 
  disabled = false,
  className = ""
}: UrlFieldProps) {
  const isValid = isValidUrl(value);
  
  return (
    <div className={`space-y-2 ${className}`}>
      <div className="relative flex gap-2">
        <div className="relative flex-1">
          <Input
            type="url"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            disabled={disabled}
            className="pl-10 pr-4"
            dir="ltr"
          />
          <Link className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        </div>
        
        {value && isValid && (
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => openUrl(value)}
            className="flex items-center gap-1 shrink-0"
          >
            <ExternalLink className="h-4 w-4" />
            فتح
          </Button>
        )}
      </div>
      
      {/* معاينة حالة الرابط */}
      {value && (
        <div className="text-xs text-muted-foreground flex items-center gap-1">
          <div className={`w-2 h-2 rounded-full ${isValid ? 'bg-green-500' : 'bg-red-500'}`} />
          {isValid ? 'رابط صالح' : 'رابط غير صالح'}
        </div>
      )}
    </div>
  );
}

// مكون لعرض الرابط فقط (للقراءة)
interface UrlDisplayProps {
  value: string;
  label?: string;
  className?: string;
}

export function UrlDisplay({ value, label, className = "" }: UrlDisplayProps) {
  if (!value) return null;
  
  const isValid = isValidUrl(value);
  
  return (
    <div className={`space-y-1 ${className}`}>
      {label && (
        <div className="text-sm font-medium text-muted-foreground">{label}</div>
      )}
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <Link className="h-4 w-4 text-blue-600 shrink-0" />
          <span className="text-sm truncate" dir="ltr">{value}</span>
        </div>
        {isValid && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => openUrl(value)}
            className="shrink-0 h-8 px-2 text-blue-600 hover:text-blue-800"
          >
            <ExternalLink className="h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  );
}

// للتوافق مع الكود الموجود، نصدر أيضاً بالأسماء القديمة
export { UrlField as LocationField, UrlDisplay as LocationDisplay };
